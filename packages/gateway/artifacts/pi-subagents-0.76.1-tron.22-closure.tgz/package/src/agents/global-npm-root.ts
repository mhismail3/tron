import { promises as fs } from "node:fs";
import path from "node:path";
import { runSetupCommand } from "../runs/shared/worktree-setup-command.ts";

let knownRoot: string | null = null;

export function knownGlobalNpmRoot(): string | null {
	const offline = process.env.PI_OFFLINE?.toLowerCase();
	return offline === "1" || offline === "true" || offline === "yes" ? null : knownRoot;
}

export async function resolveGlobalNpmRoot(options: {
	env?: NodeJS.ProcessEnv;
	platform?: NodeJS.Platform;
	timeoutMs?: number;
	signal?: AbortSignal;
} = {}): Promise<string | null> {
	const env = options.env ?? process.env;
	const offline = env.PI_OFFLINE?.toLowerCase();
	if (options.signal?.aborted || offline === "1" || offline === "true" || offline === "yes") return null;

	if ((options.platform ?? process.platform) === "win32" && env.APPDATA) {
		const appDataRoot = path.join(env.APPDATA, "npm", "node_modules");
		try {
			if ((await fs.stat(appDataRoot)).isDirectory()) {
				const root = await fs.realpath(appDataRoot);
				if (!options.env) knownRoot = root;
				return root;
			}
		} catch {}
	}
	const windows = process.platform === "win32";
	const result = await runSetupCommand(windows ? env.ComSpec ?? "cmd.exe" : "npm",
		windows ? ["/d", "/s", "/c", "npm root -g"] : ["root", "-g"], {
			env, signal: options.signal, hookTimeoutMs: options.timeoutMs ?? 5000, maxBuffer: 64 * 1024,
			acceptedExitCodes: Array.from({ length: 256 }, (_, code) => code),
		});
	if (result.processTree?.state === "unknown") {
		console.error("Global npm lookup process tree did not settle:", result.processTree);
		return null;
	}
	if (result.error || result.status !== 0 || options.signal?.aborted) return null;
	const output = result.stdout.trim();
	if (!output) return null;
	try {
		const root = await fs.realpath(output);
		if (!options.env) knownRoot = root;
		return root;
	} catch {
		return null;
	}
}
