# Tron-only patch series

This fork is based on upstream `v0.76.1`. These changes have not yet been proposed upstream.

## Provider-owned child lifecycle declaration store

- **Purpose:** define one versioned declaration per producer in the lifecycle owner's private run directory, with stable producer lookup and owner-scoped bounded pagination that remains independent of recent status projections. Immutable producer identity cannot be overwritten by a conflicting update; malformed or over-version records fail closed.
- **Maintainer source:** task #573 / approved #554 design, provider-owned lifecycle declaration portion.
- **Tests:** `test/integration/child-lifecycle-declaration.test.ts` verifies persisted declarations, pagination of 40 retained records beyond the 32-item page, exact lookup beyond the first page, invalid IDs/cursors, malformed versions, and conflicting identity. Header-readiness tests reject a missing/truncated header and publish only after a complete Pi session header is present.
- **Status:** foreground and detached-runner create boundaries now publish declarations before creating Pi children and use `publishChildLifecycleHeaderReady` at creation, non-streaming session events, and prompt settlement. Coverage includes single, structured parallel/chain, workflow `runs.run`/`runs.all`/`runs.lanes`, run-ID/keyed/previous-stage resumes, fork context, and immediate-parent nested launches. Declarations live only in the child's run directory; `workflowEdge: { workflowRunId, workflowKey }` makes the existing workflow-row → child-run link verifiable without a duplicate workflow declaration. Exact producer IDs are preserved (`foreground-index:N` or the existing async status child identity); only filenames are SHA-256 encoded. Launches without canonical parent/session evidence do not claim an admitted transcript. Scheduler launch receipts are integrated below; general lifecycle-state transitions remain separate outstanding work.
- **Launch tests:** `test/integration/child-lifecycle-launch.test.ts` drives the provider owners with scripted Pi sessions, checking launch ordering, canonical file/owner/parent, header readiness, workflow edges, shared resume files, and nested immediate parents. Missing headers remain unready; conflicting workflow edges are rejected. Removing the foreground create-boundary publication makes the representative test fail; source restoration is trap-protected and `cmp` verified. Full unit/integration suites pass.
- **Artifact scope:** repacked with the launch wiring and scheduler receipt implementation; no Stable or Debug installation is performed by this lane.
- **Upstream status:** not yet proposed.
- **Artifact:** `artifacts/pi-subagents-0.76.1-tron.4.tgz`; SHA-256 is recorded in the release section below.

## Scheduler-owned durable launch receipt

- **Purpose:** persist a version-1 `launchReceipt` in the existing untrimmed schedule `runs/<scheduleRunId>.json` before any workflow child can launch, naming `scheduleId`, the exact workflow root `providerRunId`/`producerRunId`, and the canonical immediate parent `parentSessionIdentity`/`parentSessionFile`. The executor's internal pre-start callback runs immediately after root ID allocation; the lightweight bridge preserves extension lazy loading. Existing schedule attachment, completion and restart recovery retain the same receipt, independent of bounded history. If a crash precedes async attachment, restart reads only the exact root's owned status through the existing status reader and attaches it to the same run record only when `status.runId` matches the receipt. Missing, malformed or mismatched status retains existing stale-claim handling.
- **Parent authority:** read at firing time from a bounded, complete persisted Pi header matching the current session ID; missing, mismatched, non-file or symlink parents yield `available: false, reason: "canonical-parent-unavailable"`. Explicit internal `lifecycleProvenance` flows into workflow children and suppresses their admitted declarations without removing the runtime session identity or preventing scheduled execution. Ordinary launches retain their current behaviour.
- **Approved design refinement:** a scheduled workflow root owns no Pi transcript, so its receipt deliberately omits `sessionFile` and `sessionOwnerId`. Those fields remain exclusively in each child's existing declaration, linked to the root through `workflowEdge`; there is no duplicate scheduler declaration or transcript map.
- **Tests:** `test/integration/scheduled-lifecycle-receipt.test.ts` runs a timer-fired workflow with valid, missing and mismatched parent fixtures. After scheduler restart and removal of both async attachment fields and the bounded history projection, its untrimmed receipt alone still resolves the root, child declaration and canonical session; invalid parents still execute but publish no admitted child declaration. Missing, mismatched and malformed root status negative controls do not attach and become stale failed launches. Removing the pre-start publication call makes the valid-parent case fail; a shell trap restores source and `cmp` verifies restoration. The existing schedule expected-params fixture now includes explicit unavailable provenance.
- **Validation:** `npm run typecheck`, focused scheduler/lazy-loading regressions, and full `npm run test:all` pass (unit 3,796 passed / 17 skipped; integration 1,186 passed / 7 skipped). The initial full-suite attempt exposed an eager-import regression and one stale expected-params fixture; both were fixed before the successful complete run. A later recovery-validation run hit the previously classified parallel-load `result-watcher.test.ts:86` timeout; the entire watcher file passed in isolation without edits, and the final complete run passed.
- **Upstream status:** not yet proposed. General child lifecycle-state transitions and the Gateway/cross-client admission matrix remain owning-lane work.
- **Drop condition:** remove when upstream retains equivalent schedule launch provenance before child creation and fails closed for unavailable canonical parents, with child-owned transcript declarations preserved.

### Release artifact

- Exactly one retained package tarball: `artifacts/pi-subagents-0.76.1-tron.4.tgz`, built from this fork's compiled package with Task A/B/C changes. SHA-256: `38461c9d9781b023a57c45c6f6cfde7b69470a03cca3425a0c7821556b0dc6fa`. The digest is recorded after packing; the bundled copy of this document cannot embed its own tarball digest.

## External CLI transcript capability declaration

- **Purpose:** make external CLI runners explicitly state that they do not own a Pi transcript. The declaration is present in runner status and workflow receipt metadata; external artifact paths remain artifacts, never Pi transcript references.
- **Maintainer source:** task #573 / approved #554 design, provider-owned external-runner portion.
- **Tests:** `test/integration/external-cli-runner.test.ts` executes the real external runner and asserts the no-transcript declaration. Its negative control removes that declaration and proves the runner normalizer rejects the record.
- **Upstream status:** not yet proposed.
- **Artifact:** `artifacts/pi-subagents-0.76.1-tron.4.tgz`; SHA-256 is recorded in the release section above.
- **Drop condition:** remove when upstream status and receipt contracts explicitly represent external runners as having no Pi transcript; retain the regression test as appropriate.

## Early fork admission and pre-spawn cleanup

- **Purpose:** reject a dirty managed worktree before preparing a fork session, and remove only the fork created by the current launch if the source becomes dirty during fork creation and worktree admission rejects the launch. Cleanup is owned by the fork-context resolver; unrelated or handed-off sessions are not targeted.
- **Maintainer source:** `0c0276d9` (`Prevent rejected launches from orphaning fork sessions`), narrowed to the proven worktree-admission cases.
- **Tests:** `test/integration/fork-context-execution.test.ts` — “rejects a dirty managed worktree before creating a fork session” and “cleans a newly prepared fork when worktree state races before spawn”. Both fail on bare `tron/main` and pass after the change. The complete test file passes 40/40; typecheck passes.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove this delta when upstream admission ordering ensures worktree rejection precedes fork creation and resolver-owned cleanup covers a fork created during an admission race; retain the regression tests as appropriate.

## Resolver-owned cleanup for rejected launches

- **Purpose:** a fork session exists before the child is launched. If foreground child-session creation rejects or async startup fails before the runner proceeds, the resolver removes the prepared fork. The same resolver refuses cleanup after the session has been handed off to a child.
- **Maintainer source:** `0c0276d9` (`Prevent rejected launches from orphaning fork sessions`), narrowed to verified current-upstream rejection seams.
- **Tests:** `test/integration/fork-context-execution.test.ts` — “removes an unhanded fork when foreground child-session creation rejects” and “removes a prepared fork when async startup fails before proceed”. Both fail on the current code before this delta and pass afterward. The complete test file passes 42/42; `npm run typecheck` passes.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove when upstream preserves fork files on every started or handed-off path but cleans them from all reachable pre-handoff foreground and async rejection paths at the resolver owner; retain the tests as appropriate.

## Bounded lifecycle projection in canonical status

- **Purpose:** derive a bounded lifecycle header from the same async status candidate and persist it as the first property in `status.json`; retain active child facts within the header's child bound. Status fields remain authoritative, and lifecycle header is a disposable projection.
- **Maintainer source:** `6af9779b` (`Embed bounded lifecycle header in canonical status`).
- **Tests:** `test/integration/async-execution.part-1.test.ts` — terminal status header identity/state and first-property persistence; `test/unit/async-status-projection.test.ts` — size bounds, omitted children, stable projection under unbounded result errors, and retention of active children. On bare `tron/main`, the integration assertion failed because first property was `lifecycleArtifactVersion`, not `lifecycleProjection`. After the delta, projection unit test passes 21/21 and the targeted terminal-status integration test passes.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove when upstream writes an equivalent versioned, bounded first-property lifecycle header on all status persistence/update paths and preserves active children under the header bound; retain the regression tests as appropriate.

### Lifecycle header terminal and child facts

- **Purpose:** preserve explicit run end timestamps and bounded child session-file/owner identifiers in internal lifecycle projections; reject empty, NUL-containing, or over-4-KiB session identifiers.
- **Maintainer source:** `e7353c0f` (`Preserve terminal and child lifecycle header facts`).
- **Tests:** `test/unit/async-status-projection.test.ts` asserts terminal `endedAt` and child `sessionFile` retention. It failed before the delta (`20 !== 30`) and passes afterward.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove when upstream lifecycle projection preserves exact end timestamps and equally bounded child session identity; retain the regression test as appropriate.

### Public snapshot timestamp compatibility

- **Purpose:** keep logical `endedAt` in the internal lifecycle header without changing the existing public widget snapshot's last-update timestamp; retain UTF-16-bounded display text at its expected UTF-8 size.
- **Maintainer source:** `035de2bd` (`Preserve public snapshot timestamps in lifecycle projection`).
- **Tests:** `test/unit/async-status-projection.test.ts` — Unicode display-field byte length and public terminal snapshot timestamp. The timestamp test failed before the delta (`20` instead of expected public `30`) and passes afterward.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove when upstream separates internal logical completion time from public snapshot timestamp without regressing UTF-8 bounded display labels; retain the tests as appropriate.

### Preserve lifecycle root under byte fencing

- **Purpose:** retain the run root while reducing low-priority descendants until the complete lifecycle envelope fits its 30-KiB serialized bound; mark byte-limit and omitted-child facts accurately.
- **Maintainer source:** `5c2b4ab3` (`Harden lifecycle header bounds and slash test isolation`). The unrelated test-home isolation edit for slash custom-message tests is not ported: the task’s clean isolated test environment already provides test HOME isolation, and it does not affect lifecycle behavior.
- **Tests:** `test/unit/async-status-projection.test.ts` builds a large Unicode/long-path fleet, requires root identity and state to survive, and requires the whole header envelope to remain within 30 KiB. It fails before the delta because all runs are dropped and lifecycle creation throws; it passes afterward.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove when upstream keeps the lifecycle root under the header's serialized byte cap while shedding descendants in retention order; retain the regression test as appropriate.

## Test fixture isolation and Herdr timeout ownership

- **Purpose:** keep timeout completion alive for silent spawned Herdr commands, pin user-agent-dir fixture state to each temporary home, and make retention test timestamps relative to wall time.
- **Maintainer source:** `51a4baee` (`Stabilize isolated unit fixtures and Herdr timeouts`).
- **Tests:** `test/unit/herdr-inspector.test.ts` adds a subprocess-level test that failed before the source change because the process exited before returning `TIMEOUT`; it passes after retaining the timeout handle. Existing agent/profile/skill fixtures now restore `PI_CODING_AGENT_DIR`; `async-retention.test.ts` uses a relative wall-clock anchor to avoid mtime comparison races.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove when upstream no longer unrefs a promise-owning timeout and these fixtures can run without ambient user-directory or historical-time interference; retain regression coverage as appropriate.

## Preserve original session ownership across resumes

- **Purpose:** carry a stable `sessionOwnerId` alongside `sessionFile`, distinct from the execution `runId` and workflow key, so a later resumed run retains the original file binding without guessing owner identity from a path. The field stays in private lifecycle headers and is validated when read from recovery descriptors/results.
- **Maintainer source:** `d3bd36e5` (`Preserve original session ownership through subagent resumes`).
- **Tests:** `test/unit/async-status-projection.test.ts` proves private root and child binding evidence remains in lifecycle headers while public snapshots omit it, and that lifecycle headers retain graph-derived running host monitors; `test/unit/async-resume.test.ts` proves explicit owner continuity across executions, no path-derived legacy reconstruction, rejects unsafe recovery-descriptor owners, and prevents a multi-step child from inheriting its workflow parent's owner. `test/integration/single-execution.part-1.test.ts` launches a real async child, completes and resumes it, and verifies the imported result retains its original owner; it also verifies an awaited workflow child carries owner evidence. `test/integration/intercom-result-delivery.test.ts` performs a real completed chain-root attachment and asserts the imported child keeps its own `sessionOwnerId` and `sessionFile`, distinct from the parent. Its negative control removing owner propagation from `chain-root-attachment.ts` fails. The runner now forwards that imported owner into the attached step result.
- **Upstream status:** not yet proposed.
- **Artifact:** packaged as `artifacts/pi-subagents-0.76.1-tron.3.tgz`; SHA-256 is recorded in the lane 560 validation summary.
- **Drop condition:** remove when upstream retains an explicit original session owner across all fresh/revival paths and recovery descriptors/results while keeping it out of public projections; retain the tests as appropriate.

## Supervisor progress delivered as stored context (tron.5)

- **Purpose:** a supervisor request without a reply (progress) reaches the parent as one displayed `subagent_supervisor_request` custom message with `triggerTurn: false`, instead of being deleted. Decisions and questions are unchanged. This restores the parent's access to child progress without interrupting it (Tron maintainer decision on #611).
- **Change:** `src/intercom/native-supervisor-channel.ts`, commit `3b40dda9`.
- **Tests:** supervisor ask registration and native supervisor channel unit tests: one stored, displayed send, no turn, request file removed, and decisions still wake.
- **Upstream status:** not yet proposed. Upstream #2229/#2230 deliberately removed progress from parent turns; this keeps that (no turn) but retains the context.
- **Drop condition:** remove when upstream delivers progress as non-turn context.

## Causing tool call in child lifecycle declarations (tron.5)

- **Purpose:** each child lifecycle declaration (now version 2) records `launchToolCallId`, the exact tool execution that caused this child run to launch, so a host can prove the backward edge from a parent tool call, including code-mode nested calls, to its children. It is absent only for launches no tool execution caused (scheduler timers, automatic revival), which state their launch kind.
- **Change:** `src/runs/shared/child-lifecycle-declaration.ts`, `src/runs/shared/child-lifecycle-launch.ts` and launch owners, commit `9c89d552`.
- **Tests:** child lifecycle declaration and launch integration tests, per launch kind.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove when upstream declarations carry the causing tool call.


## Per-child workflow settlement is context only (tron.5)

- **Purpose:** `subagent-incremental-child-notify` is always sent with `triggerTurn: false`. In Tron, every case where the parent must act has its own wake: async workflow completion (`subagent-notify`), the foreground tool result, scheduled completion (quiet schedules still wake on failure, stop or pause), supervisor decisions and attention control notices. A per-child wake therefore only interrupted the parent, and in the idle path it produced a separate wake prompt that the host could not tie to its note (Tron maintainer decision on #611).
- **Change:** `src/runs/foreground/subagent-executor.ts` (the one emitter call site); the now-unused `incrementalChildCompletionTriggersTurn` and its two unit tests are removed.
- **Tests:** notify and parent-wake unit tests (69) and the workflow result publication and single-execution integration files (146) pass. Tron's Gateway E2E verifies the independent wakes, including a real quiet scheduled failure.
- **Upstream status:** not proposed. Upstream (#2027/#2273) intentionally wakes on actionable child outcomes, for hosts without a separate workflow completion wake.
- **Drop condition:** remove if Tron adopts upstream's per-child wake policy.

### tron.5 release

- Package version `0.76.1-tron.5`. The Tron repository's `update:pi-subagents` packs and pins the self-contained closure from this commit; the Tron repository's artifacts are the release authority.
