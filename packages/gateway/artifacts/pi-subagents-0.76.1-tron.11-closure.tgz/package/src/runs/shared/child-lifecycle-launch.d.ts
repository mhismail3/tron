import type { ChildSession, ChildSessionFactory, ChildSessionLaunch } from "./child-session.ts";
import { type ChildLifecycleDeclaration } from "./child-lifecycle-declaration.ts";
export interface ChildLifecycleLaunch {
    ownerDirectory: string;
    declaration: ChildLifecycleDeclaration;
}
/** Both hosts publish at their create boundary; readiness follows session events, never a polling timer. */
export declare function createLifecycleChildSession(factory: ChildSessionFactory, launch: ChildSessionLaunch, lifecycle?: ChildLifecycleLaunch): Promise<ChildSession>;
