export declare const CHILD_LIFECYCLE_CONTRACT_VERSION: 2;
export type ChildLifecycleState = "queued" | "running" | "waiting" | "paused" | "interrupted" | "stopped" | "failed" | "completed";
export type ChildLifecycleReadiness = "declared" | "header-ready" | "terminal-without-session";
/** Owner-held provider contract for resolving one exact Pi producer independently of bounded status projections. */
export interface ChildLifecycleDeclaration {
    contractVersion: typeof CHILD_LIFECYCLE_CONTRACT_VERSION;
    providerRunId: string;
    producerRunId: string;
    parentSessionIdentity: string;
    /** Exact causing tool execution id for direct, parallel, chain, workflow and nested launches (including tool-invoked resume).
     * Absent only for no-tool launches: scheduler firing or automatic management revival. */
    launchToolCallId?: string;
    workflowEdge?: {
        workflowRunId: string;
        workflowKey: string;
    };
    sessionOwnerId: string;
    sessionFile?: string;
    task: string;
    lifecycleState: ChildLifecycleState;
    readiness: ChildLifecycleReadiness;
}
export interface ChildLifecycleDeclarationPage {
    items: ChildLifecycleDeclaration[];
    nextCursor?: string;
}
/** Persist/update the declaration inside its lifecycle owner's durable run directory. */
export declare function writeChildLifecycleDeclaration(ownerDirectory: string, declaration: ChildLifecycleDeclaration): void;
/** Resolve one retained producer directly, regardless of status-summary projection limits. */
export declare function readChildLifecycleDeclaration(ownerDirectory: string, producerRunId: string): ChildLifecycleDeclaration | undefined;
/** Publish readiness only after the declared canonical file contains a complete Pi session header. */
export declare function publishChildLifecycleHeaderReady(ownerDirectory: string, producerRunId: string): ChildLifecycleDeclaration;
/** Enumerate retained owner records in bounded stable pages; the cursor is owner-directory scoped. */
export declare function listChildLifecycleDeclarations(ownerDirectory: string, options?: {
    limit?: number;
    cursor?: string;
}): ChildLifecycleDeclarationPage;
