import type { SubagentParamsLike } from "../foreground/subagent-executor.ts";
/** Transient pre-start callback: the scheduler's durable receipt remains the provenance authority. */
export declare function bindScheduledWorkflowStart(params: SubagentParamsLike, beforeStart: (runId: string) => void): SubagentParamsLike;
/** Called immediately after allocation, before any scheduled workflow child can launch. */
export declare function publishScheduledWorkflowStart(params: SubagentParamsLike, runId: string): void;
