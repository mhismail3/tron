import { type BuildInProcessChildLaunchInput, type InheritedChildRuntime } from "../shared/child-launch.ts";
import type { RunnerSubagentStep } from "../shared/parallel-utils.ts";
export interface RunnerChildLaunchContext {
    cwd: string;
    id: string;
    flatIndex: number;
    lifecycleOwnerDirectory?: string;
    launchToolCallId?: string;
    producerRunId?: string;
    workflowEdge?: {
        workflowRunId: string;
        workflowKey: string;
    };
    artifactsDir?: string;
    childIntercomTarget?: string;
    orchestratorIntercomTarget?: string;
    nestedRoute?: BuildInProcessChildLaunchInput["nestedRoute"];
    runFanoutBudget?: BuildInProcessChildLaunchInput["runFanoutBudget"];
    capabilityCeiling?: BuildInProcessChildLaunchInput["capabilityCeiling"];
    inheritedChildRuntime?: InheritedChildRuntime;
    projectTrusted?: boolean;
}
export declare function buildRunnerChildLaunch(step: RunnerSubagentStep, ctx: RunnerChildLaunchContext, attempt: {
    model?: string;
    sessionEnabled: boolean;
    sessionDir?: string;
    sessionName?: string;
    structuredOutput?: BuildInProcessChildLaunchInput["structuredOutput"];
    childWatchdog?: BuildInProcessChildLaunchInput["childWatchdog"];
    watchdogStatus: NonNullable<BuildInProcessChildLaunchInput["watchdogStatus"]>;
}): import("../shared/child-launch.ts").InProcessChildLaunch;
