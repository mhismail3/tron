import * as fs from "node:fs";
import * as path from "node:path";
import { createHash } from "node:crypto";

export const CHILD_LIFECYCLE_CONTRACT_VERSION = 2 as const;
export type ChildLifecycleState = "queued" | "running" | "waiting" | "paused" | "interrupted" | "stopped" | "failed" | "completed";
export type ChildLifecycleReadiness = "declared" | "header-ready" | "terminal-without-session";

/** Owner-held provider contract for resolving one exact Pi producer independently of bounded status projections. */
export interface ChildLifecycleDeclaration {
	contractVersion: typeof CHILD_LIFECYCLE_CONTRACT_VERSION;
	providerRunId: string;
	producerRunId: string;
	parentSessionIdentity: string;
	/** Exact causing tool execution id for direct, parallel, chain, workflow and nested launches (including tool-invoked resume).
	 * Absent only for no-tool launches: scheduler firing or automatic management revival. */
	launchToolCallId?: string;
	workflowEdge?: { workflowRunId: string; workflowKey: string };
	sessionOwnerId: string;
	sessionFile?: string;
	task: string;
	lifecycleState: ChildLifecycleState;
	readiness: ChildLifecycleReadiness;
}

export interface ChildLifecycleDeclarationPage {
	items: ChildLifecycleDeclaration[];
	nextCursor?: string;
}

const DIRECTORY = "child-lifecycle";
const MAX_PAGE_SIZE = 32;
const ID_PATTERN = /^[^\x00-\x1f\x7f]{1,256}$/;
const STATES = new Set<ChildLifecycleState>(["queued", "running", "waiting", "paused", "interrupted", "stopped", "failed", "completed"]);
const READINESS = new Set<ChildLifecycleReadiness>(["declared", "header-ready", "terminal-without-session"]);

function declarationPath(ownerDirectory: string, producerRunId: string): string | undefined {
	if (!ID_PATTERN.test(producerRunId)) return undefined;
	return path.join(ownerDirectory, DIRECTORY, `${createHash("sha256").update(producerRunId).digest("hex")}.json`);
}

function isDeclaration(value: unknown, producerRunId?: string): value is ChildLifecycleDeclaration {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const item = value as Record<string, unknown>;
	return item.contractVersion === CHILD_LIFECYCLE_CONTRACT_VERSION
		&& typeof item.providerRunId === "string" && item.providerRunId.length > 0
		&& typeof item.producerRunId === "string" && ID_PATTERN.test(item.producerRunId)
		&& (!producerRunId || item.producerRunId === producerRunId)
		&& typeof item.parentSessionIdentity === "string" && item.parentSessionIdentity.length > 0
		&& (item.launchToolCallId === undefined || (typeof item.launchToolCallId === "string" && item.launchToolCallId.length > 0))
		&& (item.workflowEdge === undefined || (typeof item.workflowEdge === "object" && item.workflowEdge !== null
			&& typeof (item.workflowEdge as Record<string, unknown>).workflowRunId === "string" && Boolean((item.workflowEdge as Record<string, unknown>).workflowRunId)
			&& typeof (item.workflowEdge as Record<string, unknown>).workflowKey === "string" && Boolean((item.workflowEdge as Record<string, unknown>).workflowKey)))
		&& typeof item.sessionOwnerId === "string" && item.sessionOwnerId.length > 0
		&& (item.sessionFile === undefined || (typeof item.sessionFile === "string" && path.isAbsolute(item.sessionFile) && path.extname(item.sessionFile) === ".jsonl"))
		&& typeof item.task === "string"
		&& STATES.has(item.lifecycleState as ChildLifecycleState)
		&& READINESS.has(item.readiness as ChildLifecycleReadiness)
		&& (item.readiness !== "header-ready" || typeof item.sessionFile === "string")
		&& (item.readiness !== "terminal-without-session" || item.sessionFile === undefined);
}

function readPath(file: string, producerRunId?: string): ChildLifecycleDeclaration | undefined {
	try {
		const stat = fs.lstatSync(file);
		if (!stat.isFile() || stat.isSymbolicLink() || stat.size > 64 * 1024) return undefined;
		const value: unknown = JSON.parse(fs.readFileSync(file, "utf8"));
		return isDeclaration(value, producerRunId) ? value : undefined;
	} catch {
		return undefined;
	}
}

function immutableIdentity(value: ChildLifecycleDeclaration): string {
	return JSON.stringify([value.contractVersion, value.providerRunId, value.producerRunId, value.parentSessionIdentity, value.launchToolCallId, value.workflowEdge?.workflowRunId, value.workflowEdge?.workflowKey, value.sessionOwnerId, value.sessionFile, value.task]);
}

/** Persist/update the declaration inside its lifecycle owner's durable run directory. */
export function writeChildLifecycleDeclaration(ownerDirectory: string, declaration: ChildLifecycleDeclaration): void {
	if (!isDeclaration(declaration)) throw new Error("Invalid child lifecycle declaration");
	const file = declarationPath(ownerDirectory, declaration.producerRunId)!;
	const previous = readPath(file, declaration.producerRunId);
	if (previous && immutableIdentity(previous) !== immutableIdentity(declaration)) throw new Error(`Conflicting lifecycle declaration for producer '${declaration.producerRunId}'`);
	fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
	const temporary = `${file}.${process.pid}.${Math.random().toString(16).slice(2)}.tmp`;
	try {
		fs.writeFileSync(temporary, `${JSON.stringify(declaration)}\n`, { encoding: "utf8", mode: 0o600, flag: "wx" });
		fs.renameSync(temporary, file);
	} finally {
		try { fs.unlinkSync(temporary); } catch { /* already renamed */ }
	}
}

/** Resolve one retained producer directly, regardless of status-summary projection limits. */
export function readChildLifecycleDeclaration(ownerDirectory: string, producerRunId: string): ChildLifecycleDeclaration | undefined {
	const file = declarationPath(ownerDirectory, producerRunId);
	return file ? readPath(file, producerRunId) : undefined;
}

/** Publish readiness only after the declared canonical file contains a complete Pi session header. */
export function publishChildLifecycleHeaderReady(ownerDirectory: string, producerRunId: string): ChildLifecycleDeclaration {
	const current = readChildLifecycleDeclaration(ownerDirectory, producerRunId);
	if (!current || !current.sessionFile || current.readiness === "terminal-without-session") {
		throw new Error(`Producer '${producerRunId}' has no declared canonical session file`);
	}
	let headerLine = "";
	try {
		const fd = fs.openSync(current.sessionFile, "r");
		try {
			const stat = fs.fstatSync(fd);
			if (!stat.isFile() || stat.size === 0 || stat.size > 64 * 1024 * 1024) throw new Error("invalid session size");
			const buffer = Buffer.alloc(Math.min(stat.size, 64 * 1024));
			const bytes = fs.readSync(fd, buffer, 0, buffer.length, 0);
			headerLine = buffer.subarray(0, bytes).toString("utf8").split("\n", 1)[0] ?? "";
		} finally { fs.closeSync(fd); }
	} catch {
		throw new Error(`Producer '${producerRunId}' session header is not ready`);
	}
	let header: unknown;
	try { header = JSON.parse(headerLine!); } catch { throw new Error(`Producer '${producerRunId}' session header is not ready`); }
	if (!header || typeof header !== "object" || Array.isArray(header) || (header as Record<string, unknown>).type !== "session" || typeof (header as Record<string, unknown>).id !== "string" || !(header as Record<string, unknown>).id) {
		throw new Error(`Producer '${producerRunId}' session header is not ready`);
	}
	const ready = { ...current, readiness: "header-ready" as const };
	writeChildLifecycleDeclaration(ownerDirectory, ready);
	return ready;
}

/** Enumerate retained owner records in bounded stable pages; the cursor is owner-directory scoped. */
export function listChildLifecycleDeclarations(ownerDirectory: string, options: { limit?: number; cursor?: string } = {}): ChildLifecycleDeclarationPage {
	const limit = options.limit ?? MAX_PAGE_SIZE;
	if (!Number.isInteger(limit) || limit < 1 || limit > MAX_PAGE_SIZE) throw new Error(`Lifecycle page limit must be between 1 and ${MAX_PAGE_SIZE}`);
	const absoluteOwner = path.resolve(ownerDirectory);
	let offset = 0;
	if (options.cursor) {
		try {
			const cursor = JSON.parse(Buffer.from(options.cursor, "base64url").toString("utf8")) as { owner?: unknown; offset?: unknown };
			if (cursor.owner !== absoluteOwner || !Number.isSafeInteger(cursor.offset) || (cursor.offset as number) < 0) throw new Error();
			offset = cursor.offset as number;
		} catch {
			throw new Error("Invalid or foreign child lifecycle cursor");
		}
	}
	const directory = path.join(absoluteOwner, DIRECTORY);
	let names: string[];
	try { names = fs.readdirSync(directory).filter((name) => /^[a-f0-9]{64}\.json$/.test(name)).sort(); }
	catch { return { items: [] }; }
	const selected = names.slice(offset, offset + limit);
	const items = selected.map((name) => {
		const item = readPath(path.join(directory, name));
		return item && declarationPath(absoluteOwner, item.producerRunId) === path.join(directory, name) ? item : undefined;
	}).filter((item): item is ChildLifecycleDeclaration => Boolean(item));
	const nextOffset = offset + selected.length;
	return nextOffset < names.length
		? { items, nextCursor: Buffer.from(JSON.stringify({ owner: absoluteOwner, offset: nextOffset }), "utf8").toString("base64url") }
		: { items };
}
