import type { AsyncStatus } from "../../shared/types.ts";
import { projectAsyncStatusLifecycle } from "./async-status-projection.ts";

/** Persist one canonical status candidate with its bounded lifecycle header first. */
export function statusWithLifecycleProjection(status: AsyncStatus): AsyncStatus {
	const { lifecycleProjection: _previousProjection, ...candidate } = status;
	return {
		lifecycleProjection: projectAsyncStatusLifecycle(candidate),
		...candidate,
	};
}
