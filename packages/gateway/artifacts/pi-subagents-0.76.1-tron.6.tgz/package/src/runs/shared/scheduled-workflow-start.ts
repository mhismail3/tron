import type { SubagentParamsLike } from "../foreground/subagent-executor.ts";

const scheduledWorkflowStarts = new WeakMap<object, (runId: string) => void>();

/** Transient pre-start callback: the scheduler's durable receipt remains the provenance authority. */
export function bindScheduledWorkflowStart(params: SubagentParamsLike, beforeStart: (runId: string) => void): SubagentParamsLike {
	scheduledWorkflowStarts.set(params, beforeStart);
	return params;
}

/** Called immediately after allocation, before any scheduled workflow child can launch. */
export function publishScheduledWorkflowStart(params: SubagentParamsLike, runId: string): void {
	scheduledWorkflowStarts.get(params)?.(runId);
}
