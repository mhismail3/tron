/** Native runner construction, separate from its executable entrypoint and attempt loop. */
import * as path from "node:path";
import { buildInProcessChildLaunch, type BuildInProcessChildLaunchInput, type InheritedChildRuntime } from "../shared/child-launch.ts";
import { deriveForkPromptCacheKey } from "../shared/child-tool-plan.ts";
import { normalizeExtensionBindings } from "../shared/extension-bindings.ts";
import type { RunnerSubagentStep } from "../shared/parallel-utils.ts";
import { formatAcceptancePrompt } from "../shared/acceptance.ts";
import { isAgentContract } from "../shared/agent-contract.ts";
import { asyncStatusChildIdentity } from "../shared/child-identity.ts";
import { CHILD_LIFECYCLE_CONTRACT_VERSION } from "../shared/child-lifecycle-declaration.ts";

export interface RunnerChildLaunchContext {
	cwd: string;
	id: string;
	flatIndex: number;
	lifecycleOwnerDirectory?: string;
	launchToolCallId?: string;
	producerRunId?: string;
	workflowEdge?: { workflowRunId: string; workflowKey: string };
	artifactsDir?: string;
	childIntercomTarget?: string;
	orchestratorIntercomTarget?: string;
	nestedRoute?: BuildInProcessChildLaunchInput["nestedRoute"];
	runFanoutBudget?: BuildInProcessChildLaunchInput["runFanoutBudget"];
	capabilityCeiling?: BuildInProcessChildLaunchInput["capabilityCeiling"];
	inheritedChildRuntime?: InheritedChildRuntime;
	projectTrusted?: boolean;
}

export function buildRunnerChildLaunch(step: RunnerSubagentStep, ctx: RunnerChildLaunchContext, attempt: {
	model?: string;
	sessionEnabled: boolean;
	sessionDir?: string;
	sessionName?: string;
	structuredOutput?: BuildInProcessChildLaunchInput["structuredOutput"];
	childWatchdog?: BuildInProcessChildLaunchInput["childWatchdog"];
	watchdogStatus: NonNullable<BuildInProcessChildLaunchInput["watchdogStatus"]>;
}) {
	// Resource-backed system instructions survive SDK split-turn compaction verbatim.
	const acceptancePrompt = step.effectiveAcceptance
		? formatAcceptancePrompt(step.effectiveAcceptance, { reportOptional: isAgentContract(step.agentContract), structuredOutput: Boolean(step.structuredOutput?.acceptanceReportPath) })
		: "";
	return buildInProcessChildLaunch({
		machine: step.machine,
		remoteSkillNames: step.skills,
		remoteReads: step.remoteReads,
		parentSessionId: step.parentSessionId,
		forkCacheKey: step.context === "fork" ? deriveForkPromptCacheKey(step.parentSessionId) : undefined,
		sessionEnabled: attempt.sessionEnabled,
		sessionDir: attempt.sessionDir,
		sessionFile: step.sessionFile,
		...(ctx.lifecycleOwnerDirectory && step.parentSessionId && step.sessionFile ? { lifecycle: {
			ownerDirectory: ctx.lifecycleOwnerDirectory,
			declaration: {
				contractVersion: CHILD_LIFECYCLE_CONTRACT_VERSION,
				providerRunId: ctx.id,
				producerRunId: ctx.producerRunId ?? asyncStatusChildIdentity({ agent: step.agent, status: "running" }, ctx.flatIndex),
				parentSessionIdentity: step.parentSessionId,
				...(ctx.launchToolCallId !== undefined ? { launchToolCallId: ctx.launchToolCallId } : {}),
				...(ctx.workflowEdge ? { workflowEdge: ctx.workflowEdge } : {}),
				sessionOwnerId: step.sessionOwnerId ?? ctx.id,
				sessionFile: path.resolve(step.sessionFile),
				task: step.task,
				lifecycleState: "running",
				readiness: "declared",
			},
		} } : {}),
		model: attempt.model,
		inheritProjectContext: step.inheritProjectContext,
		inheritGlobalContext: step.inheritGlobalContext,
		inheritSkills: step.inheritSkills,
		requireReadTool: Boolean(step.skills?.length),
		tools: step.tools,
		excludeTools: step.excludeTools,
		allowNestedSubagents: step.allowNestedSubagents,
		descendantAllowedAgents: step.allowedAgents,
		extensions: step.extensions,
		subagentOnlyExtensions: step.subagentOnlyExtensions,
		requiredExtensions: step.requiredExtensions,
		fast: step.fast,
		systemPrompt: acceptancePrompt ? `${step.systemPrompt ?? ""}\n${acceptancePrompt}` : step.systemPrompt ?? "",
		systemPromptMode: step.systemPromptMode,
		mcpDirectTools: step.mcpDirectTools,
		builtinMcpTools: step.builtinMcpTools,
		extensionBindings: normalizeExtensionBindings(step.extensionBindings)?.value,
		capabilityCeiling: step.capabilityCeiling ?? ctx.capabilityCeiling,
		cwd: step.cwd ?? ctx.cwd,
		intercomSessionName: ctx.childIntercomTarget,
		projectTrusted: ctx.projectTrusted,
		sessionName: attempt.sessionName,
		orchestratorIntercomTarget: ctx.orchestratorIntercomTarget,
		runId: ctx.id,
		childAgentName: step.agent,
		childIndex: ctx.flatIndex,
		nestedRoute: ctx.nestedRoute,
		runFanoutBudget: ctx.runFanoutBudget ? {
			...ctx.runFanoutBudget,
			...(step.runFanoutPath ? { parentPath: `${ctx.runFanoutBudget.parentPath ? `${ctx.runFanoutBudget.parentPath}/` : ""}${step.runFanoutPath}` } : {}),
		} : undefined,
		structuredOutput: attempt.structuredOutput,
		toolBudget: step.toolBudget,
		permissionRules: step.permissionRules,
		permissionAuditPath: step.permissionRules && ctx.artifactsDir
			? path.join(ctx.artifactsDir, "permission-audit", `${ctx.id}-${ctx.flatIndex}.jsonl`) : undefined,
		childWatchdog: attempt.childWatchdog,
		// registerChildWatchdog returns before reading the sink when unconfigured.
		...(attempt.childWatchdog ? { watchdogStatus: attempt.watchdogStatus } : {}),
		waitToolEnabled: step.waitToolEnabled,
		waitToolDefaultTimeoutMs: step.waitToolDefaultTimeoutMs,
		thinkingCeiling: step.thinkingCeiling,
		maxSubagentDepth: step.maxSubagentDepth,
		inherited: ctx.inheritedChildRuntime,
		host: "runner",
	});
}
