import { promises as fs } from "node:fs";
import path from "node:path";
import { runSetupCommand } from "../runs/shared/worktree-setup-command.ts";

export async function resolveGlobalNpmRoot(options: {
	env?: NodeJS.ProcessEnv;
	platform?: NodeJS.Platform;
	timeoutMs?: number;
	signal?: AbortSignal;
} = {}): Promise<string | null> {
	const env = options.env ?? process.env;
	const offline = env.PI_OFFLINE?.toLowerCase();
	if (options.signal?.aborted || offline === "1" || offline === "true" || offline === "yes") return null;

	if ((options.platform ?? process.platform) === "win32" && env.APPDATA) {
		const appDataRoot = path.join(env.APPDATA, "npm", "node_modules");
		try {
			if ((await fs.stat(appDataRoot)).isDirectory()) return await fs.realpath(appDataRoot);
		} catch {}
	}
	const windows = process.platform === "win32";
	const result = await runSetupCommand(windows ? env.ComSpec ?? "cmd.exe" : "npm",
		windows ? ["/d", "/s", "/c", "npm root -g"] : ["root", "-g"], {
			env, signal: options.signal, hookTimeoutMs: options.timeoutMs ?? 5000, maxBuffer: 64 * 1024,
			acceptedExitCodes: Array.from({ length: 256 }, (_, code) => code),
		});
	if (result.processTree?.state === "unknown") {
		console.error("Global npm lookup process tree did not settle:", result.processTree);
		return null;
	}
	if (result.error || result.status !== 0 || options.signal?.aborted) return null;
	const output = result.stdout.trim();
	if (!output) return null;
	try {
		return await fs.realpath(output);
	} catch {
		return null;
	}
}
