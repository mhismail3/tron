export const BUILTIN_AGENT_NAMES = [
    "advisor",
    "claude-code",
    "claude-code-writer",
    "codex-exec",
    "codex-exec-writer",
    "cursor-agent",
    "cursor-agent-writer",
    "delegate",
    "evidence-auditor",
    "oracle",
    "researcher",
    "reviewer",
    "scout",
    "worker",
];
//# sourceMappingURL=builtin-names.js.map