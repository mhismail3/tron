import type { AsyncStatus } from "../../shared/types.ts";
/** Persist one canonical status candidate with its bounded lifecycle header first. */
export declare function statusWithLifecycleProjection(status: AsyncStatus): AsyncStatus;
//# sourceMappingURL=async-status-persistence.d.ts.map