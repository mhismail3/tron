import { projectAsyncStatusLifecycle } from "./async-status-projection.js";
/** Persist one canonical status candidate with its bounded lifecycle header first. */
export function statusWithLifecycleProjection(status) {
    const { lifecycleProjection: _previousProjection, ...candidate } = status;
    return {
        lifecycleProjection: projectAsyncStatusLifecycle(candidate),
        ...candidate,
    };
}
//# sourceMappingURL=async-status-persistence.js.map