# Tron-only patch series

This fork is based on upstream `v0.76.1`. These changes have not yet been proposed upstream.

## Early fork admission and pre-spawn cleanup

- **Purpose:** reject a dirty managed worktree before preparing a fork session, and remove only the fork created by the current launch if the source becomes dirty during fork creation and worktree admission rejects the launch. Cleanup is owned by the fork-context resolver; unrelated or handed-off sessions are not targeted.
- **Maintainer source:** `0c0276d9` (`Prevent rejected launches from orphaning fork sessions`), narrowed to the proven worktree-admission cases.
- **Tests:** `test/integration/fork-context-execution.test.ts` — “rejects a dirty managed worktree before creating a fork session” and “cleans a newly prepared fork when worktree state races before spawn”. Both fail on bare `tron/main` and pass after the change. The complete test file passes 40/40; typecheck passes.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove this delta when upstream admission ordering ensures worktree rejection precedes fork creation and resolver-owned cleanup covers a fork created during an admission race; retain the regression tests as appropriate.

## Resolver-owned cleanup for rejected launches

- **Purpose:** a fork session exists before the child is launched. If foreground child-session creation rejects or async startup fails before the runner proceeds, the resolver removes the prepared fork. The same resolver refuses cleanup after the session has been handed off to a child.
- **Maintainer source:** `0c0276d9` (`Prevent rejected launches from orphaning fork sessions`), narrowed to verified current-upstream rejection seams.
- **Tests:** `test/integration/fork-context-execution.test.ts` — “removes an unhanded fork when foreground child-session creation rejects” and “removes a prepared fork when async startup fails before proceed”. Both fail on the current code before this delta and pass afterward. The complete test file passes 42/42; `npm run typecheck` passes.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove when upstream preserves fork files on every started or handed-off path but cleans them from all reachable pre-handoff foreground and async rejection paths at the resolver owner; retain the tests as appropriate.

## Bounded lifecycle projection in canonical status

- **Purpose:** derive a bounded lifecycle header from the same async status candidate and persist it as the first property in `status.json`; retain active child facts within the header's child bound. Status fields remain authoritative, and lifecycle header is a disposable projection.
- **Maintainer source:** `6af9779b` (`Embed bounded lifecycle header in canonical status`).
- **Tests:** `test/integration/async-execution.part-1.test.ts` — terminal status header identity/state and first-property persistence; `test/unit/async-status-projection.test.ts` — size bounds, omitted children, stable projection under unbounded result errors, and retention of active children. On bare `tron/main`, the integration assertion failed because first property was `lifecycleArtifactVersion`, not `lifecycleProjection`. After the delta, projection unit test passes 21/21 and the targeted terminal-status integration test passes.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove when upstream writes an equivalent versioned, bounded first-property lifecycle header on all status persistence/update paths and preserves active children under the header bound; retain the regression tests as appropriate.

### Lifecycle header terminal and child facts

- **Purpose:** preserve explicit run end timestamps and bounded child session-file/owner identifiers in internal lifecycle projections; reject empty, NUL-containing, or over-4-KiB session identifiers.
- **Maintainer source:** `e7353c0f` (`Preserve terminal and child lifecycle header facts`).
- **Tests:** `test/unit/async-status-projection.test.ts` asserts terminal `endedAt` and child `sessionFile` retention. It failed before the delta (`20 !== 30`) and passes afterward.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove when upstream lifecycle projection preserves exact end timestamps and equally bounded child session identity; retain the regression test as appropriate.

### Public snapshot timestamp compatibility

- **Purpose:** keep logical `endedAt` in the internal lifecycle header without changing the existing public widget snapshot's last-update timestamp; retain UTF-16-bounded display text at its expected UTF-8 size.
- **Maintainer source:** `035de2bd` (`Preserve public snapshot timestamps in lifecycle projection`).
- **Tests:** `test/unit/async-status-projection.test.ts` — Unicode display-field byte length and public terminal snapshot timestamp. The timestamp test failed before the delta (`20` instead of expected public `30`) and passes afterward.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove when upstream separates internal logical completion time from public snapshot timestamp without regressing UTF-8 bounded display labels; retain the tests as appropriate.

### Preserve lifecycle root under byte fencing

- **Purpose:** retain the run root while reducing low-priority descendants until the complete lifecycle envelope fits its 30-KiB serialized bound; mark byte-limit and omitted-child facts accurately.
- **Maintainer source:** `5c2b4ab3` (`Harden lifecycle header bounds and slash test isolation`). The unrelated test-home isolation edit for slash custom-message tests is not ported: the task’s clean isolated test environment already provides test HOME isolation, and it does not affect lifecycle behavior.
- **Tests:** `test/unit/async-status-projection.test.ts` builds a large Unicode/long-path fleet, requires root identity and state to survive, and requires the whole header envelope to remain within 30 KiB. It fails before the delta because all runs are dropped and lifecycle creation throws; it passes afterward.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove when upstream keeps the lifecycle root under the header's serialized byte cap while shedding descendants in retention order; retain the regression test as appropriate.

## Test fixture isolation and Herdr timeout ownership

- **Purpose:** keep timeout completion alive for silent spawned Herdr commands, pin user-agent-dir fixture state to each temporary home, and make retention test timestamps relative to wall time.
- **Maintainer source:** `51a4baee` (`Stabilize isolated unit fixtures and Herdr timeouts`).
- **Tests:** `test/unit/herdr-inspector.test.ts` adds a subprocess-level test that failed before the source change because the process exited before returning `TIMEOUT`; it passes after retaining the timeout handle. Existing agent/profile/skill fixtures now restore `PI_CODING_AGENT_DIR`; `async-retention.test.ts` uses a relative wall-clock anchor to avoid mtime comparison races.
- **Upstream status:** not yet proposed.
- **Drop condition:** remove when upstream no longer unrefs a promise-owning timeout and these fixtures can run without ambient user-directory or historical-time interference; retain regression coverage as appropriate.

## Preserve original session ownership across resumes

- **Purpose:** carry a stable `sessionOwnerId` alongside `sessionFile`, distinct from the execution `runId` and workflow key, so a later resumed run retains the original file binding without guessing owner identity from a path. The field stays in private lifecycle headers and is validated when read from recovery descriptors/results.
- **Maintainer source:** `d3bd36e5` (`Preserve original session ownership through subagent resumes`).
- **Tests:** `test/unit/async-status-projection.test.ts` proves private root and child binding evidence remains in lifecycle headers while public snapshots omit it, and that lifecycle headers retain graph-derived running host monitors; `test/unit/async-resume.test.ts` proves explicit owner continuity across executions, no path-derived legacy reconstruction, rejects unsafe recovery-descriptor owners, and prevents a multi-step child from inheriting its workflow parent's owner. `test/integration/single-execution.part-1.test.ts` launches a real async child, completes and resumes it, and verifies the imported result retains its original owner; it also verifies an awaited workflow child carries owner evidence. The negative control removing final child-result serialization makes the test fail.
- **Upstream status:** not yet proposed.
- **Artifact:** packaged as `artifacts/pi-subagents-0.76.1-tron.2.tgz`; SHA-256 is recorded in the lane 560 validation summary.
- **Drop condition:** remove when upstream retains an explicit original session owner across all fresh/revival paths and recovery descriptors/results while keeping it out of public projections; retain the tests as appropriate.
