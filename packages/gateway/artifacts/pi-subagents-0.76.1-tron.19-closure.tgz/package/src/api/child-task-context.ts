import * as fs from "node:fs";
import * as path from "node:path";
import { writePrivateAtomicJson } from "../shared/atomic-json.ts";

const MAX_TASK_CONTEXT_BYTES = 4_096;
const RETAINED_FILE = "child-task-context.json";
const KEY = Symbol.for("pi-subagents.child-task-context.v1");

interface Registration { taskPrefix: string }

function registry(): Map<string, Registration> {
	const root = globalThis as Record<PropertyKey, unknown>;
	const existing = root[KEY];
	if (existing === undefined) {
		const created = new Map<string, Registration>();
		root[KEY] = created;
		return created;
	}
	if (!(existing instanceof Map)) throw new Error("Malformed child task context registry.");
	return existing;
}

export function registerChildTaskContext(input: { sessionId: string; taskPrefix: string }): { dispose(): void } {
	if (!input.sessionId || input.sessionId.trim() !== input.sessionId || input.sessionId.includes("\0")) throw new Error("Child task context requires a session identity.");
	if (typeof input.taskPrefix !== "string") throw new Error("Child task context requires a text prefix.");
	const store = registry();
	if (store.has(input.sessionId)) throw new Error("Child task context is already registered for this session.");
	const registration = Object.freeze({ taskPrefix: input.taskPrefix });
	store.set(input.sessionId, registration);
	return { dispose() { if (store.get(input.sessionId) === registration) store.delete(input.sessionId); } };
}

export function resolveChildTaskContext(sessionId: string | undefined, inherited?: string): string | undefined {
	const prefix = inherited ?? (sessionId ? registry().get(sessionId)?.taskPrefix : undefined);
	if (prefix === undefined) return undefined;
	if (typeof prefix !== "string") throw new Error("Child task context requires a text prefix.");
	const bytes = Buffer.byteLength(prefix, "utf8");
	if (bytes > MAX_TASK_CONTEXT_BYTES) throw new Error(`Child task context is ${bytes} UTF-8 bytes; the limit is ${MAX_TASK_CONTEXT_BYTES}.`);
	return prefix;
}

export function prepareChildTask(task: string, prefix: string | undefined): string {
	return (resolveChildTaskContext(undefined, prefix) ?? "") + task;
}

export function writeRetainedChildTaskContext(directory: string, prefix: string | undefined): void {
	if (prefix === undefined) return;
	resolveChildTaskContext(undefined, prefix);
	writePrivateAtomicJson(path.join(directory, RETAINED_FILE), { taskPrefix: prefix });
}

export function readRetainedChildTaskContext(directory: string | undefined): string | undefined {
	if (!directory) return undefined;
	const file = path.join(directory, RETAINED_FILE);
	if (!fs.existsSync(file)) return undefined;
	if (fs.statSync(file).size > MAX_TASK_CONTEXT_BYTES * 6 + 64) throw new Error("Retained child task context exceeds its serialized bound.");
	const value: unknown = JSON.parse(fs.readFileSync(file, "utf8"));
	if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).length !== 1 || !("taskPrefix" in value) || typeof value.taskPrefix !== "string") throw new Error("Retained child task context requires only a text taskPrefix.");
	return resolveChildTaskContext(undefined, value.taskPrefix);
}
