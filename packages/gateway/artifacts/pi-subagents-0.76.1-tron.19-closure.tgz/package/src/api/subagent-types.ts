const KEY = Symbol.for("pi-subagents.subagent-types-renderer.v1");

export type SubagentTypesRenderer = (agents: ReadonlyArray<{ name: string; description: string }>) => string | undefined;

function slot(): { renderer?: SubagentTypesRenderer } {
	const root = globalThis as Record<PropertyKey, unknown>;
	const existing = root[KEY];
	if (existing === undefined) {
		const created: { renderer?: SubagentTypesRenderer } = {};
		root[KEY] = created;
		return created;
	}
	if (typeof existing !== "object" || existing === null) throw new Error("Malformed subagent types renderer registry.");
	return existing as { renderer?: SubagentTypesRenderer };
}

/** Lets the host render the advertised agents as its `subagent_types` section instead of `advertised_subagents`. */
export function registerSubagentTypesRenderer(renderer: SubagentTypesRenderer): { dispose(): void } {
	const store = slot();
	if (store.renderer) throw new Error("A subagent types renderer is already registered.");
	store.renderer = renderer;
	return { dispose() { if (store.renderer === renderer) delete store.renderer; } };
}

export function subagentTypesRenderer(): SubagentTypesRenderer | undefined {
	return slot().renderer;
}
