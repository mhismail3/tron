const scheduledWorkflowStarts = new WeakMap();
/** Transient pre-start callback: the scheduler's durable receipt remains the provenance authority. */
export function bindScheduledWorkflowStart(params, beforeStart) {
    scheduledWorkflowStarts.set(params, beforeStart);
    return params;
}
/** Called immediately after allocation, before any scheduled workflow child can launch. */
export function publishScheduledWorkflowStart(params, runId) {
    scheduledWorkflowStarts.get(params)?.(runId);
}
//# sourceMappingURL=scheduled-workflow-start.js.map