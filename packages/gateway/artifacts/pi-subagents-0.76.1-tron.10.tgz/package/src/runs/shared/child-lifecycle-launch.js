import { publishChildLifecycleHeaderReady, readChildLifecycleDeclaration, writeChildLifecycleDeclaration, } from "./child-lifecycle-declaration.js";
/** Both hosts publish at their create boundary; readiness follows session events, never a polling timer. */
export async function createLifecycleChildSession(factory, launch, lifecycle) {
    if (!lifecycle)
        return factory.create(launch);
    const { ownerDirectory, declaration } = lifecycle;
    const previous = readChildLifecycleDeclaration(ownerDirectory, declaration.producerRunId);
    writeChildLifecycleDeclaration(ownerDirectory, { ...declaration, ...(previous ? { readiness: previous.readiness, lifecycleState: previous.lifecycleState } : {}) });
    let ready = false;
    const publishReady = () => {
        if (ready || !declaration.sessionFile)
            return;
        try {
            publishChildLifecycleHeaderReady(ownerDirectory, declaration.producerRunId);
            ready = true;
        }
        catch (error) {
            // Pi writes a fresh header lazily. Missing/truncated headers remain declared.
            if (!(error instanceof Error) || !error.message.includes("session header is not ready"))
                throw error;
        }
    };
    const session = await factory.create(launch);
    try {
        publishReady();
    }
    catch (error) {
        await session.dispose();
        throw error;
    }
    const unsubscribe = session.subscribe((event) => {
        if (event.type !== "message_update")
            publishReady();
    });
    const prompt = session.prompt.bind(session);
    session.prompt = async (text) => {
        try {
            await prompt(text);
        }
        finally {
            publishReady();
        }
    };
    const dispose = session.dispose.bind(session);
    session.dispose = async () => {
        try {
            await dispose();
        }
        finally {
            unsubscribe();
        }
    };
    return session;
}
//# sourceMappingURL=child-lifecycle-launch.js.map