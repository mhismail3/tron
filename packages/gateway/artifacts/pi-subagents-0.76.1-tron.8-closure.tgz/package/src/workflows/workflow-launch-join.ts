import type { RunWorkflowScriptOptions } from "./scripted-workflow.ts";

/** Upper bound on joining a settled workflow's child launches before its outcome is published. */
export const WORKFLOW_LAUNCH_JOIN_MS = 30_000;

type WorkflowLaunch = RunWorkflowScriptOptions["launch"];

/**
 * A host publishes a workflow's outcome only after every child launch it started has settled.
 *
 * `runWorkflowScript` settles on a stop, reload or timeout without waiting for a launch that is
 * still stopping its child (a launch may ignore its abort), and that launch then records the
 * child's outcome in the workflow's mission and status. Publishing first let an owner that joins
 * the workflow's terminal state (a stopped Tron Home task, a disposing session) move on while
 * those writes were still to come (Tron #1078). The join is bounded so a launch that never
 * settles cannot hold a stopped workflow forever; `join` returns how many it left behind.
 */
export function createWorkflowLaunchJoin(boundMs = WORKFLOW_LAUNCH_JOIN_MS): { wrap(launch: WorkflowLaunch): WorkflowLaunch; join(): Promise<number> } {
	const pending = new Set<Promise<void>>();
	return {
		wrap(launch) {
			return (...args) => {
				const result = launch(...args);
				const settled = result.then(() => undefined, () => undefined);
				pending.add(settled);
				void settled.then(() => pending.delete(settled));
				return result;
			};
		},
		async join() {
			if (pending.size === 0) return 0;
			let timer: ReturnType<typeof setTimeout> | undefined;
			const bound = new Promise<void>((resolve) => { timer = setTimeout(resolve, boundMs); });
			await Promise.race([Promise.allSettled([...pending]), bound]);
			clearTimeout(timer);
			return pending.size;
		},
	};
}
