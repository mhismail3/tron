# Agent Browser command reference

Related docs:

- [`../README.md`](../README.md)
- [`TOOL_CONTRACT.md`](TOOL_CONTRACT.md)
- [`ARCHITECTURE.md`](ARCHITECTURE.md)
- [`ELECTRON.md`](ELECTRON.md)
- [`RELEASE.md`](RELEASE.md)
- [`SUPPORT_MATRIX.md`](SUPPORT_MATRIX.md)

## Purpose

Requires Pi 1.5.0 or newer; official and fork hosts are qualified independently.

Provide a local, repo-readable command reference for the native `agent_browser` tool.

The native `agent_browser` tool passes the upstream command surface through, so the agent needs an accessible local equivalent of that surface. This document is the durable reference the agent can read inside the repository without calling the binary directly.

After updating `pi-agent-browser-native`, fully quit and restart Pi before using the updated tools. `/reload` can retain previously loaded compiled JavaScript even after `dist/` is rebuilt, so it is not a reliable way to pick up package updates.

Tool declarations use the native `browser` namespace and output schemas. Native `structuredContent` carries the same bounded redacted observation as direct output; optional search retains its existing data shape. It does not expose internal replay details or turn image paths into native `image()` input. The five specialized tools are deferred: load them with native `tool_search` or call them from codemode unless the host already selected them. See [canonical observations](TOOL_CONTRACT.md#canonical-observation).

SDK hosts can supply an awaited [`beforeExecute` callback](TOOL_CONTRACT.md#host-execution-hook) to save host state before each browser dispatch. This is a factory option, not a tool argument; normal installations do not need it.

## Upstream baseline

<!-- agent-browser-capability-baseline:start upstream-baseline -->
<!-- Generated from scripts/agent-browser-capability-baseline.mjs. Run `npm run docs -- command-reference write` to update. Do not edit manually. -->

This reference is baselined to the locally installed `agent-browser 0.42.0` command/help surface, audited against vercel-labs/agent-browser@e7519957b9067c541825afa21a792fbe1f483047. Upstream `agent-browser` remains the source of truth for command semantics; this file is the local fallback for Pi agent sessions where direct binary help is blocked or discouraged.

The lightweight drift check is `npm run verify -- command-reference`. Run it whenever the installed upstream `agent-browser` version changes or this reference is edited.

<!-- agent-browser-capability-baseline:end upstream-baseline -->

### Upstream 0.42.0 rebaseline

The recommended upstream is 0.42.0, audited at upstream commit `e7519957b9067c541825afa21a792fbe1f483047`. The stable runtime floor remains 0.35.0, with no version-specific shim. See the [upstream release](https://github.com/vercel-labs/agent-browser/releases/tag/v0.42.0).

- **Launch settings follow each command.** Native 0.42.0 compares the settings a command carries with the running session. An omitted or equal setting changes nothing; a changed launch setting such as `--profile`, `--args`, `--headed`, `--user-agent`, `--proxy`, `--state`, or `--allowed-domains` relaunches the browser while the daemon keeps running. `--relaunch` forces a relaunch when nothing changed. Older supported natives never report a relaunch: 0.41.2 keeps the browser for some changed settings and silently restarts it for others. See [native session settings](https://github.com/vercel-labs/agent-browser/blob/e7519957b9067c541825afa21a792fbe1f483047/docs/content/docs/sessions.mdx#L42-L55) and the [launch-setting table](https://github.com/vercel-labs/agent-browser/blob/e7519957b9067c541825afa21a792fbe1f483047/cli/src/session_settings/spec.rs#L357-L765).
- **The wrapper reports a native relaunch.** A relaunch discards the page and its refs. When native returns `lifecycle.relaunchedBrowser: true`, the result warns that upstream relaunched the browser, names the changed settings, records `about:blank` as the current page, and offers `reopen-page-after-browser-relaunch` with the prior URL. Wrapper-owned managed sessions still reject launch-scoped flags while running; use `sessionMode: "fresh"`. The automatic root browser and explicit `--session` browsers are caller-owned, so their launch flags pass through and native decides. See [running-session launch settings](#wrapper-specific-behavior-worth-knowing).
- **A command that needs no browser no longer launches one.** `read <url>`, `session info`, `stream status`, `get cdp-url`, and `flow list` start the daemon but not the browser, even with `--profile`. Their launch settings are not applied and not kept; the next command that launches must carry them. See [native launch selection](https://github.com/vercel-labs/agent-browser/blob/e7519957b9067c541825afa21a792fbe1f483047/cli/src/native/actions.rs#L2715-L2762).
- **`--no-auto-connect`** returns a session attached with `--auto-connect` to a local launch and overrides `AGENT_BROWSER_AUTO_CONNECT`. See [the flag pair](https://github.com/vercel-labs/agent-browser/blob/e7519957b9067c541825afa21a792fbe1f483047/cli/src/flags.rs#L1141-L1162).
- **Security settings survive a daemon restart.** Native keeps `--allowed-domains`, `--action-policy`, and `--confirm-actions` in an owner-only `<session>.settings` file beside the session socket until `close`. A value you pass replaces the stored one; `--allowed-domains ""` clears it.
- **`--` ends option parsing.** Native stops reading global flags at the first `--`; later tokens are literal command text. `fill <selector> [--] <text>` and `type <selector> [--clear] [--delay <ms>] [--] <text>` use it for text that looks like a flag, for example `fill "#search" -- --json`. `type` now reads `--clear` and `--delay <ms>` as options; older supported natives typed them as text. The wrapper applies the same boundary to session, restore, launch-flag, help, and version detection. See [native parsing](https://github.com/vercel-labs/agent-browser/blob/e7519957b9067c541825afa21a792fbe1f483047/cli/src/flags.rs#L1377-L1382) and [fill/type](https://github.com/vercel-labs/agent-browser/blob/e7519957b9067c541825afa21a792fbe1f483047/cli/src/commands.rs#L507-L563).
- **Batch items reject misplaced global flags.** Put global flags before `batch`. Native 0.42.0 fails an item whose command, navigation, `screenshot`, `snapshot`, or `vitals` slot holds a global flag with `Pass global flags on the outer batch invocation, not inside a batch item.` The wrapper leaves such a row unchanged so the native error is visible. See [the batch check](https://github.com/vercel-labs/agent-browser/blob/e7519957b9067c541825afa21a792fbe1f483047/cli/src/commands.rs#L373-L382).
- **Saved flows are experimental.** `--capture <list>` (only `flow`; environment `AGENT_BROWSER_CAPTURE`) records a session's commands and requests. `flow steps [--json]`, `flow save <name>`, `flow run <name>`, and `flow list [--origin <host>]` inspect, save, run, and list flows stored under `~/.agent-browser/flows` or `AGENT_BROWSER_FLOWS_DIR`. See [saved flows](#saved-flows-experimental).
- **Stricter command handling.** Unknown commands exit with status 1 even with `--help`. Unknown `cookies` operations return an error. `download <sel> <path>` is rejected over `--cdp`, `--auto-connect`, or a provider because the remote endpoint names the saved file. Mouse coordinates and wheel deltas accept finite decimals and reject invalid values. Proxy credentials are percent-decoded, so encode reserved characters (`p@ss` as `p%40ss`).
- On macOS, native also searches `~/Applications` for installed browsers. Native MCP tool calls return parsed CLI JSON in `structuredContent.response`; the [MCP boundary](TOOL_CONTRACT.md#native-mcp-boundary) is unchanged.

### Upstream 0.41.2 qualification

Native 0.41.2 owns timeout-setting continuity, bare `open` launch settings, and browserless-command behavior. `skills get <name> --ref <ref>` loads only the requested reference or template; repeat `--ref` for several files from one skill. It cannot combine with `--all` or `--full`. The core overview routes to references rather than requiring the full guide for every task.

Native checks for newer stable Chrome releases with CVE fixes and reports advisory warnings without blocking browser commands. `AGENT_BROWSER_NO_VERSION_CHECK=1` skips that check and its request to the Chrome Releases blog. The wrapper adds no version-checking or session-restart layer. See the [upstream release](https://github.com/vercel-labs/agent-browser/releases/tag/v0.41.2).

Published npm help includes `--cdp-headers <json>` and `AGENT_BROWSER_CDP_HEADERS`. The wrapper already treats that flag as one global value and redacts it from invocation presentation; native owns discovery and authentication. The [pinned Android source](REFERENCE.md#android--termux) remains separately qualified. The stable runtime floor remains 0.35.0, with no version-specific shim.

### Upstream 0.41.0 rebaseline

The recommended stock npm `agent-browser@0.42.0` includes the capabilities below, with source citations to upstream commit `1453dd37a40c730fe00f592bc32198a896ff8747`. Runtime support still starts at stable 0.35.0 with no upper cap or version-specific emulation. These native changes span [0.39.3](https://github.com/vercel-labs/agent-browser/releases/tag/v0.39.3), [0.39.4](https://github.com/vercel-labs/agent-browser/releases/tag/v0.39.4), [0.40.0](https://github.com/vercel-labs/agent-browser/releases/tag/v0.40.0), and [0.41.0](https://github.com/vercel-labs/agent-browser/releases/tag/v0.41.0).

- Native 0.39.4+ `wait --download <path>` handles downloads that completed before the wait and moves a locally launched browser's downloaded bytes to the requested destination. Native refuses to move files reported by an attached/remote CDP browser. The wrapper still requires on-disk artifact verification; a reported path alone is not success, so supported 0.35.0–0.39.3 natives, which report the path without moving the file, fail as `artifact-missing`. See [native download handling](https://github.com/vercel-labs/agent-browser/blob/1453dd37a40c730fe00f592bc32198a896ff8747/cli/src/native/actions.rs#L11403-L11508).
- Native daemon shutdown removes its own `<session>.config` along with other daemon files, while retaining `.target` and `.log`. This prevents new configuration-file accumulation; it does not sweep all historical orphans or optimize the wrapper's socket-directory scan. Updating this metadata cannot speed an installation already running 0.41.0. See [file ownership](https://github.com/vercel-labs/agent-browser/blob/1453dd37a40c730fe00f592bc32198a896ff8747/cli/src/session_files.rs#L75-L104) and [shutdown cleanup](https://github.com/vercel-labs/agent-browser/blob/1453dd37a40c730fe00f592bc32198a896ff8747/cli/src/native/daemon.rs#L147-L151).
- `batch --bail --omit-command` reduces native JSON output by replacing command arrays with original zero-based indexes. It is not secret redaction: returned values and errors can still contain credentials. See the [batch contract](#batch-auth-confirmations-sessions-chat-dashboard-devices-and-setup) for wrapper handling.
- `network route --body` accepts `--allow-origin <origin>` for cross-origin mock responses and preflights; JSON mock bodies default to `application/json`. For example: `network route https://api.example.com/data --body '{"ok":true}' --allow-origin https://app.example.com`. Native owns CORS behavior; see [the route parser](https://github.com/vercel-labs/agent-browser/blob/1453dd37a40c730fe00f592bc32198a896ff8747/cli/src/commands.rs#L3392-L3415).
- Auto-discovered `./agent-browser.json` accepts only native allowlisted presentation preferences: `headed`, `json`, `debug`, `userAgent`, `hideScrollbars`, `annotate`, `colorScheme`, `maxOutput`, `screenshotQuality`, `screenshotFormat`, and `idleTimeout`. Other runtime settings warn and are ignored; `$schema` is ignored silently. User config, environment, CLI flags, or explicitly selected `--config ./agent-browser.json` retain their native authority. This is upstream config loading, not a new Pi wrapper restriction. See [native config precedence](https://github.com/vercel-labs/agent-browser/blob/d52a5e90c372ec4710c69adc3837ac14bbd852aa/cli/src/flags.rs#L271-L319).
- Native 0.40+ state restoration uses origin-scoped DevTools storage writes rather than page-script setters and writes an origin only while the page stays on it. `state load` reports `skippedOrigins`; `session info` reports `restoreSkippedOrigins` for automatic restore and launch-time `--state`. Default wrapper text shows a nonempty `skippedOrigins` list after `State loaded` and includes `restoreSkippedOrigins` in `session info` runtime metadata; `details.data` and explicit `--json` keep the native fields. Inspect skipped origins instead of assuming every saved origin restored. See [storage restoration](https://github.com/vercel-labs/agent-browser/blob/1453dd37a40c730fe00f592bc32198a896ff8747/cli/src/native/state.rs#L463-L543) and [restore reporting](https://github.com/vercel-labs/agent-browser/blob/1453dd37a40c730fe00f592bc32198a896ff8747/cli/src/native/actions.rs#L7529-L7590).
- Native 0.41 adds finite `mcp call <tool>` invocations and `@agent-browser/sandbox/mcp-tools.json`. **This extension does not support non-help MCP invocations**, including `mcp call`; its current validation rejects them. Session identity, cross-session coordination, credential presentation, and image handling remain unresolved. See the [MCP boundary](TOOL_CONTRACT.md#native-mcp-boundary), not a promise of wrapper support.
- Crossed upstream fixes also cover auth-key preservation, copied-profile crash prompts, process-identity cleanup, Windows output capture, high-DPI/element screenshots, wedged tabs, and pinned-tab ownership. Those are upstream fixes, not wrapper emulation or full Windows qualification. The upstream `@agent-browser/eve` extension's 0.41 tool renaming does not rename this package's Pi tools.

### Upstream 0.39.2 rebaseline

The CLI trust, engine, and transport behavior added across 0.38.2–0.39.2 remains part of the recommended native release.

- CLI HTTPS requests from `read`, `install`, `upgrade`, and `doctor` now support `--ca-cert <path>` on every platform, `--use-system-ca` / `AGENT_BROWSER_USE_SYSTEM_CA` / native config `useSystemCa` for OS roots, and `SSL_CERT_FILE` as a fallback CA file. Certificate and hostname verification stay enabled. These options do not configure remote CDP/provider TLS or extend Linux Chromium's browser CA support to other platforms. See [trust options](#browser-launch-and-runtime-flags).
- `--engine obscura` selects a separately installed experimental engine. Its accessibility, iframe, and screenshot gaps are not Chrome parity. Keep Chrome as the default; inspect the [Obscura limits](#obscura-engine-experimental) before choosing it.
- Native 0.39.1+ does not replay mutating or launch requests after any request bytes were sent and the response was lost. A failed native JSON envelope with `code: "outcome_unknown"` means the command may have run, not that it failed without effects. Inspect the same session's URL, fresh snapshot, and relevant application state before deciding whether to repeat it. The wrapper adds no transport retry.
- Native 0.39.2 rejects hidden, disabled, and off-viewport click/double-click targets instead of reporting false success. Use `scrollintoview <selector>` and fresh refs before clicking an offscreen control; a native success still needs application-state verification. Ambiguous stale-ref recovery now fails rather than selecting another element.
- `--args` / `AGENT_BROWSER_ARGS` preserve commas and negative coordinates inside values. Newlines separate arguments; a comma separates them only before another flag. For example, `"--window-position=-1920,-100\n--disable-features=Translate,HttpsUpgrades"` keeps both values intact.
- Upstream fixes auth-vault hidden-duplicate targeting, CDP attachment persistence, related target/session invalidation, paused network requests, blocked main-document redirects, and invalid/unreadable policy files failing closed. `--auto-connect` can wait up to 30 seconds for Chrome's remote-debugging approval prompt; it does not bypass that prompt.
- Provider updates remain upstream-owned: Browser Use Cloud V4 adds `BROWSER_USE_PROFILE_ID`, `BROWSER_USE_PROXY_COUNTRY`, and `BROWSER_USE_ENABLE_RECORDING`; Kernel's named-profile fix adds `KERNEL_PROFILE_SAVE_CHANGES` to opt into saving changes. No provider credentials or paid cloud launches are needed for ordinary local qualification.

```json
{ "args": ["--use-system-ca", "read", "https://example.com"] }
{ "args": ["--use-system-ca", "false", "read", "https://example.com"] }
```

### Upstream 0.38.1 rebaseline

These observation options arrived in 0.38 and remain available on the recommended release. New options require an upstream release that provides them; the wrapper adds no version-specific emulation.

- `snapshot --delta` returns a nested `snapshot` object: `kind: full` includes `tree`, `refs`, and `revision`; `unchanged` includes `baseRevision` and `revision`; `delta` also includes ref `changes` and an exact `treeChange` line splice. `snapshot --delta --full` resets the native baseline. The wrapper preserves this payload and shows revisions rather than reporting an empty page. Partial results trigger a full native snapshot read for wrapper ref checks without advancing the delta baseline; there is no wrapper revision cache. Wrapper-only search/filter/viewport/diff options use a full tree instead of native delta output.
- Surviving DOM elements retain refs across same-document snapshots. Navigation and replaced page/iframe documents invalidate them. Keep refreshing after page changes; persistent refs do not remove page-target checks or same-batch mutation boundaries.
- `screenshot --if-changed` suppresses unchanged captures. `screenshot --threshold <0-1>` implies it and tolerates that changed-pixel ratio (default 0). Native `changed: false` omits the path: no new file or inline image is reported, even with an explicit destination. Use an ordinary screenshot when every call must save evidence.
- `--input-mode <mode>` sets sticky session pointer behavior (`instant`, `smooth`, or `human`) and can change on a live session. `click <sel> --human` and `drag <src> <dst> --human` override an action. `mouse move <x> <y> --duration <ms> --steps <n> --human --seed <n>` controls timed, reproducible paths (1–240 movement events); browser response time can extend the requested duration.
- `record start` / `record restart` accept `--cursor`, `--contact-sheet`, and `--contact-sheet-threshold <n>` (0–1, default 0.05, implies contact sheet). These options are not path/URL operands. Contact sheets use `<video-stem>.contact-sheet.png`, contain timestamped visual changes, and remain pending until stop; reported sheets join `details.artifacts` as images and are attached after verification. The sheet's destination is reserved alongside its video until stop/close, including transcript replay and same-batch/output-path alias checks. After direct restart, the previous take's known sheet is shown with disk evidence but remains unverified because native restart omits its terminal receipt; use stop then start when both completed artifacts must be verified. The 0.38.1 cursor overlay stays synchronized with drags and timed mouse movement. Screenshots during recording include the overlay; snapshots do not.
- `auth login <name> --no-navigate` uses the prepared top-level login page, checks its origin against the effective credential URL, and permits submit-triggered navigation. Saved and plugin credentials support the same username/password/submit selector overrides; use native auth rather than implementing a second login flow.
- Native WebMCP discovery emits bounded catalog updates on discovery/change, including names, descriptions, origin, and frame IDs. The wrapper surfaces these as untrusted page data and keeps `data.webmcp`; `details.webMcpCatalog` also preserves updates consumed by helper reads during that call. It never reuses a prior call's catalog. Request full schemas with `webmcp list [tool] [--frame <frame-id>]`; for one relevant tool, use `webmcp list set_message --frame <frame-id>`. Upstream owns CDP recovery, normalized dropdown labels, recording frame pacing, and 0.37.1 Windows headless desktop isolation.

Examples through `agent_browser`:

```json
{ "args": ["snapshot", "-i", "--delta"] }
{ "args": ["screenshot", "--if-changed", "--threshold", "0.01", "shots/current.png"] }
{ "args": ["--input-mode", "human", "click", "@e4"] }
{ "args": ["record", "start", "demo.webm", "--cursor", "--contact-sheet"] }
```

### Upstream 0.37.0 rebaseline

This release keeps the stable 0.35.0 floor and no upper version cap.

- `record start` / `record restart` accept command-local `--fps <n>` before, between or after path/URL operands (1–60, default 30). WebM uses VP8/libvpx; MP4 uses H.264/libx264. Other extensions are handed to ffmpeg; extensionless paths are rejected. Native startup validates the path, rate and ffmpeg availability.
- Recording uses the current active page without replacing its DOM/JavaScript state unless a URL is supplied. The wrapper still conservatively requires a fresh snapshot after dispatched starts and URL-bearing restarts to protect older supported natives; this is not evidence that a page changed. FPS alone neither chooses another tab nor makes a restart invalidate refs.
- Successful navigation may advertise page-provided WebMCP tools. The wrapper shows the native positive hint and retains `data.webmcp`; absent, unavailable or empty results add no hint.
- Native `tab new` and `click --new-tab` apply session user agent, headers, HTTP credentials, init scripts, routes and emulation before the first document loads. The wrapper adds no tab-setup engine.

### Upstream 0.36.0 rebaseline

The 0.36.0 release adds experimental page-provided WebMCP tools while preserving the stable 0.35.0 runtime floor.

- `webmcp list` discovers tools registered by the current page. `webmcp invoke <tool>` accepts JSON or file input, frame selection, detached execution, and a timeout; `webmcp result <id>` waits for a detached call and `webmcp cancel <id>` cancels one.
- Locally managed Chrome enables WebMCP by default. `--no-webmcp`, `AGENT_BROWSER_NO_WEBMCP`, and upstream config `noWebmcp` disable it; attached browsers, remote providers, Lightpanda, Safari/iOS, and older Chrome builds may return `webmcp_unsupported` instead. The wrapper treats `--no-webmcp` as launch-scoped.
- `webmcp list` is read-only. Because `invoke`, `result`, and `cancel` can run page code that mutates, rerenders, or navigates, the wrapper rechecks the live page and invalidates prior page-scoped refs. A detached call that remains pending keeps the page target unverified, as does a failed `result` / `cancel` attempt while that target is unknown; settle or cancel it successfully, or use the `verify-page-target-after-pending-webmcp` (`get url`) next action / explicit navigation before taking a fresh snapshot. In `batch --bail`, put `get url` between a completed WebMCP mutation and `snapshot -i`.
- `skills get webmcp-gen` loads the bundled workflow for creating `webmcp.init.js` and validating it against the existing UI. External MCP clients can opt into page tools with `mcp --tools core,webmcp`; the native Pi wrapper continues to use direct `args` rather than starting an MCP server.
- Upstream also updates its separate Eve integration, dependency resolutions, and Lightpanda launch arguments. This wrapper adds no Eve layer or compatibility shim.

### Upstream 0.35.2 rebaseline

Upstream 0.35.2 hardens the standalone dashboard against DNS rebinding and cross-origin access. `dashboard start --allowed-origins <origins>` accepts comma-separated exact HTTPS reverse-proxy origins, with `AGENT_BROWSER_DASHBOARD_ALLOWED_ORIGINS` as the environment equivalent; the wrapper keeps this local lifecycle command sessionless. The release also fixes root remote CDP WebSocket URLs that contain query strings without requiring a wrapper shim.

### Upstream 0.35.1 rebaseline

The 0.35.1 baseline is a bug-fix release with no new commands or flags. Browser-backed calls accept stable `agent-browser` versions at or above the 0.35.0 floor.

- Snapshot diffs reset element-ref numbering for each diff, invalidate refs across URL navigation, and preserve previous refs when a diff fails.
- Stream URL events now follow the active main frame across full-document, History API, fragment, and active-tab changes while ignoring child frames and background tabs.
- The Windows ARM64 launcher prefers a native executable and falls back to the published x64 binary through Windows emulation.
- `rustls-webpki` and `quinn-proto` received upstream dependency updates.

### Upstream 0.35.0 rebaseline

The 0.35.0 release is the current runtime floor and adds private proxy CA trust plus one bundled workflow skill.

- `--ca-cert <path>` / `AGENT_BROWSER_CA_CERT` loads a PEM bundle or DER certificate into an isolated NSS trust store for locally launched Linux Chromium. Normal hostname, validity, and unrelated-authority checks remain enabled. Equivalent certificate content reuses Chromium; changed content relaunches it. `--no-ca-cert` / `AGENT_BROWSER_CLEAR_CA_CERT` clears retained trust.
- For browser CA trust, use a fresh managed session. The wrapper treats `--ca-cert` and `--no-ca-cert` as launch-scoped for managed browser planning, disables automatic managed restore when CA trust is enabled, and passes caller-selected certificate paths through unchanged. Browser CA trust rejects profiles, CDP/auto-connect, providers, non-Chrome engines, `--ignore-https-errors`, macOS, or Windows, and requires `certutil` (`install --with-deps` installs it on supported Linux systems). CLI HTTPS trust is separate and available on every platform from 0.39.0; see [the current baseline](#upstream-0392-rebaseline).
- `skills get protected-vercel-deployments --full` loads the bundled short-lived Trusted Sources OIDC workflow. It uses `vc project token` and the `x-vercel-trusted-oidc-idp-token` header, avoids persisting tokens, and hands dashboard-only access-control changes to an authorized human.
- The release also restores ARM64 build artifacts; no wrapper shim is needed.

### Upstream 0.34.0 rebaseline

The 0.34.0 release added persistent session-to-tab binding for shared Chrome sessions. It is below the current 0.35.0 runtime floor: before browser-backed work, the extension caches one `agent-browser --version` check per cwd/PATH and fails below-floor or malformed versions with expected/observed version details. Plain help/version, close recovery, and sessionless local setup/diagnostics remain available.

- Named sessions on `--cdp` or `--auto-connect` remember their CDP target across commands and daemon restarts. CDP target ids from `tab list --json` are accepted as tab refs and stay stable across daemon restarts, unlike `t<N>` ids.
- `--pin-tab` (`AGENT_BROWSER_PIN_TAB`) is sticky per session and is not launch-scoped: pass it once, including on an already-live session, so a closed bound tab fails with `tab_gone` instead of adopting a neighbor. JSON includes `code=tab_gone`, `data.targetId`, and optional sanitized `data.lastUrl`; batch exposes the same recovery object under `result`. Recover with `tab new` or `tab list`. `--no-pin-tab` turns the pin off again. Optional booleans use separated tokens (`--pin-tab false`).
- This wrapper classifies `tab_gone` as `failureCategory: "tab-gone"` and returns `list-tabs-after-tab-gone` plus `open-tab-after-tab-gone`. `tab list` presentation includes `target=<id>` when upstream reports `data.targetId`.
- Doctor no longer hangs on Chrome version detection. The Remote Agent Browser provider guide is upstream documentation only; this wrapper adds no new provider mode.

### Upstream 0.33.2 rebaseline

The 0.33.1–0.33.2 releases harden daemon lifecycle and live streaming without new core page commands. Package 0.4.1 targeted exactly `agent-browser 0.33.2`: before browser-backed work, the extension caches one `agent-browser --version` check per cwd/PATH and fails a mismatch with expected/observed version details. Plain help/version, close recovery, and sessionless local setup/diagnostics remain available.

- 0.33.1 ships a default daemon idle timeout of 1 hour (`AGENT_BROWSER_IDLE_TIMEOUT_MS`, default `3600000`; `0` disables). Sessions without a restore key discard transient cookies/tabs on idle shutdown. Headed, Safari/iOS WebDriver, and user-attached browsers are exempt from that default. Tab recovery also revives Memory Saver-discarded tabs on connect/switch/close and reports recovery fields such as `revived` / `dialogBlocked` / `activeTabRevived`.
- 0.33.2 makes stream frame delivery latest-wins, prioritizes input over frame writes, adds per-client `maxFps` / ack pacing, and adds `AGENT_BROWSER_STREAM_QUALITY`, `AGENT_BROWSER_STREAM_MAX_WIDTH`, and `AGENT_BROWSER_STREAM_MAX_HEIGHT` for screencast bandwidth control.
- This wrapper keeps its managed-session idle override and enables transcript- and checkout-scoped `AGENT_BROWSER_RESTORE` for wrapper-owned implicit sessions so browser state can survive relaunch, reload, and `/resume`; set `PI_AGENT_BROWSER_MANAGED_SESSION_RESTORE=0` to disable it. Explicit sessions, restore/state paths, config, file access, launch arguments, environment, local pages, and close arguments pass through unchanged. Session/state lists keep every upstream row and restore identifier visible. Managed daemon inspection only coordinates the wrapper's automatic restore lifecycle.

### Upstream 0.33.0 rebaseline

The 0.32.3–0.33.0 releases add HAR body capture, fix semantic locators, and ship accessibility audits:

- 0.32.3 embeds text response bodies in HAR captures by default and adds `network har start --content <mode>` with `text` (default), `all`, and `none`. It also ships the `derive-client` skill for recording traffic and generating a standalone API client from HAR data.
- 0.32.4 makes `find role` match implicit ARIA roles and browser-computed accessible names (for example `find role heading text --name` against `<h2>`, lists, and banners), keeps case-insensitive substring name matching by default, preserves locator detail in element-not-found errors (`Names seen: …`), and aligns advertised `find` actions to `click, fill, check, hover, text`.
- 0.33.0 adds `a11y [url]` axe-core accessibility audits (`--tags`, `--selector`, structured JSON) with an embedded offline engine, plus a native fix that revives discarded tabs on tab switch instead of hanging the daemon.

This wrapper classifies 0.32.4+ locator-detail misses as `selector-not-found`, treats HAR `--content` and a11y `--tags` as command-scoped value flags, renders compact `a11y` summaries, and documents the skill/HAR/a11y surfaces. No Eve-specific Pi runtime is added.

### Upstream 0.32.2 rebaseline

The 0.32.1 and 0.32.2 releases only update the separate `@agent-browser/eve` integration; the CLI/help/schema surface is unchanged:

- 0.32.1 standardized lowercase eve branding and widened compatibility beyond the original pinned peer range.
- 0.32.2 targets eve 0.25.1+, adopts eve's source/dist extension manifest, updates its example to stable AI SDK packages, and aligns tests with eve's scoped config registry.
- This Pi extension still does not bundle `@agent-browser/eve` or add an eve-specific input mode.

The current audit also closes a command-reference/presentation gap for upstream `read [url]`, which has existed since 0.30.0: the capability baseline now samples `read --help`, native results render `data.content` instead of only the fetched URL, explicit fetch metadata cannot replace the active browser tab target, and `read --timeout <ms>` extends the wrapper subprocess budget across upstream's per-request `.md` and ancestor-`llms.txt` fallback sequence.

### Upstream 0.32.0 rebaseline

The 0.32.0 rebaseline hardens domain containment and fixes completed-page waits without adding a new native Pi input mode:

- `--allowed-domains <list>` now contains request traffic across pages, iframes, workers, service workers, shared workers, and popups. Chromium `RTCPeerConnection` is disabled while containment is active to prevent WebRTC bypasses.
- The wrapper treats argv-supplied `--allowed-domains` as launch-scoped. Use `sessionMode: "fresh"` for a fresh local Chrome context; upstream owns containment and incompatible-mode rejection, and the wrapper passes its result through unchanged.
- `wait --load load` and `wait --load domcontentloaded` now resolve immediately when the current document already reached the requested state instead of waiting for a future lifecycle event. The wrapper still treats `waited:timeout` as inconclusive rather than success.
- Upstream also publishes `@agent-browser/eve`, a separate Eve extension with namespaced browser tools and sandbox helpers. It is not bundled by this Pi extension and does not change the native `agent_browser` schema.

### Upstream 0.31.2 rebaseline

The 0.31.2 rebaseline adds a WebGPU launch preset and periodic restore-state autosaves:

- `--webgpu` (also `AGENT_BROWSER_WEBGPU`; upstream config accepts `"webgpu": true`) enables the upstream platform preset. Native calls preserve project/user config plus explicit `--config` and `AGENT_BROWSER_CONFIG`. It uses Metal on macOS, D3D on Windows, and SwiftShader software Vulkan on Linux. The Pi wrapper treats it as launch-scoped, so use `sessionMode: "fresh"` after an implicit session exists; `--webgpu false` explicitly disables a config/environment default.
- WebGPU requires a local browser launch. Upstream rejects enabled WebGPU with `--cdp`, `--auto-connect`, or `-p` / `--provider`. Use `doctor --webgpu` to pixel-check rendering and screenshot capture; use `doctor --webgpu --headed` when validating the headed capture path.
- Headless WebGPU screenshots work on macOS. Upstream documents black headless WebGPU canvas captures on Windows and Linux even when in-page rendering succeeds; Windows needs a logged-in headed desktop, while Linux can use `--headed` with automatic Xvfb unless `AGENT_BROWSER_NO_XVFB=1`. Linux software rendering also needs `libvulkan1` and `mesa-vulkan-drivers`.
- Restore-enabled sessions now save periodically while the browser remains open, including idle page-driven cookie/storage changes. `AGENT_BROWSER_AUTOSAVE_INTERVAL_MS` defaults to `30000`; `0` disables periodic saves but keeps native close saves. The existing `--restore-save` policy still controls whether automatic saves are allowed. For wrapper-owned headed launches, this extension defaults the interval to `0` because upstream 0.33.2 collects multi-origin storage through visible temporary tabs; upstream exempts headed browsers from idle shutdown, so direct window close can lose newer state unless an explicit interval was set before launch. The wrapper retains the effective launch-time interval across resume and rejects changes in either direction on a running wrapper-owned headed daemon until close plus a fresh launch.
- Upstream MCP `open` and `doctor` tools now expose typed WebGPU fields. This Pi extension keeps `args` as the thin CLI-parity path; `mcp --help` remains sessionless, while bare long-running MCP server startup is intentionally rejected in a one-shot Pi tool call.

### Upstream 0.31.1 rebaseline

The 0.31.1 rebaseline is a React bugfix release: `react tree`, `react inspect <id>`, and `react suspense` now pick the `react-dom` renderer with mounted fiber roots instead of hardcoding renderer id `1`. This fixes empty React trees on Next.js 16.3 / Turbopack / RSC pages. No CLI/help/schema surface changed, so the wrapper only updates baseline evidence and keeps the 0.31.0 restore/session handling below.

### Upstream 0.31.0 rebaseline

The 0.31.0 rebaseline adds restore workflow and namespace/session lifecycle surfaces: `--restore [name]`, `--restore-save <policy>`, restore check flags, `--namespace <name>`, `session id`, and `session info`. The wrapper parses those globals, keeps `--namespace` before `--session`, carries namespace context through managed-session probes and state, and keeps `session id` / `session info` sessionless. Use `agent_browser` with `args: ["session", "id", "--scope", "worktree", "--prefix", "my-skill"]` to derive reusable session ids from inside Pi; use `--restore=<key>` when passing an explicit key that could be confused with a command word.

Runtime probes retain the 0.30.1 `wait --url` fix: `wait --url "**/dashboard"` succeeds after a `pushstate /dashboard`, so URL assertions use native `wait --url` with exact or glob patterns. Upstream 0.32.4 aligns advertised `find` actions with the dispatcher: `click, fill, check, hover, text` only—use top-level `uncheck <selector-or-ref>` (and `type` / `focus`) instead of `find ... uncheck|type|focus`. One older caveat still stands: `wait <selector> --state hidden|detached` remains advertised by some help paths but fails at runtime, so keep `wait --fn` disappearance guidance.

### Upstream 0.29.1 rebaseline

The 0.29.1 rebaseline added no new core browser CLI commands. It captured upstream's new hosted-sandbox helper package and install behavior:

- `@agent-browser/sandbox` is the upstream helper package for Eve and Vercel Sandbox workflows. It is not bundled by this pi extension; load `skills get vercel-sandbox --full` when a task needs that hosted-sandbox guidance.
- Fresh Eve and Vercel Sandbox helpers install Chromium system dependencies by default; pass `installSystemDependencies: false` only when the sandbox image already has those libraries.
- `install --with-deps` exits nonzero when the package manager cannot install required browser libraries (`install --with-deps exits nonzero`).

### Upstream 0.28.0 rebaseline

The 0.28.0 rebaseline tracks new local/infra upstream surfaces and does not change core browser-command semantics. New agent-facing surface captured by the capability baseline:

- `mcp` starts a local MCP stdio server exposing agent-browser tools. It is intended for external MCP clients that spawn `agent-browser mcp` as a subprocess; an agent inside pi would not normally invoke it, and the wrapper treats it as sessionless (no managed browser session injected).
- `plugin add <ref>`, `plugin [list]`, `plugin show <name>`, and `plugin run <name> <type>` manage configured plugins (added from npm or GitHub); all are sessionless in the wrapper. Current native defaults `plugin add` to `~/.agent-browser/config.json`; `plugin add <ref> --project` selects `./agent-browser.json`, which must be loaded explicitly with `--config`.
- `auth login <name> --credential-provider <plugin>` resolves credentials just-in-time from a configured credential plugin (for example, a vault); credentials are not saved locally.
- `AGENT_BROWSER_PLUGINS` is a JSON plugin registry override.

The wrapper adds no compatibility shim for older upstream releases. Non-help MCP calls currently fail wrapper validation, including the finite forms added later; see the [MCP boundary](TOOL_CONTRACT.md#native-mcp-boundary).

### Upstream 0.27.3 install-only rebaseline

The 0.27.3 rebaseline is an install-only compatibility update: upstream changed Windows ARM64 installation fallback behavior and did not change the CLI/help surface or browser-command semantics. This wrapper adds no compatibility shim for older upstream releases. The wrapper must still not hide these prior upstream fixes:

- click reliability: upstream now scrolls off-viewport elements before coordinate resolution, handles JavaScript dialogs promptly, recovers mouse state after dialog-opening clicks, and reports overlay interception before dispatching input
- frame-scoped CSS selectors and waits, including cross-process iframe click-coordinate translation
- wait timeout handling: documented 25s default, honored `--timeout` across wait variants, and appropriate client read budgets for long waits; the native wrapper forwards explicit long waits and derives a subprocess watchdog when top-level `timeoutMs` is omitted
- form commands: `find label` matches `aria-label` / `aria-labelledby`, `select` errors when no option matches, and `type` parses `--clear` / `--delay` instead of typing them as literal text
- warm CLI command latency and batch daemon respawn/retry improvements
- GNU Linux release artifacts pinned to glibc 2.28

## Core mental model

Use `agent_browser` for one native command and `batch --bail` with JSON-array stdin for a fixed sequence. Pi codemode scripts call `agent_browser` for loops, branches, and aggregation over the same persistent browser. Return to the model when observation needs judgment. All native command families remain available; there is no public job DSL or isolated script input.

`agent_browser` accepts `{ args, stdin?, outputPath?, timeoutMs?, sessionMode? }`. Tokens exclude the binary and shell syntax. Stdin is accepted for native batch, `eval --stdin`, and `auth save --password-stdin`. Omit `--json` for prose backed by structured upstream JSON; include `--json` or `--json true` for a parseable canonical observation. Explicit `--json false` preserves native text for standalone commands and batch, including leading/trailing whitespace and line breaks in data, complete spills and exports, without trusted row/confirmation/page-target/artifact receipts. `outputPath` success/failure notices append prose without reparsing JSON-looking page text. Repeated flags follow upstream's last-wins semantics; batch-row flags remain native operands and do not select outer output mode. See [the output contract](TOOL_CONTRACT.md#wrapper-json). Help/version remains native text. Empty stdin batch rows (`[]`) pass through unchanged and native execution skips them; `[""]` still fails as an unknown command. `--bail` stops at that failure, while a non-bail batch retains later native results. A nonzero process exit that supplies stderr instead of JSON retains that native error and redaction, with parse diagnostics secondary. Zero-exit malformed JSON remains a strict failure.

```json
{ "args": ["open", "https://example.com"] }
{ "args": ["snapshot", "-i"] }
{ "args": ["batch", "--bail"], "stdin": "[[\"get\",\"title\"],[\"get\",\"url\"]]" }
```

Ordinary calls share the root Pi parent/subagent browser unless native config, an explicit identity, or an active managed/fresh browser selects otherwise. `sessionMode: "fresh"` intentionally rotates the managed browser; explicit native session choice still wins. Keep profile/provider/attachment launch flags on first launch. Native launch environment/config can submit the full launch configuration again on each invocation: mixing an executable default with first-call-only profile/user-agent flags can replace the browser when those flags disappear. Use a consistent native launch configuration; the wrapper passes it through unchanged and omits automatic Chrome startup args when native environment/config already supplies local launch defaults. After a failed fresh call, inspect `managedSessionOutcome` rather than guessing which browser is current.

A cooperating-process lock covers each direct helper/action sequence, keyed by actual socket context, canonical namespace, and session. Independent identities remain concurrent; direct namespace-wide close barriers matching work. Restart all participants onto the new version. This is not rollback or protection against human/external-client navigation, and separate tool calls still need coordination.

`outputPath` saves result data or recording receipts, including failed recording evidence, through the existing writer. The visible observation carries the `outputFile` receipt (`status`, `path`, `source`, and `bytes` or `error`), including compacted and `--json` results; confirm the save from it instead of reading the full spill. Keep it distinct from browser artifacts; aliasing fails without overwriting the artifact. `timeoutMs` bounds the requested subprocess; managed policy inspection has its separate budget. Unknown mutation outcomes require inspection before retry.

### Loops and branches in codemode

For loops, branches, or aggregation, call `agent_browser` from a Pi codemode script; enable codemode with `--tools +codemode` or `defaultTools`. `tools.agent_browser({ args, stdin? })` resolves to the structured observation: check `success` before using `data`, and return only the fields the model needs.

```js
const titles = [];
for (const url of ["https://example.com", "https://example.org"]) {
	const opened = await tools.agent_browser({ args: ["open", url] });
	if (!opened.success) return opened;
	const title = await tools.agent_browser({ args: ["get", "title"] });
	titles.push({ url, title: title.data?.title });
}
return titles;
```

Each script call is an ordinary `agent_browser` call against the same persistent browser, with the same identity, ordering, artifact, and recovery rules as a direct call. Use `image(await tools.read({ path }))` to show a saved screenshot to the model. See [0.7 migration](TOOL_CONTRACT.md#07-migration).

### Advanced tools

The five specialized tools register deferred. Load one for the next model call with Pi's native `tool_search` (active through `--tools`, `defaultTools` `+tool_search`, or `setActiveTools`):

```json
{ "query": "agent_browser_qa" }
```

Codemode scripts call deferred tools directly (`await tools.agent_browser_qa({ ... })`) without loading them. Loading is additive and uses native Pi selected-tool history. An explicit CLI `--tools` allowlist must include every deferred tool it wants available. The tools take flat input:

| Tool                           | Example                                                                                                 |
| ------------------------------ | ------------------------------------------------------------------------------------------------------- |
| `agent_browser_action`         | `{ "action": "select", "locator": "role", "role": "combobox", "name": "Flavor", "value": "chocolate" }` |
| `agent_browser_qa`             | `{ "url": "https://example.com", "expectedText": "Learn more" }`                                        |
| `agent_browser_electron`       | `{ "action": "list", "query": "code" }`                                                                 |
| `agent_browser_source`         | `{ "selector": "#save", "componentName": "SaveButton" }`                                                |
| `agent_browser_network_source` | `{ "requestId": "req-1", "url": "/api/fail" }`                                                          |

Native commands remain in `agent_browser`; advanced objects are neither nested batch rows nor nested fields on that tool. If a recovery action names an inactive advanced tool, enable it before calling its exact flat payload.

### Debug, diff, stream, dashboard, and chat families

Upstream also exposes non-core families (`network`, `diff`, `trace` / `profiler` / `record`, `console` / `errors` / `a11y` / `highlight` / `inspect` / `clipboard`, `stream`, `dashboard`, `chat`, and related subcommands). The wrapper still owns argv planning, `--json`, managed sessions where applicable, artifact metadata, and model-facing presentation: structured results are compacted and scrubbed in `extensions/agent-browser/lib/results/presentation.ts`, and echoed argv uses the same `redactInvocationArgs` rules as core commands (see [`TOOL_CONTRACT.md`](TOOL_CONTRACT.md#details) for the field contract). Deterministic fake-upstream coverage for representative JSON shapes and redaction lives in `test/agent-browser.extension-validation.test.ts` under `agentBrowserExtension passes through non-core network debug diff stream dashboard and chat families`.

## Recommended workflow

Keep routine browser work simple: open a page, inspect it with `snapshot -i`, interact with current `@ref` values from that snapshot, then inspect again. Re-run `snapshot -i` after navigation, scrolling, rerendering, or other major DOM changes because refs can become stale.

### Normal browse flow

```json
{ "args": ["open", "https://example.com"] }
{ "args": ["snapshot", "-i", "--urls"] }
{ "args": ["click", "@e2"] }
{ "args": ["snapshot", "-i"] }
```

### Headed demo, WebGPU, and local-page checks

Use upstream's global `--headed` flag on the first launch when the user needs to watch the browser. Because headed/headless state belongs to the browser launch, use `sessionMode: "fresh"` when a managed session may already exist or when changing from a previous headless run.

```json
{ "args": ["--headed", "open", "https://example.com"], "sessionMode": "fresh" }
{ "args": ["screenshot", "/tmp/agent-browser-headed-check.png"] }
```

`--headed` is launch-scoped, including explicit `false`, so changing an active managed session between headed and headless requires `sessionMode: "fresh"`. Wrapper-owned headed launches default `AGENT_BROWSER_AUTOSAVE_INTERVAL_MS` to `0` to avoid upstream 0.33.2's visible temporary storage-collector tabs and related daemon-policy delays, and record the effective launch-time interval and reapply it to every helper/follow-up subprocess, still-owned off-current session, Electron cleanup close, and reload/resume so daemon configuration remains stable. Native close still saves, but direct window close can lose newer state because headed browsers are exempt from idle shutdown; set an explicit interval before launch when periodic preservation matters, and close then relaunch fresh to change an existing daemon.

For a WebGPU page, enable the launch preset before the first navigation. Treat it as local-launch-only and use a fresh managed session when changing an existing browser:

```json
{ "args": ["--webgpu", "open", "https://webgpu.github.io/webgpu-samples/?sample=helloTriangle"], "sessionMode": "fresh" }
{ "args": ["screenshot", "/tmp/webgpu.png"] }
```

Run `{ "args": ["doctor", "--webgpu"] }` before trusting a black or blank WebGPU capture. On Linux/Windows capture paths, use `doctor --webgpu --headed` and follow upstream's platform requirements; do not combine enabled WebGPU with `--cdp`, `--auto-connect`, or provider launches.

On a successful first/fresh local wrapper-managed headed launch, including a launch inside `batch`, whose upstream lifecycle proves a browser launched, `details.browserWindow` reports `{ mode: "headed", ownership: "wrapper-managed", sessionName, visibility: "unverified" }` and the result adds one visible login handoff. CDP, auto-connect, provider, and Electron attachments suppress this local-window claim. Treat it as headed-launch evidence, not proof that a window is visible on the user's display. Remote shells, containers, virtual framebuffers, or upstream/provider-owned browser hosts can still put the window somewhere the user cannot see. If visible, let the user complete the login and continue the same wrapper session with `sessionMode: "auto"`; otherwise gather evidence with `screenshot`, `tab list`, `get url`, or `snapshot -i`, then fix display/profile/provider setup.

For local fixtures, remember that `localhost` and `127.0.0.1` are resolved from the browser host, which may differ from the shell that started a temporary HTTP server. `net::ERR_EMPTY_RESPONSE` on `http://localhost:<port>` usually means the browser could not reach that server, not that the page rendered blank. Use a host-reachable HTTP(S) address or a `file://` fixture when upstream browser settings allow it. Local paths, artifact destinations, and top-level `outputPath` are caller-owned and pass through normally.

For an explicit `--session`, content-bearing reads and interactions first run a session-scoped `get url`; missing or stale transcript page state is not trusted, and a failed probe stops the requested content command. When a launch-flagged call targets a confirmed inactive caller-owned session, remembered-tab selection and the page probe wait for the requested command to launch that browser, including after transcript reload. After dispatch, the stopped browser's physical tab and refs are not inherited. Successful commands observe the replacement page; a failed or unobserved launch leaves the target unknown. Flagless calls and running browsers keep their checks. Calls to the same canonical namespace/session are serialized through that probe and command. Nested `batch` steps remain unsupported; raw batch command strings mirror upstream's ASCII-space tokenizer, including quoting and backslash handling.

Temporary HTTP servers and their port/process lifecycle stay outside the native tool. Extension maintainers running real-upstream contract tests can reuse `startAgentBrowserContractFixtureServer()` in [`test/helpers/agent-browser-harness.ts`](https://github.com/fitchmultz/pi-agent-browser-native/blob/main/test/helpers/agent-browser-harness.ts) instead of ad-hoc `python3 -m http.server` processes.

### React, SPA, and Web Vitals flows

React introspection requires the React DevTools init hook to be installed before the page's first JavaScript runs. Launch or relaunch that browser session with `--enable react-devtools`; if the implicit session is already active, use `sessionMode: "fresh"`.

```json
{ "args": ["open", "--enable", "react-devtools", "https://example.com"], "sessionMode": "fresh" }
{ "args": ["react", "tree"] }
{ "args": ["react", "inspect", "<fiberId>"] }
{ "args": ["react", "renders", "start"] }
{ "args": ["react", "renders", "stop"] }
{ "args": ["react", "suspense", "--only-dynamic"] }
```

Use `vitals [url]` for Core Web Vitals plus React hydration timing when available, and `pushstate <url>` for client-side SPA navigation without a full reload:

```json
{ "args": ["vitals", "https://example.com"] }
{ "args": ["pushstate", "/dashboard?tab=settings"] }
```

For first-navigation setup, start on `about:blank`, then stage routes, cookies, or init scripts before navigating. The relevant current upstream surfaces are `network route <url> [--abort|--body <json> [--allow-origin <origin>]] [--resource-type <csv>]` and `cookies set --curl <file>`:

```json
{ "args": ["open"], "sessionMode": "fresh" }
{ "args": ["network", "route", "**/*.js", "--abort", "--resource-type", "script"] }
{ "args": ["cookies", "set", "--curl", "/path/to/cookies.txt", "--domain", "example.com"] }
{ "args": ["navigate", "https://example.com"] }
```

### Selector strategy

Prefer targets in this order:

1. Use a current `@ref` from the latest `snapshot -i` for visible interactive controls.
2. After `scroll`, `scrollintoview`, navigation, or any rerender, take a fresh `snapshot -i` before reusing refs.
3. When a target is easiest to describe by accessible name or visible text, use `find` locators such as `role`, `text`, `label`, `placeholder`, `alt`, `title`, or `testid` instead of guessing selector syntax.
4. Use CSS selectors for scoped extraction or stable app-specific hooks when you know they match the current page.

Examples:

```json
{ "args": ["find", "role", "button", "click", "--name", "Close"] }
{ "args": ["find", "text", "Close", "click"] }
{ "args": ["find", "label", "Email", "fill", "user@example.com"] }
{ "args": ["select", "#flavor", "chocolate"] }
{ "args": ["scrollintoview", "@e12"] }
{ "args": ["snapshot", "-i"] }
```

The optional `agent_browser_action` tool preserves stable accessible click/check/fill and unique visible dropdown selection. Enable `action`, then pass flat locator/selector fields. Role/name or label select resolves one current visible native combobox/listbox from a fresh snapshot or the eligible next-call confirmed capture; missing or ambiguous select targets still fail. It does not assume native `find ... select`. A `session` field targets a named browser. `compiledSemanticAction` remains the audit metadata name; `effectiveArgs` identifies the executed ref/command. `uncheck` remains native argv. Selector failures retain exact ref/role candidates and session-aware recovery.

For desktop, contenteditable, or host-controlled rich inputs, treat a semantic `fill` miss or mismatch differently. Active-session role/name fills can execute through one exact current editable `combobox`, `searchbox`, or `textbox` ref before upstream `find` runs. If a later selector miss still finds an exact current editable ref (`searchbox` or `textbox`), `details.richInputRecovery` and visible `Rich input recovery` describe the candidate and append `focus-current-editable-ref*` / `click-current-editable-ref*` next actions. Those actions deliberately do **not** copy the fill text and never press `Enter` or submit. Direct `fill @ref <text>` on contenteditable refs may also append/prepend instead of replacing; when the latest snapshot proves the target is contenteditable, the wrapper verifies `get text` after a successful fill and appends `details.fillVerification` plus `inspect-after-fill-verification` / `verify-filled-value` if the visible text does not match. Use the safe ladder instead: refresh refs, choose the current editable `@ref`, focus or click it, then use `keyboard type` for framework-controlled editors that require real key events. `keyboard inserttext` is paste-like: it can change a DOM value without updating application state, so use it only when later application-state evidence proves the edit was accepted. Do not auto-submit unless the user flow explicitly calls for it.

Do not assume Playwright selector dialects such as `text=Close` or `button:has-text('Close')` are supported wrapper syntax. In particular, current upstream can report successful `scrollintoview text=...` without moving the page, so the wrapper rejects that form before dispatch—directly or in an effective raw/stdin batch row—and shows executable `find text <label> hover` plus snapshot/ref recovery payloads in visible failure text and `details.nextActions`. `scrollintoview ... --help` and `-h` remain native help calls. Use `scrollintoview` with CSS, `xpath=...`, or a current `@e…` ref; use `find` for semantic text targets.

Treat `@eN`, `eN`, and `ref=eN` selector refs as page-scoped. Ref-looking fill/type text, select values, paths, and keyboard/mouse data remain literal. After a successful `snapshot`, the wrapper records the latest refs and page target for that session; getter or mutation ref commands such as `get text @e4`, `click @e4`, `select @e5 chocolate`, or batch steps with old refs fail with `failureCategory: "stale-ref"` when the page target changed or the ref is absent from the latest same-page snapshot. If a session `snapshot -i` fails with `No active page`, the wrapper invalidates prior refs for that session; later mutation-prone `@e…` calls fail before upstream until a successful fresh `snapshot -i` records refs again. Inside effective raw-argument or stdin `batch` steps, the wrapper also walks the full plan in order before spawn: steps whose first token can navigate or mutate set a latch; a later step whose first token is `snapshot` clears that latch for following rows; guarded steps that still mention `@e…` after an uncleared latch fail with the same `stale-ref` bucket without launching upstream. This scan continues after a snapshot even when no refs appear before it: `snapshot -i`, a non-form `click @e1`, then `get value @e2` is rejected. Put another `snapshot -i` after the click or split the batch and inspect before continuing. Same-snapshot form fills and native form-control steps are allowed before a click or submit step, so `fill`, `check`/`uncheck` checkbox or radio refs, checkbox/radio `click`/`tap` refs, `select` combobox refs, then a final submit `click` can run from one snapshot. Split dynamic or autosubmit forms with a fresh snapshot if a control interaction rerenders the targets. Follow the `refresh-interactive-refs` next action (it includes `--session <name>` when needed) and prefer stable `find` or `agent_browser_action` locators when navigation or rerendering is likely. Contract detail: [`TOOL_CONTRACT.md`](TOOL_CONTRACT.md#details) (`refSnapshot`, `refSnapshotInvalidation`).

A successful `click` result means upstream reported a target, not that the app definitely handled the event. For top-level non-Electron direct clicks on `xpath=` targets and eligible current `@e…` refs, the wrapper installs a bounded target-specific DOM-event probe when it can; when upstream reports success but no trusted event reaches the resolved target, it fails the tool and exposes `details.clickDispatch` plus a `Click dispatch diagnostic` line with explicit retry/inspect next actions (no in-page click replay). Raw `find … click` locator calls are not probed because the wrapper has no concrete element before upstream resolves the locator, and document-level probes can falsely fail frame-scoped clicks. Direct `@e…` click probes are role-gated to current snapshot refs whose accessible role is `button`, `checkbox`, `menuitem`, `radio`, `switch`, or `tab`, with a unique role/name in both the saved snapshot and the live candidates. For both ref and XPath candidates, the wrapper requires native `get attr <original-selector> <marker>` to read back a per-probe temporary DOM marker on that candidate. Missing or mismatched identity (including frame/XPath scope mismatches) cleans up the probe and lets the native click run without dispatch verification. Duplicate-name refs pass through without a probe because their old ordinal does not prove target identity. Probe listeners and the window marker self-expire after the call's process-timeout budget plus the existing two-second cleanup grace if a pending decision blocks normal cleanup; collection cancels the timer. This uses no extra browser command while pending. If the probe evidence shows the target is outside a nested scroll container or viewport, `details.clickDispatch.scrollContainer` and `scroll-target-into-view-after-dispatch-miss` point to `scrollintoview <target>` before retry. When the workflow depends on a mutation, use `details.pageChangeSummary`, a wait, URL/text extraction, or a fresh `snapshot -i` before trusting the state; if nothing changed, retry with a current visible ref or stable selector and report the workflow issue. For static local fixtures or debugging where the user explicitly accepts scripted activation, `eval --stdin` can call `document.querySelector(...).click()` to exercise inline handlers and app code; treat that as an untrusted programmatic event, not as evidence that CDP/user-like clicking works. Respect explicit user stop boundaries yourself: if the user says to stop before a final order, post, purchase, or submit action, gather evidence from that page and do not click the final action or use scripted activation to bypass the stop. The wrapper does not infer broad business intent from prompt text; `details.promptGuard` is reserved for concrete artifact-before-close checks. `press`, `key`, `keydown`, and `keyup` accept exactly one key token; focus or click the target first, then run `press Enter` or another single-key command.

Successful `snapshot -i` results can also surface `Possible overlay blockers` when their own refs already show dialog/alertdialog context plus close/dismiss controls, so agents can detect likely obstruction before clicking. When a **top-level** `@e…`/`ref=` click succeeds (not a `click` hidden inside a native batch tool call—the unified command must be `click`), the upstream payload includes `data.clicked`, no `details.clickDispatch` diagnostic fired for the same result, and the wrapper sees `details.navigationSummary.url` unchanged after the same normalization it uses for ref guards (**`#fragment` ignored**), it may run one extra `snapshot -i` and surface `Possible overlay blockers` plus `details.overlayBlockers` (`candidates`, `summary`, and a `snapshot` map that can refresh `refSnapshot`) when that snapshot shows strong modal context (`dialog` / `alertdialog`) **and** up to three close/dismiss-like controls; page-wide words such as privacy, sign in, or banner alone do not trigger it. The URL check compares the session’s prior pinned tab target to `details.navigationSummary.url`. CSS selector clicks do not run this overlay probe. The diagnostic is skipped if the wrapper already applied tab-focus correction or about-blank recovery on that result. Appended `inspect-overlay-state` / `try-overlay-blocker-candidate-*` entries in `details.nextActions` preserve namespace/session context (`--namespace <namespace> --session <name>` when namespaced, otherwise `--session <name>` when the session is named), same as other session-scoped follow-ups. Treat `inspect-overlay-state` as the safe first follow-up; only use a `try-overlay-blocker-candidate-*` next action when the candidate is clearly the control you intend to close. A click that upstream rejects because another element covers the target's click point (`is covered by` … `at its click point`) remains `failureCategory: "upstream-error"`, but receives the same session-aware `inspect-overlay-state` snapshot action. This includes direct `click`, `agent_browser_action` click, raw `find` clicks (including `nth` and omitted default-click actions), and failed native batch rows. That failed-click path does not retry the original click or synthesize a dismiss candidate before a fresh snapshot provides evidence; it is separate from silent input-dispatch failures.

### Extract page data

```json
{ "args": ["read", "https://example.com/docs", "--filter", "authentication"] }
{ "args": ["read"] }
{ "args": ["get", "title"] }
{ "args": ["get", "url"] }
{ "args": ["get", "text", "main"] }
{ "args": ["eval", "--stdin"], "stdin": "document.title" }
```

Use `read [url]` for documentation and other unstructured text. `read <url> --raw` preserves the response body, `read <url> --require-md` requires `text/markdown`, `read <url> --llms <index|full>` reads the nearest ancestor llms index/full file, `read <url> --outline` emits headings, `read <url> --filter <text>` narrows matching sections/headings/links, and `read <url> --timeout <ms>` changes the request timeout. Explicit URL reads prefer markdown, try a `.md` path and nearby `llms.txt` links, then fall back to readable HTML without requiring a Chrome page. The wrapper does not allocate or replace a managed browser for an explicit URL read or all-read batch. It skips page verification, tab/ref changes and timeout page probes; malformed read arguments go to native validation without falling back to a DOM preflight. Caller config and flags remain native-owned. `Read execution` reports source, CLI start and native launch evidence without treating the HTTP read as proof of shared-browser liveness. Use `session info` for that. Native no-browser-effects behavior requires the companion upstream fix; older supported binaries do not guarantee it merely because the wrapper skips helpers. Omit the URL to read rendered active-tab DOM, including current browser auth and client-side state; `--llms` / `--require-md` without a URL instead fetch from the active tab URL. The wrapper renders `data.content` first, retains source/content-type/status/final-URL metadata in `details.data`, keeps fetched URLs from replacing the active browser tab target, and extends its subprocess watchdog for explicit long read timeouts.

When you already know several visible refs or selectors, extract them in one `batch` call instead of many serial getter calls. When a prior snapshot and session are available and the same-page freshness checks apply, ref-consuming calls add one extra `snapshot -i` preflight per top-level call or batch. Batching shares that probe across rows; it does not remove it:

```json
{
	"args": ["batch"],
	"stdin": "[[\"get\",\"text\",\"@e64\"],[\"get\",\"text\",\"@e65\"],[\"get\",\"text\",\"@e66\"]]"
}
```

Prefer `get` and scoped `eval --stdin` for read-only extraction. Getter names are grouped under `get`: use `get title`, `get url`, or `get text <selector>`, not shortcut commands such as `title` or `url`. When upstream reports an unknown command, unknown subcommand, or unrecognized command for a single-token shortcut (`attr`, `count`, `html`, `text`, `title`, `url`, or `value`), the wrapper adds a visible grouped-`get` hint; only `title` and `url` also get exact read-only `details.nextActions` (`use-get-title` / `use-get-url`, with `--session` preserved when the failed call named a session). If another `Agent-browser hint:` (selector dialect or stale-ref recovery) was already appended to the same error text, the getter hint is omitted.

Return the intended JavaScript value from `eval --stdin` instead of relying on `console.log`. In the native pi tool, the JavaScript belongs in the top-level `stdin` field; do **not** write it as a third `args` item such as `{ "args": ["eval", "--stdin", "document.title"] }`. The wrapper tolerates that common misplaced form by moving the trailing token to stdin before spawn, but the explicit `stdin` field is the documented form and avoids ambiguity for multiline snippets. For object-shaped extraction, pass a plain expression such as `({ title: document.title, url: location.href })`; if the result should be kept outside the transcript as a durable file, add top-level `outputPath` (for example `{ "args": ["eval", "--stdin"], "stdin": "({ title: document.title })", "outputPath": "logs/page-title.json" }`). If you send a function-shaped snippet, invoke it explicitly, for example `(() => ({ title: document.title }))()`. When upstream serializes a function result to `{}`, the wrapper can append `Eval stdin hint` and `details.evalStdinHint`. Snippets run in the page's per-tab global scope, so top-level `const`/`let`/`function` declarations persist across calls and later snippets can fail with `SyntaxError: Identifier ... has already been declared`; wrap multi-statement extraction in an IIFE instead of redeclaring names. After a failed `eval`, `back`/`forward`/`reload`, `connect`, `state load`, or `tab` selection, the wrapper probes the live page URL itself and keeps an observed page verified, so follow-up reads do not need a manual `get url` unless the result says the page became unverified; because the failed command may still have changed the document, prior page-scoped refs are invalidated and need a fresh `snapshot -i` before reuse.

On tabbed or hidden-DOM pages, `get text <selector>` reads the upstream-selected match, which may be hidden even when a later match is visible. For non-`@ref`, non-simple-id CSS selectors with multiple matches, including successful `batch` steps, the wrapper may add `Selector text visibility warning`, `details.selectorTextVisibility` (and `details.selectorTextVisibilityAll` for multiple batched warnings), and `inspect-visible-text-candidates` next actions. The warning names the matching `details.nextActions` id so agents know to use a fresher `snapshot -i`, a visible `@ref`, or a more specific selector instead of trusting hidden tab content. If the probe still leaves multiple visible candidates, do not keep reading the broad selector; switch to a current visible `@ref`, add a narrower selector such as a known panel/container id, or use a targeted `eval --stdin` expression that filters for visible elements and returns the intended index/text.

### Run a multi-step flow in one browser invocation

On native 0.40+, add exact `--omit-command` to retain each result's zero-based native `index` instead of echoed `command` arrays. Indexes refer to the original plan, including skipped empty `[]` stdin rows. Raw command arguments still take precedence over stdin. The wrapper restores command attribution internally for ordinary credential redaction, lifecycle/ref state, and artifacts, then omits reconstructed commands from public receipts, JSON, and whole-batch spills.

```json
{ "args": ["batch"], "stdin": "[[\"open\",\"https://example.com\"],[\"snapshot\",\"-i\"]]" }
```

Use exact `batch --bail` when later steps should stop after the first failed command; omit it to continue after errors. `--bail=true` / `--bail=false` are unsupported: upstream treats them as raw command strings and ignores stdin. The wrapper returns shape guidance without running that ignored stdin. Tab recovery does not change caller flags, literal operands, or batch control flow; a failed wrapper tab selection stops before user commands. Both pinned and unpinned mixed failures retain per-step results and failure counts.

For fixed flows, keep native batch rows short around navigation and rerender boundaries. Preserve fail-fast behavior with `--bail` when later work depends on earlier success. Add `wait --url` and/or `wait --text` after navigation-prone clicks; a dispatch receipt does not prove navigation. Multiple same-snapshot fills can precede submit; split when refs must be refreshed.

```json
{
	"args": ["batch", "--bail"],
	"stdin": "[[\"open\",\"https://shop.example/checkout\"],[\"fill\",\"#email\",\"user@example.com\"],[\"click\",\"#continue\"],[\"wait\",\"--url\",\"**/shipping\"],[\"wait\",\"--text\",\"Shipping address\"],[\"screenshot\",\"/tmp/shipping.png\"]]"
}
```

Paced input uses explicit native rows, preserving the former job's behavior without assuming `--delay` equivalence:

```json
{
	"args": ["batch", "--bail"],
	"stdin": "[[\"focus\",\"#prompt\"],[\"keyboard\",\"type\",\"h\"],[\"wait\",\"20\"],[\"keyboard\",\"type\",\"i\"]]"
}
```

For longer text, a codemode script can construct the rows and call native batch; keep the former 200-character pacing bound when porting a job. Add a final `press` only when submission is intended. Fixed waits are not postconditions. Timeout partial progress remains available through the same batch path. See [all job step equivalents](TOOL_CONTRACT.md#07-migration).

For quick smoke/QA checks, enable `qa` and call `agent_browser_qa` with flat fields. It clears enabled network/console buffers and snapshots any page-error residue after the unreliable upstream clear, then opens the target URL and gives immediate post-load console/page-error callbacks a bounded 150 ms settle, waits for page readiness, checks expected text/selector, then inspects fresh network requests, console messages, and page errors only if preceding assertions pass, and can capture an evidence screenshot. Successful reset rows are labeled as reset-scoped diagnostic output. If final page-error rows match a nonempty post-clear baseline, QA is non-pass with “page-error check could not be verified”: identical new errors can replace old rows in the native FIFO buffer without changing the result. Those matches are not proof of new application errors. Definitely new rows, including errors after an empty baseline, count separately as page errors; a clean final buffer can pass. Explicit `checkErrors: false` omits this check for a more limited smoke test. The preset compiles to `batch --bail` so a missing text/selector assertion fails crisply instead of letting slower diagnostics burn the wrapper watchdog. Expected text compiles to bounded visible-text `wait --fn … --timeout 5000` predicates after load so dense pages can pass on visible headings/copy without dumping `body` text; missing text reports a crisp QA failure. Text and control values under `display: none` or `opacity: 0` ancestors, or whose computed visibility is hidden, are excluded even when the control itself has a visible layout box; `display: contents` wrappers and `visibility: visible` overrides still count. The readiness wait defaults to `loadState: "domcontentloaded"`; set `loadState` to `"load"` or `"networkidle"` only when that stricter state is useful and the site is not expected to keep background requests alive. QA network diagnostics classify failed requests by likely impact and list failed rows first in the network preview: actionable document/script/API-style failures fail the preset, while common low-impact browser icon misses such as `favicon.ico` are surfaced as warnings (`qaPreset.warnings`) so they do not fail an otherwise healthy page. Successful QA with no failed checks returns compact model-visible prose (page URL/title when known, checks run, optional screenshot verification) while keeping the full step matrix in `details.qaPreset` and `details.batchSteps`. Failed QA presets report `details.resultCategory: "failure"`, `failureCategory: "qa-failure"`, show compact failure reasons with the full matrix in `details.batchSteps`, and real Pi sessions treat the diagnostic as a failed tool result. Prose output also gets a model-visible result-category line including `Pi tool isError: true`; caller-requested `--json` output keeps the JSON string parseable and relies on the patched `isError` plus `details` fields.

For failed QA, inspect `details.qaPreset.failedChecks` separately from `notRunChecks`: a reported fail-fast error leaves later checks not run, rather than proving their assertions failed. Failure prose leads with the redacted cause and reports received execution coverage; missing timeout receipts mean an unknown executed count. Incomplete receipts without a reported failure are unverified, never proof of a pass or of unreached checks.

The same classification drives plain `network requests` presentation: when any row counts as failed (HTTP status ≥ 400, `failed: true`, or a string `error`), model-facing text starts with a line like `Network failure summary: 0 actionable, 1 benign low-impact (1 total).`, and each preview line can end with an impact tag such as `[benign: low-impact browser icon asset]` or `[actionable: document, script, API, or non-benign request failure]`. When safe request IDs are present, `details.nextActions` adds bounded read-only follow-ups such as `network request <id>`, `agent_browser_network_source` for actionable failed rows, `network requests --filter <path>`, `network requests --clear` before a repro, and `network har start`; prefer those payloads over rebuilding request-id commands from prose. For aggregate buffers, the wrapper accepts `network requests --current-page` / `--current-origin` to render only rows matching the active page origin, or `--current-url` for exact active document URL matching; it strips those wrapper-only flags before upstream spawn and reports counts in `details.networkRequestsPageFilter`. Filtered data receives the same credential redaction as ordinary network diagnostics before entering `details.data` or an `outputPath` export. If the wrapper has seen a prior `network route` in the same session, matching failed, pending, or CORS-looking fetch/XHR rows add `details.networkRouteDiagnostics` plus executable route-mock follow-ups (`inspect-routed-network-request` and `start-network-har-capture-for-route-mock`) so agents do not mistake an unfulfilled mock for a fulfilled mock; same-origin/CORS fixture retry guidance stays in visible prose. `network requests` also hides `data:image` screenshot/artifact noise from the compact preview by default while preserving raw rows in `details.data.requests`. Rules live in `classifyNetworkRequestFailure` / `summarizeNetworkFailures` in `extensions/agent-browser/lib/results/network.ts`; QA aggregation is `analyzeQaPresetResults` in `extensions/agent-browser/lib/input-modes/job.ts`.

```json
{
	"url": "https://example.com",
	"expectedText": "Learn more",
	"screenshotPath": ".dogfood/qa-example.png"
}
```

Optional `loadState`, `checkNetwork`, `checkConsole`, and `checkErrors` default to `"domcontentloaded"`, `true`, `true`, and `true` for URL-opening QA; set a check to `false` to skip that diagnostic. For `qa.attached`, the diagnostic checks default to `false` because upstream buffers may predate the current check; opt in with `checkNetwork`, `checkConsole`, or `checkErrors` when preserved-buffer failures are desired. Omit `expectedText` and `expectedSelector` when you only need load plus diagnostics.

For attached Electron or manually connected CDP sessions, use `qa.attached` after the session exists. It does not open a URL and rejects `sessionMode: "fresh"` because it checks the current managed session. Before running diagnostics, the wrapper requires a readable non-empty page URL on the attached session; missing URLs and read failures fail fast with recovery `nextActions` such as `tab list` and `snapshot -i` instead of running the full QA batch. `file:`, custom-scheme, and other attached targets are accepted. Unlike URL-opening QA, `qa.attached` preserves existing upstream network/console/page-error buffers; by default it does not inspect those buffers so stale rows do not false-fail a current-page smoke check. Set `checkNetwork`, `checkConsole`, or `checkErrors` to `true` to opt into preserved-buffer diagnostics; model-visible text and `details.compiledQaPreset.checks.diagnosticsResetAtStart` call out that preserved diagnostics may include earlier events.

```json
{ "attached": true, "expectedText": "Explorer", "screenshotPath": ".dogfood/electron.png" }
```

Use native batch or a codemode script for a different check sequence.

### Electron desktop apps

Here `electron.launch` and similar labels refer to `agent_browser_electron { "action": "launch", ... }`; `qa.attached` refers to `agent_browser_qa { "attached": true, ... }`. These labels are not nested public input fields.

Full public guide: [`ELECTRON.md`](ELECTRON.md). Use it as the entry point when Electron support is the task; this section keeps the inline workflow snippets for agents reading the broader command surface.

Enable `electron` and use `agent_browser_electron` with flat fields when the wrapper should discover, launch, attach to, probe, and clean up a desktop Electron app. The wrapper owns only launches it created. It uses an isolated temporary `userDataDir`, `--remote-debugging-port=0`, and safe launch defaults; it does **not** reuse the app's normal signed-in profile or attach to an already-running authenticated app. Tron admits only recorded owned launches: for signed-in state use `owned-launch prepare <profileDir>` (a private directory holding a `.tron-owned-profile` marker), launch Chrome with the returned args, `owned-launch record <launchId> <pid> <profileDir>`, then `connect` the returned endpoint. A normal app or browser started with `--remote-debugging-port` is refused with `owned_launch_required`. Remote debugging still exposes app content, so use caller-owned `allow` / `deny` lists for sensitive app policies when needed. `electron.list` may annotate common private-data apps as `[likely sensitive: …]`; this is advisory metadata only and does not block `launch` or replace caller policy.

Install scans for `electron.list` (and resolving `appName` / `bundleId` targets) are implemented for **macOS and Linux** hosts only. On **Windows**, `list` returns `platform: "unsupported"` with no apps, so prefer `executablePath` (or a host `appPath` that points at the real Electron `.exe`) when launching there—the wrapper still runs Electron evidence checks on that path before spawn.

Call `agent_browser_electron` for lifecycle actions, and `agent_browser` for the native snapshot:

```json
{ "action": "list", "query": "code" }
{ "action": "launch", "appName": "Visual Studio Code", "handoff": "snapshot" }
{ "args": ["snapshot", "-i"] }
{ "action": "probe", "timeoutMs": 5000 }
{ "action": "cleanup", "launchId": "electron-…" }
```

`electron.status` and `electron.cleanup` take either `launchId`, **`all: true`** (literal boolean) to walk every active wrapper-tracked launch (including dead, failed, or partial records, but excluding cleaned records), or neither when exactly one active launch exists—never both `launchId` and `all`. They can target the current branch-visible launch plus still-owned off-branch launch records by `launchId`; default no-arg calls are intentionally ambiguous when more than one active launch is owned. `/reload` preserves the current branch-visible active Electron launch and its isolated temp `userDataDir` for continuity, and cleans off-branch owned Electron launches. A managed fork `pi restart` keeps every active branch-visible launch and profile for the replacement worker instead of quitting. First reuse after reload/resume checks the live app's saved debug endpoint and the exact named upstream connection with `get cdp-url`, without reconnecting or resetting page refs; if cleanup is partial and skips or fails profile removal, the generic temp sweep preserves that `userDataDir` across reload, quit, later temp cleanup, process exit, and stale temp-root pruning after restart. `agent_browser_electron` with `action: "list"` has no timeout field. For `action: "launch"`, flat `timeoutMs` sets host CDP readiness polling to a **15s** default and **120s** cap after target discovery; upstream attach and handoff use separate subprocess budgets. Optional `timeoutMs` on **`status`** applies to each managed-session `get url` / `get title` read and any `get cdp-url` read needed to verify a restored connection (localhost CDP probes stay on a short fixed fetch budget). On **`cleanup`**, it is applied separately to upstream `close` and the initial host process-exit wait, not to the entire teardown; debug-port checks have fixed fetch budgets and profile removal has no configurable deadline; when omitted it follows the implicit session close default (**35s** unless `PI_AGENT_BROWSER_IMPLICIT_SESSION_CLOSE_TIMEOUT_MS` overrides). A successful managed-session close step retires that wrapper-managed session even when host process/profile cleanup remains partial. On **`probe`**, it bounds each underlying upstream read subprocess—omit it to use the normal tool subprocess default, or raise it on slow desktops.

Explicit-ID `electron.status` labels a cleaned record as historical while measuring PID/port liveness independently. `details.electron.statuses[].userDataDirState` freshly reports the tracked profile path as `present`, `absent` (only ENOENT), or `unknown` (other native `lstat` errors); dangling symlinks are present. This is not an audit of all app residue and does not change stored launch records or cleanup ownership.

`launch.handoff` defaults to `"snapshot"`, which attaches through upstream `connect`, lists targets, and captures a current `snapshot -i` in one call. Snapshot handoff retries briefly when the first Electron snapshot has no refs; if it still reports no refs, run `snapshot -i` once more before assuming the app is blank. Use `handoff: "tabs"` as the safer diagnostic starting point when you only need target discovery and do not want to snapshot app content yet, or `handoff: "connect"` when you want to attach first and run your own follow-up commands. `targetType` defaults to `"page"`; use `"webview"` or `"any"` for apps that expose useful webviews. When a matching CDP target exposes a WebSocket URL, launch connects to that target; otherwise it falls back to the browser port.

After launch, prefer the exact `details.nextActions` payloads when present: `status-electron-launch` checks liveness, `probe-electron-launch` runs compact diagnostics for a tracked launch, `snapshot-electron-session` refreshes current refs, `list-electron-tabs` inspects targets, and `cleanup-electron-launch` removes the wrapper-owned process/profile when the run is done. If startup fails, inspect the redacted stdout/stderr tails in visible error text and `details.electron.failure.diagnostics`, plus PID, wrapper profile, `DevToolsActivePort`, and timing evidence before retrying. Tails read at most 4096 source bytes per stream; private log files follow profile cleanup/preservation and are not lifetime-size-capped. If status/probe detects a session or target mismatch, follow `reattach-electron-launch` or a fresh snapshot action before using old refs. If a click/fill/type looks successful but the Electron PID or debug port dies, the wrapper now fails the result with `details.electronPostCommandHealth` and same-launch status/probe/cleanup next actions instead of leaving the agent on `about:blank`. If cleanup is partial (`failureCategory: "cleanup-failed"`), inspect `details.electron.cleanup.results` and use `retry-electron-cleanup` only for the same `launchId`.

Recorded external launches: run `owned-launch prepare <profileDir>`, launch Chrome with the returned args, `owned-launch record <launchId> <pid> <profileDir>`, then attach with upstream `connect` to the returned endpoint. You own that browser's shutdown; do not use `electron.cleanup`. close commands (`close`, `quit`, or `exit`) only close the browser/CDP session.

```json
{ "args": ["connect", "<recorded endpoint>"], "sessionMode": "fresh" }
{ "args": ["tab", "list"] }
{ "args": ["tab", "t2"] }
{ "args": ["snapshot", "-i"] }
```

A successful raw `connect` means the debug endpoint accepted the session, not that the app has an active ready page. Prefer `details.nextActions` when present: `verify-connected-session-url` performs the only page read allowed while the attached target is unverified, and `list-connected-session-tabs` runs session-scoped tab inspection. A verified HTTP(S)/app target clears the guard; otherwise navigate explicitly to a safe URL. After the read-only tab list, select or confirm the stable `t<N>` target, verify it with `get url`, and run `snapshot -i` explicitly before trusting refs. If a `snapshot -i` says `No active page`, the wrapper clears any prior refs for that session; follow `list-tabs-after-no-active-page`, select the stable `t<N>` surface, then use a condition wait or retry `snapshot -i` before trusting refs.

For current-session smoke checks after either path, use `qa.attached`; for compact state instead of separate title/url/focus/tab/snapshot calls, use `electron.probe`. `electron.probe.timeoutMs` bounds each underlying read subprocess; `electron.probe.launchId` ties the probe to a wrapper launch and can surface session or target mismatch guidance before you trust page refs. Electron status target reads and probe reads use the same daemon-policy lock and owned restore decision as ordinary managed commands. A probe reads and validates the live URL before title, focus, tab, or snapshot helpers. Electron `launch` snapshot/tabs handoff likewise validates the URL before tab/snapshot reads; handoff failure or cancellation closes the new managed session and host process/profile. Current-managed probe events persist namespace, tab target and a once-stored ref definition so Pi reload/branch replay restores the same page identity after native-generation verification. For VS Code-style quick inputs, treat a successful `fill` as tentative: the wrapper may append `details.fillVerification` if `get value` still reads empty or different, and Electron `@e…` mutations can append `refresh-electron-refs-after-rerender` because same-URL UI rerenders commonly churn refs.

For local app debugging, enable `source`; `agent_browser_source` can gather candidate component/file locations for a visible element from selector DOM hints, React DevTools inspection, and a bounded workspace component-name search rooted at the captured execution directory (`maxWorkspaceFiles` defaults to 2000 and cannot exceed 5000; the scan records at most ten `workspace-search` candidates). With a `selector`, the wrapper runs `is visible` and, unless `includeDomHints` is `false`, `get html` so DOM data attributes and embedded source-like paths can become `dom-attribute` candidates. It reports evidence and confidence in `details.sourceLookup` instead of claiming a guaranteed source file. React hints require a session opened with `--enable react-devtools`. The `details.sourceLookup.status` field reads `unsupported` only when no candidates were collected **and** a `react` batch step failed (inspect errors, missing renderer, and similar); it reads `no-candidates` when the batch succeeded but nothing matched. If selector or workspace hints still yield candidates, `status` remains `candidates-found` even when React inspection failed. Unlike `qa`, the wrapper does not downgrade a **fully successful** upstream batch to `isError` solely because those statuses appear—though failed batch steps still produce normal tool errors. For wrapper-tracked packaged Electron sessions with no candidates, `details.sourceLookup.workspaceRoot` and optional `details.sourceLookup.electronContext` explain that the scan only covered the captured execution directory; installed app resources or `app.asar` bundles are outside that scan and are not unpacked. Those results may add `snapshot-electron-session`, `probe-electron-launch`, and `list-electron-tabs` next actions so you can inspect the live packaged app before deciding whether to change the workspace or app bundle.

```json
{ "selector": "#save", "reactFiberId": "2", "componentName": "SaveButton" }
```

Enable `network` and call `agent_browser_network_source` for failed browser requests. `requestId` adds `network request <requestId>`; `filter` or `url` adds `network requests --filter …`, with explicit filter winning. Optional `namespace` and `session` select the native target; `namespace: ""` overrides an ambient namespace. HTTP status ≥ 400, `failed: true`, and error fields identify failed rows. The same explicit-filter-wins query limits failed-request and initiator analysis by substring; unrelated failed-request initiators are ignored. Repeated request IDs count once, keeping the first matching failed row; anonymous rows and different IDs sharing one URL remain distinct. Workspace URL-literal search uses the captured execution directory and the source tool's bounds: 2,000 files by default, 5,000 maximum, eight needles and ten matches. Results retain `details.networkSourceLookup` with status, failed requests, candidate evidence, and limitations. They never assign definitive blame or replace the active page target and same-page refs.

```json
{ "requestId": "req-1", "url": "/api/fail" }
```

### Wait for page readiness or downloads

```json
{ "args": ["wait", "--load", "networkidle"] }
{ "args": ["wait", "--url", "https://app.example/dashboard"] }
{ "args": ["wait", "--download", "/tmp/report.pdf"] }
```

Do not omit the load state value; use `wait --load <state>` with `load`, `domcontentloaded`, or `networkidle`.

For desktop-host readiness, prefer condition waits over fixed sleeps. Use this ladder: `wait --text` / `wait --url` / `wait --fn` / `wait --load <state>` / `wait --download` when a real condition exists; after raw `connect`, run `tab list` → `tab t<N>` → condition wait or `snapshot -i`; after wrapper-owned `electron.launch`, use `electron.probe` / `electron.status` for launch health or target mismatch; use `qa.attached` when expected text or selector plus diagnostics can express the check. Upstream `agent-browser 0.31.1` supports `wait --url` glob forms such as `**/dashboard` against the full active URL. Fixed waits are a last resort: use explicit `--timeout` or top-level `timeoutMs` for legitimately slow waits, and treat a successful fixed-wait payload such as `"waited":"timeout"` as elapsed time only, not proof that the desktop host finished. Verify with an observed condition, fresh snapshot, or screenshot before continuing.

Use `wait --download [path]` after an earlier action has already started a browser download, such as a dashboard export button that responds asynchronously. Use the control's current snapshot ref (for example `@e5`):

```json
{ "args": ["click", "@e5"] }
{ "args": ["wait", "--download", "/tmp/report.csv"] }
```

For one-call flows, put the click and wait in `batch`; the wait step keeps the saved-file metadata in `details.batchSteps[n].savedFilePath` and `details.batchSteps[n].savedFile`:

```json
{
	"args": ["batch"],
	"stdin": "[[\"click\",\"@e5\"],[\"wait\",\"--download\",\"/tmp/report.csv\"]]"
}
```

A successful wait-based download renders a readable summary such as `Download saved and verified: /tmp/report.csv` and exposes top-level `details.savedFilePath` plus `details.savedFile` for non-batch calls. Native 0.39.4+ handles already-completed downloads and moves their bytes to the requested path for locally launched browsers, but not attached/remote CDP browsers. Treat `details.savedFilePath` as metadata until `details.artifactVerification` verifies the file and `details.artifacts[].exists` is true. A reported-but-missing destination still fails as `artifact-missing`.

### Download, screenshot, and PDF files

```json
{ "args": ["download", "@e5", "/tmp/report.pdf"] }
{ "args": ["screenshot", "/tmp/page.png"] }
{ "args": ["screenshot", "--full", "/tmp/full-page.png"] }
{ "args": ["screenshot", "--annotate", "/tmp/annotated.png"] }
{ "args": ["pdf", "/tmp/page.pdf"] }
```

The upstream screenshot aliases are `screenshot --full` for full-page capture and `screenshot --annotate` for labeled screenshots. Annotated screenshots can be noisy on dense pages because labels overlap real content; when labels obscure evidence, capture a scoped element screenshot, take a non-annotated screenshot, or use `snapshot -i` high-value refs as the machine-readable map. When a user gives exact artifact paths for screenshots, recordings, downloads, PDFs, traces, or HAR files, use those paths or explicitly report why the artifact was unavailable; do not silently substitute another path in the final report. When the latest prompt names exact required screenshot paths, `close` / `quit` / `exit` can be blocked with `details.promptGuard.reason: "requested-artifacts-missing-before-close"` until those paths appear as verified explicit artifacts.

Prefer `download <selector> <path>` when the target element itself is the downloadable link/control. Native download always owns the click and download, including loopback links, generated Blob exports, and redirects; the wrapper never substitutes a fetch of the anchor's `href`. Use `click` plus `wait --download [path]` when a previous action starts the download indirectly.

Screenshot `imageObservations` includes verified pixel dimensions and capture kind. Positively identified Lightpanda images also carry `rendering: "text"`: their text representation is not graphical layout and never establishes CSS/mouse coordinates. Matching pre/post CSS viewport, scroll, DPR, and crop samples may establish a measured document-space mapping; otherwise geometry remains unknown, including unmeasured batches and uncertain scrolled/iframe element captures. Native mouse uses current viewport CSS pixels. Account separately for crop origin, current scroll/frame, and any Pi resize before using coordinates; prefer refs. See [image geometry](TOOL_CONTRACT.md#image-observations).

For evidence-only screenshots, QA captures, or audit artifacts, save to an explicit path and branch on `details.artifactVerification` plus `details.artifacts` before reporting PASS/FAIL. Inline image attachments are optional convenience when size limits allow; do not require vision review unless the user asked for visual inspection.

Wrapper result rendering is metadata-first for saved files. Image MIME types come from a bounded header read for PNG, JPEG, GIF and WebP, never from a filename suffix; missing, unreadable, unknown or truncated headers omit `mediaType`. This identifies a format, not full image validity. Inline screenshots use the same byte check and existing size limit, so a PNG saved as `.webm` still attaches as `image/png`; other artifact kinds are not auto-inlined. An artifact-producing command fails as `artifact-missing` with artifact `status: "stale"` when the reported path's `mtimeMs` falls outside the command's bounded start/end window (with two seconds of filesystem precision tolerance), including a previous recording that `record restart` claims to finalize; clearly old or future-dated evidence is never accepted as a fresh capture. A batch, whether supplied through stdin arrays or argument command strings, must use distinct explicit artifact destinations; preflight canonicalizes existing path ancestry, compares existing file identities to catch hardlinks, and applies full Unicode plus platform case folding on macOS/Windows so aliases cannot satisfy another step's verification. The same preflight prevents `outputPath` from aliasing a same-call browser artifact, follows upstream's forward option consumption and final effective `-o` / `--output` for `diff screenshot`, and treats the optional path on `network har stop` as an artifact destination; upstream ignores positional paths on `network har start`. Outer CLI artifact parsing removes upstream global flags, so direct forms such as `record --json start <path>` and `pdf --quiet <path>` retain their native destinations. Native batch rows do not run that cleanup: `pdf --quick ignored.pdf` writes to the literal path `--quick`, and `download #link --quiet ignored.bin` writes to `--quiet`. Preflight, directory preparation, presentation, and timeout evidence use those same operands, not the ignored trailing tokens. Screenshot destination parsing mirrors upstream's exact flag matching and `[selector] [path]` positional order: `--` is positional, `true` / `false` after screenshot-only `--full` / `-f` remain positional, extra positionals are ignored after the path slot, selector-prefixed (`.`, `#`, `@`) or uppercase-extension single arguments remain selectors, and lowercase image extensions or slash-bearing arguments are paths. The wrapper deliberately keeps its existing slash-bearing hidden-workspace path normalization (for example `.dogfood/run/foo.png`) before launch. `wait --download` is observational and may verify a download that completed just before the wait began, so it is exempt from the command-window mtime gate; an explicit wait destination, in long `--download <path>` or short `-d <path>` form (including `wait --download --timeout 30000 capture.csv`), still participates in active-recording reservation preflight; the path is the next retained operand after the first timeout pair is removed; unsupported `--download=<path>` fails with split-argument guidance:

- screenshots return a saved-path summary, visible artifact metadata, structured `details.artifacts` metadata, and an inline image attachment when safe; the visible block includes artifact type, requested path, absolute path, existence, size, cwd, session, and repair/copy status when applicable
- downloads, PDFs, `wait --download` files, `state save` state files, diff screenshot output images, traces, CPU profiles, completed video recordings from `record stop`, and path-bearing HAR captures return concise saved-path summaries plus structured `details.artifacts` metadata without inlining large files
- `record start <path>` and `record restart <path>` report `successCategory: "artifact-pending"` and that output will be written on `record stop`; dispatched `record start` and URL-bearing `record restart` attempts append one `Page state:` warning on success or failure, describing conservative ref invalidation rather than an observed page change; explicit `--json` puts that warning in `warnings`. Only reached batch rows qualify, not preflight failures, missing binaries, help calls or unconfirmed planned rows — the wrapper invalidates the session’s prior ref snapshot (direct calls and batch steps alike, and even when the start fails with `Recording already active`, to protect older supported natives that can swap the page before that check), so old `@e…` refs fail as `stale-ref` until a fresh `snapshot -i` succeeds; `record restart <path> <url>` navigates the current page and invalidates refs the same way, while a restart without a URL, including FPS-only options, keeps the current page and refs; `details.artifacts` / `details.artifactVerification` mark that future file as `pending` with `recordingState: "openRecording"` and `willExistOnStop: true`, and `details.nextActions` includes exact `stop-pending-recording` args. When `record restart` returns a native `previousRecording`, that receipt's outcome and capture window control the previous artifact's verification; without that receipt, only an acknowledged native `restarted: true` retires the previous take, whose file remains unverified, not saved; rejected or pending restarts keep the active take's reservation and stop action; a missing or stale prior file fails as `artifact-missing` while the new recording remains visible as pending and the prior manifest row is retired. Within one Pi extension process, an unbounded transcript-backed index reserves active recording destinations independently of the bounded artifact manifest. Artifact lifecycle calls and result `outputPath` writes serialize around that global check; reservations use canonical namespace/session identity, survive manifest eviction and branch replay, and retire after direct, ordered nested-batch, fresh-replacement, Electron, or shutdown close; the newest pending row per identity is authoritative. Legacy batch replay retires a pending manifest only when the ordered close lifecycle leaves recording closed; a later successful browser reactivation plus `record start` keeps the new pending reservation. Lexical, hardlink, existing/dangling symlink, full Unicode-fold, and macOS/Windows case aliases are rejected, so `record restart` must use a distinct new path. Do not place `record start` or `record restart` after `close` / `quit` / `exit` in one batch: wrapper preflight rejects it because upstream can report success without starting a recording; split the close and recording into separate calls. A `No recording in progress` stop failure checks the matching native receipt once and preserves checked file metadata instead of assuming the path is missing; a later successful batch recording row opens its new pending path normally. Recovery offers an exact status query, and a stop only when the matching take is still current and pending. The target remains unverified until recording stops. Native 0.37 checks `ffmpeg` before starting; older supported natives may defer failure. If a successful start/restart reports pending output without `ffmpeg`, the wrapper appends `Recording dependency warning: ffmpeg not found on PATH` and `details.recordingDependencyWarning`; stop, check the result, then install the dependency before starting a new recording.
- `batch` keeps each step's artifacts in `details.batchSteps[].artifacts`; top-level `details.artifacts` and `details.artifactManifest` coalesce an earlier pending recording into the later saved, missing, or stale terminal result for the same namespace/session identity; a successful later close retires an unfinalized recording as `close-abandoned`, uses `missing` only after a filesystem check proves absence (otherwise unverified), removes its stop action, and resets earlier ref/page/network-route batch state; a later successful `record stop` replaces that intermediate abandoned row with its verified saved artifact, and later rows—including failed rows—whose lifecycle reports a browser launch may rebuild state without triggering stale pre-close `about:blank` recovery; failed-step `batchSteps[]` retains only the bounded `lifecycle.effectiveLaunch.browserLaunched` boolean for replay, explicitly non-launching diagnostics leave the close terminal, missing lifecycle evidence remains conservatively active even on the first managed call, every successful close clears wrapper trace/profiler ownership before ordered later successful rows can rebuild it, namespace-scoped `close --all` clears all matching managed/attached/page/ref/route/trace/recording ownership, and any later same-session failure before recording stops keeps exact `stop-pending-recording` args alongside its normal recovery

`diff screenshot` follows the file-artifact path above for the **diff** image: model-visible text and `details.artifacts` focus on that output, while baseline paths stay out of the artifact summary block, and Pi does **not** auto-inline the diff the way it inlines trusted `screenshot` captures. `state load` may print the loaded path in prose but does not add a saved-file artifact entry the way `state save` does.

For screenshot paths under dot-directories such as `.dogfood/run/foo.png`, the wrapper normalizes the requested path to an absolute path before invoking upstream `agent-browser`, verifies the requested file exists, and repairs from an upstream temp screenshot when possible. For direct artifact commands and batch artifact steps (`download`, `pdf`, `screenshot`, `state save`, and `wait --download`), the wrapper creates missing parent directories before launch. A parent-directory failure returns `validation-error` with the attempted directory and `verify-artifact-path` guidance before the browser command runs. Prefer **absolute paths in raw batch artifact rows** because the daemon's working directory may differ from Pi's. When `pi-change-working-dir` selects a different execution root, the wrapper binds relative file operands in direct, stdin, and raw batch rows to that invocation's root; upstream's raw-argument precedence over stdin is unchanged. Otherwise raw strings stay unchanged and screenshot path normalization applies only to direct calls and stdin rows. See [working-directory changes](REFERENCE.md#working-directory-changes). Known caller paths appear as `Requested path`; `Absolute path` is the resolved location checked on disk, and `Reported path` exposes a differing screenshot report (including a canonical `/private/tmp` alias) through the existing `tempPath` metadata. No extra canonicalization rewrites upstream arguments.

For annotated screenshots in `batch`, put `--annotate` in top-level args instead of inside the screenshot step:

```json
{ "args": ["--annotate", "batch"], "stdin": "[[\"screenshot\",\"/tmp/page.png\"]]" }
```

#### Recording quality and receipts

```json
{ "args": ["record", "start", "captures/demo.webm", "--fps", "30"] }
{ "args": ["record", "stop"], "outputPath": "captures/demo-receipt.json" }
```

Inspect `details.artifacts[].recording`: native capture start/end and first/last frame timestamps, wall duration, captured-frame rate, received frames, encoded/written/held/dropped/skipped counts, and separate output duration/FPS. Received frames are not pixel-unique. Repeated/static or late/final-only frames cannot establish smoothness. Missing metrics stay unknown; nominal FPS and `frames / fps` are not wall-clock capture evidence.

A stop timeout or `No recording in progress` result triggers one two-second native `session info` query, not another stop. `details.recordingRecovery` keeps the original failed attempt and requires matching session/namespace, recording ID/path (or an effective planned start window), terminal native encoder success and a verified file before recovering success. Same-path older receipts cannot verify a newer take. A timed-out batch may yield a verified recording while other steps remain unproven; unrelated failed-step repair actions remain available. Failed or unverified receipts still export safely to a distinct `outputPath`, with error/attempt provenance and parseable JSON. Follow the returned status/stop actions, not blind mutation retries or longer timeouts.

Detailed receipt/live-browser fields and browser-independent native read/confirm handling require companion upstream support not yet present in the current recommended release. Older supported versions remain usable with unknown metrics. Native receipt lookup lasts only while that daemon retains its memory; transcript metadata is not post-exit native recovery. See [the full receipt contract](TOOL_CONTRACT.md#recording-receipts-and-recovery).

#### Artifact retention and dogfood-heavy QA runs

The wrapper's internal recent artifact view defaults to 100 metadata rows, configurable with `PI_AGENT_BROWSER_SESSION_ARTIFACT_MANIFEST_MAX_ENTRIES=<count>`. That cap bounds the current view, not append-only history. Journal events store row changes; `details.artifactManifest` contains changed or referenced receipts for this invocation rather than the unchanged history. Complete reference captures are likewise defined once, with small reuse/invalidation events. Historical browser journals resume automatically at the original path without rewriting history; the same ref and native-generation checks still apply. See [browser session storage](SESSION_STORAGE.md).

This cap controls the internal recent view and summaries such as `Session artifacts: 42 live, 0 evicted (42/100 recent)`. It does not delete explicit files that upstream saved to paths you chose, such as screenshots, PDFs, downloads, traces, HAR files, or WebM recordings.

Browser close commands (`close`, `quit`, or `exit`) are also not file cleanup. When the internal recent view contains explicit artifacts, a successful close command appends a compact `Artifact lifecycle` note and reports `details.artifactCleanup` with the current retention summary and the same host-owned cleanup `note` as the contract (`extensions/agent-browser/lib/orchestration/browser-run/diagnostics.ts`, `getArtifactCleanupGuidance`). Up to ten distinct user-chosen paths that still exist on disk appear in `explicitArtifactPaths` when matching `explicit-path` manifest rows exist in the recent window; deleted/stale paths are skipped. Otherwise that array is empty and the visible text stays compact while the structured detail still reminds you that close commands do not delete saved files. Delete any paths you care about with host file tools after inspection; the native browser tool intentionally does not remove arbitrary user-chosen filesystem paths.

Oversized snapshots and oversized generic outputs are different: when a persisted pi session is available, their wrapper-managed spill files are stored under the private session artifact directory and are governed by the byte budget `PI_AGENT_BROWSER_SESSION_ARTIFACT_MAX_BYTES` (default 32 MiB). Raise that byte budget for longer retention, or set `PI_AGENT_BROWSER_SESSION_ARTIFACT_MAX_BYTES=0` to disable automatic eviction of persistent spill files. Zero leaves existing files in place as new spills are written; it does not recover files already evicted or change temporary subprocess spill cleanup.

### Switch from an already-active implicit session to a fresh profiled or alternate-browser launch

```json
{
	"args": ["--profile", "Profile 1", "open", "https://mail.google.com"],
	"sessionMode": "fresh"
}
```

```json
{
	"args": [
		"--executable-path",
		"/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
		"open",
		"https://mail.google.com"
	],
	"sessionMode": "fresh"
}
```

`profiles` lists Chrome profile directory names from Chrome's user data directory; `Default` is common but not guaranteed. When profile resolution fails, use `agent_browser` diagnostics first: run `{ "args": ["profiles"] }` and `{ "args": ["doctor"] }`, then tell the user which profile name/path or browser executable setting to configure before retrying. For non-Chrome Chromium browsers, pass `--executable-path <path>` to the browser binary and use a full profile/user-data directory path only when upstream accepts that path.

### Recover tabs when focus lands somewhere unexpected

```json
{ "args": ["tab", "list"] }
{ "args": ["tab", "t2"] }
{ "args": ["snapshot", "-i"] }
```

Use `tab list` and `tab <tab-id-or-label>` when a profile restore, pop-up, or click opens or focuses the wrong tab. Wrapper presentation keeps stable tab IDs plus upstream labels from `tab new --label` visible (for example `label=docs`) so multi-tab sessions are easier to read. Generic tab-drift recovery lists tabs first; run `snapshot -i` only after selecting or confirming the intended stable target. When the wrapper already knows the target, `details.nextActions` may include recovery actions that list tabs, select the intended tab, and refresh refs in the right session.

### Recover from guarded-action confirmations

Configure `--confirm-actions` on the session's first command. The extension retains that setting for the same canonical namespace/session across helpers, bare follow-ups, advanced calls, and transcript resume. Follow the exact returned confirm/deny action without repeating the policy. First launch and new explicit `--confirm-actions` / `--config` selections use native argv → environment → config precedence. Bare follow-ups retain an established string, including explicit `""`, over ambient environment/discovered-config edits; those defaults apply again after close or for a new identity. Native unset is not pinned and continues ordinary native default resolution. Explicit policy changes still use native restart behavior and can discard pending confirmations. Successful close, namespace-wide close, and successfully closed managed replacements retire the setting with that session. Replacement cleanup uses the old identity's setting; failed or pending close retains its continuity state. Electron launch and host probes use the selected setting too. A definite wrapper/native CLI parse/config/local-inspection rejection restores the previous setting unless an earlier browser helper could have established the request; interrupted work retains selected intent.

When upstream requires confirmation, the native tool result prints the pending confirmation id and both recovery calls. Confirming one action in a compound command can return another native confirmation; follow its returned action too. Pending navigation is intent, never an observed page target, including pending native batch rows. A completed compound confirmation reconciles its native resulting target before ordinary follow-ups. A tab-creation transport can add `after_confirmation: ["open", <requested URL>]` plus nonempty `guidance` when the URL matches the original `tab new` request, including a preceding `--label`. Follow that visible continuation only after approval successfully creates the blank/labeled tab, in the same session and new tab—never after denial. The extension preserves the exact decision and conditional guidance but does not execute the continuation. Confirmed full snapshots install returned refs in direct and batch row order. A final confirmed capture supplies the next same-identity call's freshness sample once, including role click/check/fill and unique accessible select resolution; an intervening call or later row consumes the opportunity. A pending snapshot is displayed as confirmation required, never as an empty capture. Use refs from that capture: membership, target and invalidation checks still apply. On this one use, live verification compares the complete capture URL, including fragments, and rejects refs when it changes—including wrapper-owned managed sessions and warm sessions without resume. Ordinary ref/tab URL comparisons remain fragment-insensitive. DOM-only renames on the same page after the sample are not resampled on this one use. Further ref actions use normal freshness checks. Optional click-dispatch eval probes are skipped when the effective native confirmation list guards `evaluate`; native click confirmation still applies. Use the same `agent_browser` tool; do not switch to bash.

```json
{ "args": ["--confirm-actions", "click", "click", "@danger"] }
```

If the result says `Pending confirmation id: c_8f3a1234`, choose one follow-up:

```json
{ "args": ["confirm", "c_8f3a1234"] }
{ "args": ["deny", "c_8f3a1234"] }
```

Use the exact returned actions for a genuine native control: they preserve its ID and canonical namespace/session across resume/branch replay. Matching guarded decisions skip page/pinning helpers that could overwrite the native pending slot, then reconcile completed browser actions normally; this is not proof of native ID validation or browser independence. Only a matching first effective guarded decision gets that suppression in native batch; native raw-argument-over-stdin selection and later page/ref checks remain unchanged. Page content and unrelated/nonmatching decisions gain no exemption. Explicit URL reads remain separate: only `capabilities.readRequiresConfirmation: true` grants browser independence with native ID checking; legacy URL reads keep normal checks. Explicit caller identities still win. A pending cold-reopen helper exposes its exact action without running the requested getter or replaying open. A failed inner confirmed action fails the tool; a completed confirmed close retires session state.

Confirmation context may be redacted when it contains credentials, tokens, cookies, or auth-bearing URLs. Replacements are marked `[REDACTED]` (URL-encoded in parsed URLs); ordinary technical phrases such as `bearer token` and `bearer authentication` stay intact outside credential fields and headers. URL scrubbing covers `code`, SAMLRequest, SAMLResponse, RelayState, `authorization_session_id`, and auth-context `state` / `nonce` while retaining ordinary non-auth query values and the spelling of URLs needing no redaction. Visible text, structured details, persisted spills, and `outputPath` exports use the same redaction; exact internal page-target URLs remain available to browser state logic. Use the id exactly as printed.

### Use stateful browser-context commands safely

Stateful commands are native `agent_browser` calls, not shell commands. Keep secrets out of `args` whenever upstream supports stdin, and expect model-facing summaries to redact auth, cookie, password, secret, session, and token-like values.

```json
{ "args": ["auth", "save", "demo", "--password-stdin"], "stdin": "password from the user-approved secret source" }
{ "args": ["auth", "login", "demo"] }
{ "args": ["state", "save", "/tmp/demo-state.json"] }
{ "args": ["state", "load", "/tmp/demo-state.json"], "sessionMode": "fresh" }
{ "args": ["cookies", "set", "theme", "dark", "--url", "https://example.com"] }
{ "args": ["storage", "local", "get", "theme"] }
{ "args": ["dialog", "status"] }
{ "args": ["dialog", "accept", "prompt text"] }
{ "args": ["frame", "main"] }
```

Operational notes:

- Visible page content from real authenticated profiles is still model-visible and may persist in transcripts or saved artifacts. The wrapper redacts credential-like cookie/storage/auth data, not the ordinary page text you asked it to read.
- `stdin` is accepted only for `batch`, `eval --stdin`, and `auth save --password-stdin`; other stdin-bearing calls are rejected before launch.
- `auth list/show/save/login/delete` summaries avoid expanding profile secrets. Prefer `auth save --password-stdin` over `--password <value>`.
- `session list` and `tab list` are formatted as compact field lists so caller-owned names, labels, active markers, page titles, and URLs are visible without relying on raw JSON. Wrapper-managed `piab-*` session rows remain visible in `session list`.
- `state save <path>` is a verified file-artifact workflow; the wrapper creates missing parent directories before invoking upstream, then inspect `details.artifactVerification` before relying on the file. `state load <path>` is not treated as a newly saved artifact.
- `cookies get` can expose real authenticated-profile cookies; prefer task-specific page actions and only inspect cookies when the user needs cookie data.
- `storage local|session` summaries redact sensitive keys and likely secret values but may keep benign primitive local QA values visible, for example `theme: dark`; still avoid broad storage dumps unless necessary.
- `dialog accept/dismiss/status`, `frame <selector|main>`, and guarded-action `confirm <id>` / `deny <id>` pass through the native tool. Dialog commands use a shorter wrapper process timeout than general browser calls; if a click/tap/find/dialog command times out and may be blocked behind a JavaScript dialog, `details.nextActions` can include `inspect-dialog-after-timeout`, `dismiss-dialog-after-timeout`, and `recover-fresh-session-after-dialog-timeout`. Prefer `details.nextActions` for exact confirmation recovery payloads.
- `batch` mirrors the same redaction on every step: top-level `details.data` is a compact `{ success, command, result?, error? }[]` matrix (argv-redacted `command`, stateful `result`, scrubbed `error` text). Use `details.batchSteps[]` when you need per-step artifacts, categories, spill paths, or full structured errors beyond the roll-up.

## Full supported surface

The command groups below intentionally list more than the recommended workflow. Rare commands are included so agents can discover that the installed upstream supports them without direct `agent-browser --help` access.

### Built-in skills

Native-tool note: upstream skills are written for the standalone `agent-browser` CLI and may show bash/heredoc examples. In pi, convert those examples to `agent_browser` calls: pass CLI tokens in `args`, and pass heredoc/stdin bodies through the tool `stdin` field for `batch`, `eval --stdin`, or `auth save --password-stdin`. The wrapper's copyable skill calls preserve quoted empty and whitespace-only operands: `fill '#name' ""` becomes `args: ["fill", "#name", ""]`, not a missing value.

Session note: `skills list`, `skills get …`, and `skills path …` are **stateless** in this wrapper. Even with default `sessionMode: "auto"`, the extension does not prepend the implicit managed `--session` for those commands, so reading bundled skills does not attach to or rotate the active browser session (same intent as plain-text `--help` / `--version` inspection). Other `skills` subcommands follow normal session rules until explicitly allowlisted in `extensions/agent-browser/lib/runtime.ts` alongside regression coverage in `test/agent-browser.runtime.test.ts`.

| Command                         | Purpose                                                                                                                                                                                                                                                                                                                               |
| ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `skills list`                   | List available CLI-bundled skills.                                                                                                                                                                                                                                                                                                    |
| `skills get core`               | Print the core usage guide.                                                                                                                                                                                                                                                                                                           |
| `skills get core --full`        | Print the full version-matched core command reference and templates.                                                                                                                                                                                                                                                                  |
| `skills get <name>`             | Load a specialized skill such as `electron` or `slack`. Common specialized calls include `skills get electron`, `skills get slack`, `skills get dogfood`, `skills get vercel-sandbox`, `skills get agentcore`, `skills get derive-client` (HAR-to-API-client workflow), and `skills get webmcp-gen` (create and validate page tools). |
| `skills get <name> --full`      | Include a skill's supplementary references/templates when present.                                                                                                                                                                                                                                                                    |
| `skills get <name> --ref <ref>` | Load only the named reference or template by relative path, file name, or stem. Repeat `--ref` for several files from one skill.                                                                                                                                                                                                      |
| `skills get --all`              | Print all visible bundled skills for broad audit/debug work.                                                                                                                                                                                                                                                                          |
| `skills path [name]`            | Print a skill directory path.                                                                                                                                                                                                                                                                                                         |

Skill-source debugging note: upstream honors `AGENT_BROWSER_SKILLS_DIR` as an override for bundled skill discovery. Normal agents should not need it, but it is useful when validating package layout or upstream skill packaging.

### Core page and element commands

- `open [url]` — Navigate when given a URL. URL-less `open` runs native `get url`, launching if needed and otherwise retaining the current page. Use explicit `about:blank` when navigation to blank is intended.
- `open <url>` — Navigate to a URL; `goto <url>` and `navigate <url>` are equivalent navigation aliases when a URL is present.
- `read [url]` — Fetch agent-readable text from an explicit URL without requiring a Chrome page, or omit the URL to read rendered active-tab DOM. Supports `--raw`, `--require-md`, `--llms <index|full>`, `--outline`, `--filter <text>`, and `--timeout <ms>`.
- `click <sel>` — Click an element or `@ref`.
- `click <sel> --new-tab` — Click a link/control while requesting a new tab.
- `dblclick <sel>` — Double-click an element.
- `type <sel> <text>` — Type into an element; both selector and text are required. Full form: `type <selector> [--clear] [--delay <ms>] [--] <text>`. Native 0.42.0 reads `--clear` and `--delay <ms>` as options; put `--` before text that looks like a flag. For the focused element without a selector, use `keyboard type <text>`.
- `fill <sel> <text>` — Clear and fill an element. Full form: `fill <selector> [--] <text>`; text after `--` is literal on native 0.42.0, including values such as `--json`. Older supported natives type the marker too.
- `press <key>` — Press a key such as `Enter`, `Tab`, or `Control+a`. `key <key>` is the upstream alias.
- `key <key>` — Alias for `press <key>`.
- `keydown <key>` — Hold a key down without releasing it, useful for modifiers.
- `keyup <key>` — Release a key previously held by `keydown <key>`. Common modifier examples are `keydown Shift` and `keyup Shift`.
- `keyboard type <text>` — Type text with real keystrokes and no selector.
- `keyboard inserttext <text>` — Insert text without key events.
- `hover <sel>` — Hover an element.
- `focus <sel>` — Focus an element.
- `check <sel>` — Check a checkbox.
- `uncheck <sel>` — Uncheck a checkbox.
- `select <sel> <val...>` — Select one or more dropdown options.
- `drag <src> <dst>` — Drag and drop.
- `upload <sel> <files...>` — Upload one or more files.
- `download <sel> <path>` — Download a file by clicking an element. Native 0.42.0 rejects it on a browser attached with `--cdp`, `--auto-connect`, or a provider.
- `scroll <dir> [px]` — Scroll `up`, `down`, `left`, or `right`.
- `scroll <dir> [px] --selector <sel>` — Scroll a specific scrollable element/container instead of the page.
- `scrollintoview <sel>` — Scroll an element into view; `scrollinto <sel>` is the upstream alias.
- `scrollinto <sel>` — Alias for `scrollintoview <sel>`.
- `wait <sel|ms>` — Wait for an element or a duration.
- `screenshot [selector] [path]` — Take a full-page or element-scoped screenshot; a single selector-like argument scopes, while a path-like argument saves to that path.
- `screenshot [path]` — Take a screenshot and optionally save it to a path.
- `pdf <path>` — Save the page as a PDF.
- `snapshot` — Print an accessibility tree with refs for AI interaction. Common options include `snapshot --interactive`, `snapshot --urls`, `snapshot --compact`, `snapshot --depth <n>`, `snapshot --selector <sel>`, and native `snapshot --delta` / `snapshot --delta --full`. Cursor-interactive elements are included by default; `snapshot --cursor` / `snapshot -C` are deprecated no-ops.
- `eval <js>` — Run JavaScript. Use `eval --stdin` through this wrapper for larger snippets, or `eval -b <base64>` for shell-escaping-safe one-liners.
- `connect <port|url>` — Connect to a browser through CDP.
- `close [--all]` — Close the current browser or all sessions; `quit` and `exit` are upstream close aliases.
- `tap <selector>` — Touch-oriented tap alias for iOS/provider workflows.
- `swipe <direction> [distance]` — Touch-oriented swipe for iOS/provider workflows.

On dashboards and other apps with nested scroll containers, `scroll <dir> [px]` can miss because a page-level wheel does not move the document or the intended pane. Without startup-scoped launch flags, the wrapper first applies ordinary `scroll <up|down|left|right> [px|percent]` directly to `document.scrollingElement` with smooth scrolling temporarily disabled; successful movement reports `details.scrollPage`. If the document cannot move, it falls back to upstream wheel behavior. For large fallback calls on an existing or fresh managed session, the wrapper samples viewport and prominent scroll-container positions before and after the command; when nothing changes it reclassifies the nominal upstream success as `failureCategory: "upstream-error"`, prepends `Scroll completed with no observed movement`, appends `Scroll diagnostic: no observed scroll movement`, exposes `details.scrollNoop`, marks `details.data.scrolled: false`, and adds exact `details.nextActions` for a fresh `snapshot -i` and screenshot. Explicit CSS-container calls `scroll <selector> <up|down|left|right> [px|percent]` remain wrapper-handled, use `Element.scrollBy` with `behavior: "instant"` so smooth-scroll CSS cannot delay the measured movement, and report `details.scrollContainer`; `scroll to end` / `scroll to top` report `details.scrollPage`. These shims intercept only complete recognized shapes: `scroll to end|top` has no extra operands, and CSS-container scroll accepts only the selector, direction, and optional amount. Surplus operands such as `scroll to end --selector #panel` or `scroll #panel down 500 extra` pass through to native agent-browser unchanged rather than being silently dropped. Calls with startup-scoped flags skip all helper shims so the requested launch configuration runs first. Use these paths before repeating page scrolls; when you need a specific element, prefer `scrollintoview <@ref>` or target the actual scrollable region. Do not pass `text=...` to `scrollintoview`: the wrapper rejects that upstream false-success path and returns `scroll-semantic-text-target` (`find text ... hover`) plus `refresh-refs-for-scroll-target` (`snapshot -i`) actions.

Comboboxes vary by app. For native `<select>` controls, prefer raw `select <selector> <value...>`, flat `agent_browser_action` select fields or active-session semantic role/name/label select instead of clicking option refs; native option refs can be non-boxed in CDP and fail before a real selection. A `click` or `agent_browser_action` role/name click may focus a searchable custom combobox without opening its option list. For explicit combobox-targeted actions such as `agent_browser_action` role `combobox`, the wrapper checks whether a combobox-like element is focused, has explicit `aria-expanded` state, and has no visible listbox/options open; this still applies when the semantic action first resolves to a current visible `@ref` before execution. When that happens it appends `Combobox diagnostic: focused combobox did not expose visible options`, exposes `details.comboboxFocus`, and adds exact `details.nextActions` for a fresh `snapshot -i`, `press ArrowDown`, and `press Enter`. Use those instead of assuming click alone expanded the control. To search the focused input, use `keyboard type <text>`; raw `type` requires both a selector and text. Reserve visible option refs for custom comboboxes after a fresh snapshot shows the intended option.

### Navigation

| Command   | Purpose                  |
| --------- | ------------------------ |
| `back`    | Go back.                 |
| `forward` | Go forward.              |
| `reload`  | Reload the current page. |

### Session, state, frames, dialogs, windows, and inspection commands

- `session` — Show current session name.
- `session list` — List active sessions.
- `state save <path>` — Save cookies, local storage, and session storage to a state file.
- `state load <path>` — Load cookies and storage from a state file.
- `state list` — List saved state files.
- `state show <filename>` — Show saved-state metadata without dumping cookie or storage values.
- `state rename <old-name> <new-name>` — Rename a saved state file.
- `state clear [session-name] [--all]` — Clear saved states for one name or all names; `state clear -a` is the upstream short alias for clearing all names.
- `session id --scope worktree --prefix <name>` — Generate a stable session id for agent/worktree-scoped browser state.
- `session info --json` — One read-only preflight: daemon activity/PID versus native browser liveness, Chrome PID, exact profile, tabs and launched/attached ownership, plus separate Pi cleanup ownership. Missing native fields remain unknown; no browser launch or tab changes.
- `state clean --older-than <days>` — Delete expired saved-state files.
- `frame <selector|main>` — Switch iframe context by selector/ref/name/URL, or return to the main frame.
- `dialog accept [text]` — Accept an alert, confirm, or prompt dialog, optionally supplying prompt text.
- `dialog dismiss` — Dismiss or cancel the current dialog.
- `dialog status` — Check whether a dialog is pending.
- `window new` — Open and activate a new blank window. The wrapper keeps that intentional `about:blank` target rather than selecting the old tab. Old refs are invalid; take a fresh snapshot before further interaction.
- `close` — Close the current browser session.
- `close --all` — Close every session.

A canceled cold-session reopen returns an aborted result with its exact session identity and the consumed reopen marker once the CLI starts. Reload does not repeat that navigation. Cancellation before the attempt leaves the remembered URL pending for the next current-page operation.

An incomparable saved process-start format does not prove a daemon restarted. When its PID and socket still match, the wrapper invalidates old refs and requires a fresh snapshot without reopening the live page or discarding unsaved input. Restored daemon provenance still requires a positive identity match. A restore-disabled session, such as a fresh profile/state launch, can therefore refuse reuse after an update when its saved identity is incomparable; it requires owner-side close and a fresh launch rather than inferring ownership from PID/socket alone.

Native inspection calls use the `agent_browser` tool shape, not shell-like direct-binary commands:

- { "args": ["--help"] }
- { "args": ["--version"] }

These calls return plain text and stay stateless: the extension does not inject its implicit session and does not let inspection consume the managed-session slot needed for later profile, session, CDP, state, auto-connect, or provider-backed launches.

### Page state, finding, mouse, settings, network, and storage

- `get title`, `get url`, `get cdp-url` — Read page/browser metadata without a selector. Upstream root help summarizes this family as `get <what> [selector]`, but the selector is not optional for DOM getters.
- `get text/html/value/count <selector>` — Read matched elements; use `get text body` for whole-page text.
- `get attr <selector> <name>`, `get box <selector>`, `get styles <selector>` — Read an attribute, bounding box, or computed styles from matched elements.
- `is <what> <selector>` — Check `visible`, `enabled`, or `checked`.
- `find <locator> <value> <action> [text]` — Locator types include `role`, `text`, `label`, `placeholder`, `alt`, `title`, and `testid`; selector helpers include `find first <sel>`, `find last <sel>`, and `find nth <n> <sel>`. Role/text filters include `find role <role> --name <name>` and `find ... --exact`. Actions are `click, fill, check, hover, text` only. Prefer `find role` for semantic elements: implicit roles work (`find role heading text --name` for `<h2>`, list/banner landmarks, and similar). Default name matching is a case-insensitive substring; `--exact` makes the accessible name case-sensitive. On misses, upstream 0.32.4+ keeps locator detail such as `Names seen: …` or `No element found: getByRole(...)` instead of a generic flatten.
- `mouse <action> [args]` — `move <x> <y>`, `down [btn]`, `up [btn]`, `wheel <dy> [dx]`.
- `set <setting> [value]` — `viewport <w> <h>`, `device <name>`, `geo <lat> <lng>`, `offline [on|off]`, `headers <json>`, `credentials <user> <pass>`, and `set media <features>` (`dark`, `light`, and/or `reduced-motion`).
- `network <action>` — `network route <url> [--abort|--body <json> [--allow-origin <origin>]] [--resource-type <csv>]`, `network unroute [url]`, `network requests [--clear] [--filter <pattern>] [--type <csv>] [--method <method>] [--status <code|range>]`, `network request <requestId>`, `network har start`, `network har start --content text` (default; embeds text bodies), `network har start --content all`, `network har start --content none`, and `network har stop [path]`. `--resource-type` filters intercepted requests by CDP resource type, such as `script`, `image`, `font`, `xhr`, or `fetch`; request listing filters accept resource types (`xhr,fetch`), methods (`POST`), and statuses (`2xx`, `400-499`). HAR files can include auth headers and bodies—do not share them unredacted. For turning a recording into a reusable API client, load `skills get derive-client`.
- `cookies [get|set|clear]` — Manage cookies. Full set form: `cookies set <name> <value> --url <url> --domain <domain> --path <path> --httpOnly --secure --sameSite <Strict|Lax|None> --expires <timestamp>`; also supports `cookies set --curl <file>` for JSON, cURL, or bare Cookie-header bulk imports.
- `storage <local|session>` — Manage web storage.

`cookies set --curl <file>` selects native file-import mode even when `--curl` follows other set operands. Ordinary import paths remain visible in invocation echoes and failed batch diagnostics; inline cookie values, sensitive flags, and secret-bearing path text still redact. File contents are not echoed by this exception.

With explicit `--json false`, cookie `name=value` (including empty names) and storage `key: value` (including empty and colon-containing keys) output use command-aware redaction before presentation and export; benign preferences remain visible. Standalone `storage local|session get <key>` and shorthand `storage local|session <key>` redact the whole sensitive value, including embedded newlines, even when invocation display redaction changes the supplied key. All-entry/raw-batch text has unescaped multiline values and no row provenance, so use structured JSON for unambiguous sensitive storage. See [the output contract](TOOL_CONTRACT.md#wrapper-json).

Privacy note: `cookies get` can expose real profile cookies. Do not run it against `--profile Default` or other authenticated profiles unless the user explicitly needs cookie inspection; prefer task-specific page actions and storage checks.

### WebMCP page tools

WebMCP support is experimental and browser-dependent. Locally managed Chrome enables it by default; use a fresh launch with `--no-webmcp` or set `AGENT_BROWSER_NO_WEBMCP=1` to disable it. Page tool metadata and results come from the page itself. On 0.37, successful navigation with native `webmcp.available: true` and a positive tool count shows a `webmcp list` hint; the raw object stays in `details.data`. No hint is added for absent, unavailable or empty metadata.

- `webmcp list` — List tools registered by the current page, including each tool's frame id, origin, schema, and annotations.
- `webmcp invoke <tool>` — Invoke a page tool with an empty input object.
- `webmcp invoke <tool> --params <json|@file>` — Pass a JSON object inline or read it from a caller-selected file.
- `webmcp invoke <tool> --frame <frame-id>` — Select the registering frame when a tool name is ambiguous.
- `webmcp invoke <tool> --detach` — Start the call and return its invocation id without waiting.
- `webmcp invoke <tool> --timeout <ms>` — Bound a blocking invocation in milliseconds.
- `webmcp result <id>` — Wait for or read a detached invocation result; accepts `--timeout <ms>`.
- `webmcp cancel <id>` — Cancel an active detached invocation.

`webmcp invoke`, `webmcp result`, and `webmcp cancel` can run page code that changes or navigates the document. The wrapper refreshes page-target evidence and invalidates prior `@e…` refs after these commands. A detached invocation that still reports `pending`, or fails to settle while its target is unknown, leaves the target unverified rather than trusting the immediate URL probe; `result`, `cancel`, `get url`, and explicit navigation remain available for recovery. `details.nextActions` replaces the blocked snapshot suggestion with `verify-page-target-after-pending-webmcp` (`get url`) and warns that the detached tool remains unsettled. After a completed WebMCP mutation, run `snapshot -i` before reusing refs; inside `batch --bail`, put `get url` before that snapshot. `webmcp list` does not invalidate refs. Attached browsers, providers, Lightpanda, Safari/iOS, and Chrome builds without the experimental CDP domain may return `webmcp_unsupported`.

### Tabs

Stable tab ids look like `t1`, `t2`, and `t3`. Optional user labels such as `docs` or `app` are interchangeable with ids wherever a tab reference is accepted. Upstream help may refer to numeric tab positions, but this wrapper guidance uses stable `t<N>` ids because positional integers are not accepted by current upstream `agent-browser`.

- `tab` — List open tabs by default.
- `tab list` — List open tabs with ids and labels.
- `tab new [url]` — Open a new tab.
- `tab new --label <name> [url]` — Open a new tab with a user label.
- `tab <t<N>|label>` — Switch to a tab by id or label. CDP target ids from `tab list --json` are also accepted and stay stable across daemon restarts.
- `tab close [t<N>|label|target]` — Close the current tab or a referenced tab. Generic references in workflows may say `tab close [target]`; use a stable `t<N>` id, label, or CDP target id when you have one.

The wrapper persists native CDP `targetId` when available so resume/branch recovery distinguishes tabs with the same URL and title. A missing known target requires explicit tab recovery; older transcripts without IDs still use URL matching, and a cold managed reopen adopts its new ID. Failed reached batch navigations retire earlier targets and recheck the live page, including Chrome error pages, before subsequent inspection.

After successful tab creation, selection, or close, including dispatched native batch rows, the wrapper live-probes `get url` and, for non-blank pages, `get title` before committing the active target. Tab transitions always refresh the title even when the URL matches the prior tab. New blank tabs, explicitly selected `about:blank` tabs, and blank tabs revealed by close remain active instead of triggering prior-tab correction. A successful probe clears the unverified-page gate for the next command; if the probe fails, `details.sessionTabTargetUnknown` stays true and recovery still starts with `get url`.

With `--pin-tab`, a closed bound tab fails as `tab_gone` (`data.targetId`, optional `data.lastUrl`) instead of falling back to another tab.

### Snapshot

| Option                                            | Purpose                                                                                                  |
| ------------------------------------------------- | -------------------------------------------------------------------------------------------------------- |
| `snapshot`                                        | Full accessibility tree with refs.                                                                       |
| `snapshot -i` / `snapshot --interactive`          | Include only interactive elements.                                                                       |
| `snapshot -i --urls`                              | Include only interactive elements and link hrefs.                                                        |
| `snapshot -u` / `snapshot --urls`                 | Include href URLs for link elements.                                                                     |
| `snapshot -C` / `snapshot --cursor`               | Deprecated no-ops; cursor-interactive elements are included by default.                                  |
| `snapshot -c` / `snapshot --compact`              | Remove empty structural elements.                                                                        |
| `snapshot -d <n>` / `snapshot --depth <n>`        | Limit tree depth.                                                                                        |
| `snapshot -s <sel>` / `snapshot --selector <sel>` | Scope to a CSS selector.                                                                                 |
| `snapshot --delta` / `snapshot --delta --full`    | Native revision-relative observation or a forced full baseline; see [0.38.1](#upstream-0381-rebaseline). |

When a snapshot is too large for inline output, the Pi wrapper renders a compact view before spilling the full redacted snapshot to `details.fullOutputPath`. Compact snapshots are main-content-first, but dense pages and desktop host screens can still hide actionable controls in omitted content; scan `Omitted high-value controls` before opening the spill file. That bounded section favors editable/searchbox/textbox/combobox controls, named tab/surface controls, primary action buttons, and named action links such as row/navigation links and repository-style result links, then includes other useful controls such as checkboxes, radios, options, and menuitems that were not already listed under key refs or other refs. When that section appears, `details.data.highValueControlRefIds` repeats the same visible ref ids for programmatic follow-up alongside fields such as `previewMode`, `previewSections`, and counts on `details.data` (see [`TOOL_CONTRACT.md`](TOOL_CONTRACT.md#details)).

For dense pages, the wrapper also accepts `snapshot -i --search <text>` and `snapshot -i --filter role=<role>` as wrapper-side filters. It runs upstream `snapshot` without those wrapper-only flags, records the full returned ref map in `details.refSnapshot` for stale-ref safety, and renders matching direct refs plus surrounding snapshot context in the model-visible snapshot with `details.snapshotFilter` counts. Search also runs one bounded read-only rendered-DOM text probe across the full document, including below-fold content and accessible labels, so visible warnings or label-only controls omitted from the accessibility snapshot still surface under `Rendered page text matches`; hidden elements stay excluded. The visible summary distinguishes direct ref matches from rendered-text/context matches so contextual output does not look like a ref-count mismatch. Add wrapper-side `--viewport` when scroll position, viewport size, document size, and sampled scroll-container offsets matter; it runs one read-only `eval --stdin` probe and reports `details.snapshotViewport`. Add wrapper-side `--diff` to compare the current ref map with the previous wrapper-tracked snapshot for that session and report `details.snapshotDiff` added/removed/changed refs. Use these flags when you need controls like checkout buttons, all comboboxes, above/below-fold context, or a quick before/after ref delta without reading a full spill file.

### Wait

| Mode                                    | Purpose                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| --------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `wait <selector>`                       | Wait for an element to appear.                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| `wait <ms>`                             | Wait for a fixed number of milliseconds; the duration is positional, not `--time <ms>`. The native Pi wrapper now forwards long waits and derives a subprocess watchdog from the explicit wait duration when the caller does not provide top-level `timeoutMs`.                                                                                                                                                                                                |
| `wait --url <pattern>`                  | Wait for the URL to match a pattern. On timeout the wrapper appends a `fresh-session-after-url-wait-timeout` next action (`sessionMode: "fresh"` + `open about:blank`, after the inspect action): if a preceding click or submit reported success but the page never navigated, upstream click dispatch may have silently missed, so replace about:blank with the target URL and replay the flow as one batch in a fresh session instead of retrying the wait. |
| `wait --load <state>`                   | Wait for load state: `load`, `domcontentloaded`, or `networkidle`.                                                                                                                                                                                                                                                                                                                                                                                             |
| `wait --fn <expression>`                | Wait for a JavaScript expression to become truthy.                                                                                                                                                                                                                                                                                                                                                                                                             |
| `wait --text <text>`                    | Wait for text to appear on the page; failures may include `inspect-after-text-assertion-failure` with a session-scoped `snapshot -i` payload.                                                                                                                                                                                                                                                                                                                  |
| `wait --download [path]`                | Wait for a download started by a previous action and optionally save it to `path`; successful wrapper results include upstream-reported `savedFilePath`/`savedFile`, while `details.artifacts[].exists` is the wrapper's on-disk verification signal.                                                                                                                                                                                                          |
| `wait --download [path] --timeout <ms>` | Set download-start timeout in milliseconds. The native Pi wrapper forwards explicit wait timeouts and extends the subprocess watchdog unless the caller supplies top-level `timeoutMs`.                                                                                                                                                                                                                                                                        |

Current upstream still does not parse `wait <selector> --state hidden` / `wait <selector> --state detached` as distinct wait modes even though upstream help mentions those examples. Use `wait --fn "!document.querySelector('#spinner')"` or another explicit JavaScript predicate for disappearance/detach checks until upstream parser support exists.

### Diff, debug, and streaming

- `diff snapshot` — Compare current versus last snapshot. Use `diff snapshot --baseline <file> --selector <sel> --compact --depth <n>` when you need a saved baseline, scoped subtree, compact output, or depth bound.
- `diff screenshot --baseline` — Compare current screenshot versus a baseline image. Use `diff screenshot --baseline <file> --output <file> --threshold <0-1> --selector <sel> --full` when you need a saved diff image, threshold tuning, element scope, or full-page capture.
- `diff url <u1> <u2>` — Navigate to both pages and compare them, leaving the second destination active. The wrapper observes the final URL, including redirects to `about:blank`, and invalidates old refs without recovering the old tab; direct and reached batch rows use the same rule. If the URL cannot be observed, run `get url` before taking a fresh snapshot. Use `diff url <u1> <u2> --screenshot --wait-until <strategy> --selector <sel> --compact --depth <n>` when you need screenshot comparison, navigation wait control, or scoped/compact snapshot comparison.
- `trace start`, `trace stop [path]` — Record a Chrome DevTools trace.
- `profiler start|stop [path]` — Record a Chrome DevTools profile.
- `record start <path> [url]` — Record the active page; an optional URL navigates first. Use `.webm` or `.mp4` and optional `--fps <n>` (1–60, default 30); native validates startup and requires `ffmpeg` on `PATH`. Verify output after `record stop`.
- `record stop` — Finalize video and inspect its native receipt plus wrapper file verification. A failed or recovered stop retains original attempt evidence; use a distinct top-level `outputPath` to save its receipt.
- `record restart <path> [url]` — Stop any current recording and start a new video. Supports the same formats and `--fps` option; without a URL it keeps the page and refs.
- `console [--clear]` — View or clear console logs.
- `errors [--clear]` — View or clear page errors.
- `highlight <sel>` — Highlight an element.
- `inspect` — Open Chrome DevTools for the active page.
- `clipboard <op> [text]` — Read/write clipboard: `clipboard read`, `clipboard write <text>`, `clipboard copy`, and `clipboard paste`. Clipboard access is environment-dependent; `NotAllowedError` / permission-denied failures are common in headless, managed-profile, remote, or `file://` sessions.
- `stream enable [--port <n>]` — Start runtime WebSocket streaming for this session. If upstream reports that streaming is already enabled, the wrapper treats it as an idempotent success and adds status/disable follow-ups.
- `stream disable` — Stop runtime WebSocket streaming.
- `stream status` — Show streaming status and active port.
- `react tree` — Print the full React component tree. Requires the page to have been launched with `--enable react-devtools`.
- `react inspect <id>` — Inspect one React fiber's props, hooks, state, and source.
- `react renders start` — Start recording React render activity.
- `react renders stop [--json]` — Stop render recording and print mount/re-render counts and changed details.
- `react suspense [--only-dynamic] [--json]` — Classify Suspense boundaries with grouped root-cause recommendations.
- `a11y [url]` — Run an embedded axe-core accessibility audit on the current page, or navigate to `url` first. Options: `a11y --tags wcag2a,wcag2aa`, `a11y --selector "#main"`. CDP browsers only (not Safari/iOS WebDriver). Model-facing text summarizes violation/incomplete counts and top rules; full node targets stay in `details.data`.
- `vitals [url] [--json]` — Report Core Web Vitals: LCP, CLS, TTFB, FCP, INP, plus React hydration timing when available. `web-vitals [url] [--json]` is the upstream alias.
- `pushstate <url>` — Perform SPA client-side navigation; detects Next.js router pushes and falls back to history navigation events.
- `removeinitscript <id>` — Remove an init script registered through upstream init-script mechanisms.

Recording destinations are reserved within one Pi process, not across processes. Use unique paths for concurrent Pi processes: different explicit sessions can overwrite one file even when both `record stop` results are verified. Upstream’s same-session `record start` guard does not reserve the filename across other sessions.

When these diagnostic commands are invoked through the native `agent_browser` tool, structured console, page-error, React, Web Vitals, and SPA outputs render as compact summaries when possible, with large outputs previewed and spilled instead of dumped into context. Large outputs are previewed with a `Full output path:` spill file instead of dumping the entire payload into context. Artifact-producing commands such as `network har stop`, `diff screenshot`, `trace stop`, `profiler stop`, and `record stop` report `details.artifacts[]` plus `details.artifactVerification`; `record start` / `record restart` are reported as pending until `record stop` completes. For video workflows, keep `ffmpeg` on `PATH` first; on macOS with Homebrew, `brew install ffmpeg` or `brew install ffmpeg-full` is sufficient. Native 0.37 checks `ffmpeg` before capture and native `doctor` checks its encoders. Older supported natives may report pending output first; `details.recordingDependencyWarning` marks that output unverified, not recoverable merely by installing ffmpeg before stop. The README install section keeps the concise external-dependency list for maximal extension use.

Long-running or lifecycle commands should be explicitly paired with cleanup calls: `stream enable` → `stream disable`, `dashboard start` → `dashboard stop`, `trace start` → `trace stop`, `profiler start` → `profiler stop`, and `record start` → `record stop`. The wrapper keeps each subprocess bounded by its normal timeout; it does not keep an interactive `chat` REPL open, so prefer `chat <message>` with `--model` or `AI_GATEWAY_MODEL` for single-shot AI use.

`trace` and `profiler` share upstream Chrome tracing machinery. Do not run them at the same time. The wrapper tracks owner state it observes in the current Pi session and blocks conflicting starts/stops with "wrapper believes ..." wording because direct upstream CLI use or browser restarts can desynchronize wrapper-local state.

### Batch, auth, confirmations, sessions, chat, dashboard, devices, and setup

Auth profiles are shared in upstream's HOME-level `~/.agent-browser/auth` store:
`auth save`, `list`, `show`, `delete`, and `remove` do not select a browser, and
`--session` does not create a separate credential store. Saving a profile alone
does not log in. `auth login <name>` applies a shared profile to the selected
browser, preserving an unqualified call's active automatic root or managed session.
Use distinct auth-profile names for separate accounts; use sessions, persistent
browser profiles, or `state save/load` to separate cookies and storage.

| Command                                            | Purpose                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| -------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `batch [--bail] ["cmd" ...]`                       | Execute multiple commands sequentially from args or stdin. Put global flags before `batch`; native 0.42.0 rejects them inside an item.                                                                                                                                                                                                                                                                                                            |
| `auth save <name> [opts]`                          | Save an auth profile. Full credential form: `auth save <name> --url <url> --username <user> --password <pass>`; selector override form: `auth save <name> --username-selector <s> --password-selector <s> --submit-selector <s>`. Prefer `auth save <name> --password-stdin` with the tool `stdin` field; avoid putting passwords in `args`.                                                                                                      |
| `auth login <name>`                                | Login using saved credentials; add `--no-navigate` for a prepared, same-origin login page.                                                                                                                                                                                                                                                                                                                                                        |
| `auth list`                                        | List saved auth profiles.                                                                                                                                                                                                                                                                                                                                                                                                                         |
| `auth show <name>`                                 | Show auth profile metadata.                                                                                                                                                                                                                                                                                                                                                                                                                       |
| `auth delete <name>`                               | Delete an auth profile; `auth remove <name>` is the upstream alias.                                                                                                                                                                                                                                                                                                                                                                               |
| `confirm <id>`                                     | Approve a pending action.                                                                                                                                                                                                                                                                                                                                                                                                                         |
| `deny <id>`                                        | Deny a pending action.                                                                                                                                                                                                                                                                                                                                                                                                                            |
| `session`                                          | Show current session name.                                                                                                                                                                                                                                                                                                                                                                                                                        |
| `session list`                                     | List active sessions.                                                                                                                                                                                                                                                                                                                                                                                                                             |
| `chat <message>`                                   | Send a natural-language instruction.                                                                                                                                                                                                                                                                                                                                                                                                              |
| `chat`                                             | Start interactive chat when stdin is a TTY.                                                                                                                                                                                                                                                                                                                                                                                                       |
| `dashboard [start]`                                | Start the dashboard server on the default port `4848`.                                                                                                                                                                                                                                                                                                                                                                                            |
| `dashboard start --port <n>`                       | Start the dashboard on a specific port.                                                                                                                                                                                                                                                                                                                                                                                                           |
| `dashboard start --allowed-origins <origins>`      | Allow comma-separated exact HTTPS reverse-proxy origins. Environment: `AGENT_BROWSER_DASHBOARD_ALLOWED_ORIGINS`.                                                                                                                                                                                                                                                                                                                                  |
| `dashboard stop`                                   | Stop the dashboard server.                                                                                                                                                                                                                                                                                                                                                                                                                        |
| `device list`                                      | List available iOS simulators. Use with `-p ios` when exercising iOS provider flows.                                                                                                                                                                                                                                                                                                                                                              |
| `install`                                          | Install browser binaries.                                                                                                                                                                                                                                                                                                                                                                                                                         |
| `install --with-deps`                              | Install browser binaries plus Linux system dependencies; exits nonzero when required libraries cannot be installed.                                                                                                                                                                                                                                                                                                                               |
| `upgrade`                                          | Upgrade `agent-browser` using its detected package manager. Native output is text, even with `--json`; the wrapper displays it with surrounding whitespace trimmed and normal redaction, and exposes it in `details.data`. Caller-requested `--json` stays a parseable result with the text in `data`. Nonzero exits, spawn failures, timeout and cancellation remain failures; failed upgrade stdout and stderr remain available as diagnostics. |
| `doctor [--fix]`                                   | Diagnose install issues and optionally auto-clean stale files. Use `doctor --offline --quick` for a fast local-only check and `doctor --json` for structured output.                                                                                                                                                                                                                                                                              |
| `plugin add <ref>`                                 | Add a plugin from npm or GitHub (`<owner>/<repo>` or `@scope/<name>`). `--global` (default) writes `~/.agent-browser/config.json`; `--project` writes `./agent-browser.json`, whose plugins load only with explicit `--config ./agent-browser.json`. `--name`, `--capability`, and `--no-manifest` shape discovery.                                                                                                                               |
| `plugin [list]`                                    | List configured plugins (default subcommand); `{ "plugins": [...] }` is a successful sessionless result.                                                                                                                                                                                                                                                                                                                                          |
| `plugin show <name>`                               | Show one configured plugin; `{ "plugin": {...} }` is a successful sessionless result.                                                                                                                                                                                                                                                                                                                                                             |
| `plugin run <name> <type>`                         | Run a `command.run` or custom plugin request over the agent-browser plugin stdio protocol.                                                                                                                                                                                                                                                                                                                                                        |
| `auth login <name> --credential-provider <plugin>` | Resolve credentials just-in-time from a configured credential plugin (e.g. a vault) instead of saved passwords; pair with `--item <ref>` and optional selector overrides. Credentials are not stored locally.                                                                                                                                                                                                                                     |
| `mcp --help`                                       | Show MCP server help through the native tool.                                                                                                                                                                                                                                                                                                                                                                                                     |
| `mcp`                                              | Native MCP stdio server for external clients; `mcp call <tool>` is the finite native alternative. The wrapper currently rejects every non-help MCP invocation, including finite calls. External clients can opt into experimental page tools with `mcp --tools core,webmcp`; see the MCP boundary.                                                                                                                                                |
| `profiles`                                         | List available Chrome profiles.                                                                                                                                                                                                                                                                                                                                                                                                                   |

When these commands are invoked through the native `agent_browser` tool, structured diagnostic/status outputs are rendered as compact summaries. `session list` and `state list` keep every upstream row and restore identifier visible. Explicit sessions, state/restore paths, broad state lifecycle commands, config, local files, and launch environment pass through unchanged. Local inspection/setup calls remain sessionless unless you explicitly pass `--session`; browser-backed or context-dependent calls keep normal managed-session behavior when no explicit session is supplied. List-like outputs such as sessions, Chrome profiles, auth profiles, network requests, console messages, and page errors include counts and key fields; large outputs are previewed with a `Full output path:` spill file instead of dumping the entire payload into context. For `network requests`, the wrapper shows a failed-request summary split into actionable versus benign low-impact rows, then status, method, URL, resource/mime type, request id, and, when the installed upstream output includes body-like fields, bounded redacted payload, response, and failure/error snippets. Safe request IDs also produce `details.nextActions` for exact request details, actionable failed-request source lookup candidates, filtered request lists, or starting HAR capture before a repro. If the same session has active wrapper-observed network routes, failed/pending/CORS-looking matched request rows add `details.networkRouteDiagnostics` and executable route-mock next actions before the generic request actions. `data:image` artifact rows are omitted from compact request previews but remain in raw `details.data.requests`. `network request <requestId>` can expose upstream full-detail body fields such as response bodies using the same bounded model-facing preview; its request URL stays diagnostic-only and does not overwrite `details.sessionTabTarget` for later ref guards. Clipboard failures that mention `NotAllowedError` or permission denial are usually browser/OS capability limits, not proof that a read, paste, or page mutation happened; prefer page-native reads (`snapshot -i`, `get text`, `eval --stdin`) or direct typing (`keyboard inserttext` / `keyboard type`) when the workflow allows it, and retry true clipboard flows only from an allowed profile/session on a normal `http(s)` page. Header, cookie, auth, token, and other secret-like fields are not expanded in model-facing text or `details.data`; low-risk primitive storage values may remain visible, while command echoes still redact `--body`, `--headers`, `--password`, proxy credentials, auth-bearing URLs, `clipboard write` text, cookie/storage set values, and bearer/basic credential text in positional arguments. Raw batch row strings receive the same command-aware redaction in visible output and ordered transition journals without changing execution argv. Use upstream HAR or full raw details only when complete data is required.

### Saved flows (experimental)

Native 0.42.0 can record a session and save part of it as a flow that later runs over direct HTTP, then from the page, then by replaying the recorded commands. Upstream marks this experimental: a run can fail on a page that changed.

- `--capture <list>` — Record the session; only `flow` is supported. Environment: `AGENT_BROWSER_CAPTURE`. It is a launch setting, so use it on the first command of a session or with `sessionMode: "fresh"`.
- `flow steps [--json]` — List the recorded steps: number, command, URL, request count, and ok or failed.
- `flow save <name>` — Save steps as a flow. Options: `--from <seq>`, `--to <seq>`, `--param k=v`, `--output <id>`, `--description <text>`, and `--timeout <ms>`.
- `flow run <name>` — Run a saved flow. Options: `--param k=v`, `--where f=v`, `--fields a,b`, `--limit n`, `--origin <host>`, `--allow-write <all|id,...>`, and `--timeout <ms>`.
- `flow list [--origin <host>]` — List saved flows with params and verified state.

Flows live in `~/.agent-browser/flows/<origin>/<name>.json`; `AGENT_BROWSER_FLOWS_DIR` overrides the directory. Native never saves cookies, `authorization`, or token and CSRF headers.

Wrapper behavior:

- The recording includes the wrapper's own helper reads, such as `get url` and `tab list`. Check `flow steps` and pass `--from` / `--to` when saving.
- `flow run` can navigate the page when it falls back to replay. After it, the page target is unknown: run `get url` before page-content commands, and take a new `snapshot -i` before using refs. In a batch, use `batch --bail` and put `get url` after `flow run`. Refs from before a direct or batched `flow run` stay blocked as stale, even when `get url` reports the same URL, until a new `snapshot -i`.
- `flow steps`, `flow save`, `flow list`, and `flow run` do not need a verified page target.
- Flow results pass through with the normal redaction. The wrapper adds no flow storage, naming, or retry layer.

## Optional package config and companion web search

`pi-agent-browser-native` has package-owned config under Pi-scoped paths. This is separate from upstream `agent-browser` config and from Pi package settings:

- global: `~/.pi/config/pi-agent-browser-native/config.json`
- project-local: `.pi/config/pi-agent-browser-native/config.json`
- explicit override: `PI_AGENT_BROWSER_CONFIG=/path/to/config.json`

Get an Exa API key from the [Exa dashboard](https://dashboard.exa.ai/api-keys) or a Brave Search API key from the [Brave Search API dashboard](https://api-dashboard.search.brave.com/). If both keys are available, `agent_browser_web_search` prefers Exa by default because its `/search` endpoint returns token-efficient highlights and agent-oriented search modes; set `webSearch.preferredProvider` to `"brave"` when Brave Search is preferred. You can also disable this package's search tool with `webSearch.enabled: false` when another search tool should win. Config merges global → project → `PI_AGENT_BROWSER_CONFIG` override, so `enabled` is read from the final loaded config: a global disable can be re-enabled by project or override config, while an override file with `enabled: false` is the highest-priority hard disable for that run. Globally installed or CLI-loaded copies read project-local config under `.pi/config/...` when Pi's native trust decision permits it, and skip that layer when the project is untrusted or Pi is launched with `--no-approve`.

`pi install npm:pi-agent-browser-native` loads the extension, but it does **not** usually put the package helper on your shell `PATH`. The clearest setup is to write the config file directly and keep actual keys in the environment that launches `pi`:

```bash
mkdir -p ~/.pi/config/pi-agent-browser-native
cat > ~/.pi/config/pi-agent-browser-native/config.json <<'JSON'
{
  "version": 1,
  "webSearch": {
    "enabled": true,
    "preferredProvider": "exa",
    "defaultSearchType": "deep-lite",
    "exaApiKey": "$EXA_API_KEY",
    "braveApiKey": "$BRAVE_API_KEY"
  }
}
JSON
```

`pi install` does not add package helper binaries to your shell `PATH`. Use direct JSON config edits, or run the helper only through `npm exec`:

```bash
npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config paths
npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config show
npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search set-env EXA_API_KEY --global
npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search set-env BRAVE_API_KEY --global
npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search set-env EXA_API_KEY --project
npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search prefer brave --global
npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search disable --global
npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search disable --project
npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search set-command "op read 'op://Private/Brave Search/API Key'" --provider brave --global
printf '%s' "$EXA_API_KEY" | npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search set-key --provider exa --stdin
npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config browser profile set "Profile 1" --policy authenticated-only
npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config browser executable set "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"
```

The optional `agent_browser_web_search` tool is available when Exa or Brave credentials are visible from startup config or trusted session config and the runtime config has not set `webSearch.enabled` to `false`. It is a separate custom tool, not an `agent_browser` input mode, and does not launch a browser. Prefer it for current/live external web facts and URL discovery; use `agent_browser` for browser interaction, screenshots, authenticated/profile pages, and DOM inspection after you have a target URL. Prefer it over driving public search-engine forms such as Google with browser typing flows, which can redirect headless automation to anti-bot or CAPTCHA pages; do not attempt CAPTCHA bypass. Disable scope is explicit: `web-search disable --global` sets the normal user default, `web-search disable --project` disables it for one repo, and a `PI_AGENT_BROWSER_CONFIG` override containing `{ "version": 1, "webSearch": { "enabled": false } }` wins over both for a hard per-run disable. Loaded config may use plaintext, custom env aliases, interpolation literals, malformed-or-late-bound `$` values, and command-backed web-search keys; the resolved secret reaches the provider request while model-facing tool output and status text stay redacted. Malformed config files report their scope/path and `Invalid JSON`, plus the parser's numeric position/line/column when available; malformed provider JSON reports a provider-specific invalid-JSON error. Neither includes parser previews or parser causes that could echo partial credentials, and provider HTTP failures report only the status with a fixed hint. `web-search set-key`, `set-command`, and `clear` require `--provider`; `set-env` infers Exa/Brave from `EXA_API_KEY` or `BRAVE_API_KEY` unless you pass `--provider`.

For Exa, effective search type precedence is per-call `searchType` → `webSearch.defaultSearchType` → `auto`, with regular `contents.highlights: true`. Typical latencies are `instant` ~250 ms, `fast` ~450 ms, `auto` ~1 second, `deep-lite` ~4 seconds, `deep` 4–15 seconds, and `deep-reasoning` 12–40 seconds. Prefer `deep-lite` for research before implementation, `deep` for hard multi-source work, and `deep-reasoning` only for exhaustive or still-thin research. Searches are serialized; do not launch several in parallel.

```json
{
	"query": "pi-agent-browser-native agent_browser_web_search searchType defaults",
	"searchType": "deep-lite",
	"count": 5
}
```

Exa-only options include 1–20 `includeDomains` / `excludeDomains`, a six-value `category`, 1–10 deep-mode `additionalQueries`, and `highlightsDynamic`. The `company` and `people` categories cannot combine with `freshness` or `excludeDomains`; invalid combinations fail before the request. Explicit new Exa-only options also fail if Brave resolves as the provider, while the existing `searchType` field remains ignored by Brave. `highlightsDynamic: true` is a research preview and sends Exa's required beta header. Full page text and structured output schemas remain out of scope.

Every Exa request includes a fixed provider instruction to favor primary official sources, requested versions/dates, and distinct results. After normalization, both provider adapters remove later results only when their normalized URLs are exactly equal, retain the first row and provider order, and do not overfetch replacements or guess that distinct paths/query URLs are aliases. `details.duplicatesRemoved` reports removed rows, so returned results may be fewer than `count`. `pageDate` is Exa's estimated `publishedDate` or Brave's `page_age`; Brave may also supply `age`. Neither field proves crawl/retrieval age or a version match. When correctness or version matters, use the page/date clues, constrain one follow-up to the primary domain (`includeDomains` for Exa or `site:` in a Brave query), and read the primary page.

Example config:

```json
{
	"version": 1,
	"webSearch": {
		"enabled": true,
		"preferredProvider": "exa",
		"defaultSearchType": "deep-lite",
		"exaApiKey": "$EXA_API_KEY",
		"braveApiKey": "$BRAVE_API_KEY"
	},
	"browser": {
		"defaultProfile": {
			"name": "Profile 1",
			"policy": "authenticated-only"
		},
		"executablePath": "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"
	}
}
```

Browser defaults are scoped: global/override `defaultProfile` with `policy: "always"` and a Chrome profile name (not a path), plus `executablePath`, become native subprocess defaults only for automatic root browsers and their helpers when the effective engine is Chrome. Lightpanda omits these wrapper defaults, without changing caller-selected launch settings. Roots have distinct named sessions and restore keys; parents and descendants share one root through pi-subagents' equal `PI_INTERCOM_ROOT_SESSION_ID`/`PI_INTERCOM_PARENT_SESSION_ID` (or older `PI_SUBAGENT_CHILD=1` with `PI_SUBAGENT_ROOT_SESSION_ID`). These defaults never apply to unrelated explicit sessions or Electron launches. Profile paths, other policies, and project-only guidance remain advisory. Native restore keeps cookies/localStorage/sessionStorage, not new IndexedDB, service workers, or memory-only grants; verify app access after a real restart. Avoid global native profile changes or a shared writable profile path; see [shared browser defaults](REFERENCE.md#shared-browser-defaults). Configure profile/executable guidance globally, in trusted project config, or through `PI_AGENT_BROWSER_CONFIG`. Ask the agent to run `profiles` and `doctor` when profile resolution fails, then use the reported Chrome profile directory name, a full profile/user-data directory path if upstream accepts one, or the configured `browser.executablePath` with top-level `sessionMode: "fresh"`.

## Important global flags, config, and environment

### Authentication and session flags

`agent-browser` 0.35.0 and newer require separate argv tokens for global flag values (for example, `--args <args>` and `--user-agent <ua>`). The explicit exception is `--restore=<key>`, which is supported when an optional restore key could otherwise be confused with a command word. The wrapper rejects other global `--flag=value` forms before normal command dispatch, including when they trail the command. Plain `--help`, `-h`, `--version`, and `-V` inspection preserves exact caller argv because upstream accepts those top-level inspection shapes. Global flags for `batch` belong before `batch` in top-level `args`; row-local equals forms are rejected without the help/version or `--restore=<key>` exceptions. A `--` token ends global-flag parsing as it does upstream: later tokens are literal command text, so the wrapper does not read them as session, restore, launch, help, or version flags.

- `--profile <name|path>`: reuse Chrome profile login state by directory name from `profiles`, or use a persistent custom profile/profile-directory path when upstream accepts it. Environment: `AGENT_BROWSER_PROFILE`.
- `--session <name>`: use an isolated session. Environment: `AGENT_BROWSER_SESSION`. Native session names may begin with a hyphen; they remain values, not extra flags, including when selected through config or environment.
- `--restore [name]`: auto-save/restore cookies, local storage, and session storage; bare `--restore` uses `--session` as the key. Environment: `AGENT_BROWSER_RESTORE`. Wrapper-owned implicit sessions set a transcript- and checkout-scoped restore key automatically unless disabled with `PI_AGENT_BROWSER_MANAGED_SESSION_RESTORE=0` or suppressed by incompatible caller launch choices. Explicit restore/state/session/config choices pass through unchanged and remain visible in results. Automatic restore validates only its own checkout/storage identity and coordinates same-daemon reuse so wrapper restore pools cannot mix.
- `--restore-save <policy>` (`auto`, `always`, or `never`): restore auto-save policy. Environment: `AGENT_BROWSER_RESTORE_SAVE`. Restore-enabled sessions also save periodically while open; `AGENT_BROWSER_AUTOSAVE_INTERVAL_MS` sets the minimum interval in milliseconds (`30000` by default, `0` disables periodic saves but not save-on-close).
- `--restore-check-url <glob>`, `--restore-check-text <txt>`, `--restore-check-fn <js>`: validate restored state before auto-save. Environments: `AGENT_BROWSER_RESTORE_CHECK_URL`, `AGENT_BROWSER_RESTORE_CHECK_TEXT`, `AGENT_BROWSER_RESTORE_CHECK_FN`.
- `--namespace <name>`: isolate daemon sockets and restore-state directories. Environment: `AGENT_BROWSER_NAMESPACE`. Upstream and the wrapper canonicalize namespace identity to a lowercase sanitized component (for example, `Team Name` becomes `team-name`).
- `--session-name <name>`: legacy alias for restore persistence key. Environment: `AGENT_BROWSER_SESSION_NAME`.
- `--state <path>`: load saved auth state from JSON. Environment: `AGENT_BROWSER_STATE`.
- `--auto-connect`: connect to a running Chrome; Tron refuses it (`owned_launch_required`), so use a recorded owned launch for signed-in state. Environment: `AGENT_BROWSER_AUTO_CONNECT`. Optional booleans use separated tokens (`--auto-connect false`); the wrapper rejects `--auto-connect=false` before dispatch.
- `--no-auto-connect`: return a session attached with `--auto-connect` to a local launch; it overrides the environment and an earlier `--auto-connect`. `--no-auto-connect false` is a no-op.
- `--relaunch`: relaunch the session's browser even when no setting changed. The page and refs are discarded; open the page again.
- `--capture <list>`: record the session as it runs; only `flow` is supported. Environment: `AGENT_BROWSER_CAPTURE`. On a running session without capture it relaunches the browser. See [saved flows](#saved-flows-experimental).
- `--pin-tab`: pin the session to its bound tab. Environment: `AGENT_BROWSER_PIN_TAB`. Sticky per session and not launch-scoped. Commands fail with `tab_gone` instead of falling back when that tab is closed. `--no-pin-tab` disables a previously enabled pin. Optional booleans use separated tokens (`--pin-tab false`).
- `--headers <json>`: apply HTTP headers scoped to the opened URL's origin.
- `--init-script <path>`: register a script before first navigation; repeatable. Environment: `AGENT_BROWSER_INIT_SCRIPTS`.
- `--enable <feature>`: enable built-in init scripts such as `react-devtools`; repeatable or comma-separated. Environment: `AGENT_BROWSER_ENABLE`.

### Browser launch and runtime flags

The extension composes stock `--args --no-startup-window` for local Chrome startup only when native environment/config does not already supply local launch defaults. Otherwise no automatic Chrome startup arguments are injected; include `--no-startup-window` in native `args` if a single headed window is required. Headless remains the default, external engines/attachments stay native-owned, and caller settings retain native precedence. Plain active follow-ups do not repeat wrapper bootstrap settings. A follow-up that carries a launch flag gets the stock startup argument again, joined with that call's `--args`, so an exact repeat of the launch flags keeps the browser. A changed launch setting makes native 0.42.0 relaunch the browser; the result reports that relaunch. This includes a follow-up that carries a launch flag but drops the `--args` value used at launch: repeat the same `--args`, or pass no launch flag. URL-less `open` runs native `get url` to lazily launch or preserve the active page, including batch rows; the result exposes the actual command and URL, not a fabricated launch receipt. See [the startup contract](TOOL_CONTRACT.md#headed-and-local-fixture-limits).

- `--executable-path <path>`: custom Chromium-compatible browser executable, such as Brave/Edge/Arc/Vivaldi when upstream can launch that binary. Environment: `AGENT_BROWSER_EXECUTABLE_PATH`.
- `--extension <path>`: load browser extensions; repeatable. Environment: `AGENT_BROWSER_EXTENSIONS`.
- `--args <args>`: browser launch args, newline separated or comma separated before another flag; commas and negative coordinates inside values stay intact. Chromium switches belong in this value, for example `{ "args": ["--args", "--no-sandbox", "open", "https://example.com"], "sessionMode": "fresh" }`. A bare `--no-sandbox` is diagnosed when it occupies the command slot (unknown command) or an `open` / `goto` / `navigate` option position (ignored by upstream); literal operands in other commands are left alone. For batches, put `--args` before `batch` in top-level `args`, not inside a row. Environment: `AGENT_BROWSER_ARGS`.
- `--user-agent <ua>`: custom user agent. Environment: `AGENT_BROWSER_USER_AGENT`.
- `--proxy <server>`: proxy server URL. Credentials are percent-decoded on native 0.42.0. Environments: `AGENT_BROWSER_PROXY`, `HTTP_PROXY`, `HTTPS_PROXY`, `ALL_PROXY`.
- `--proxy-bypass <hosts>`: proxy bypass hosts. Environments: `AGENT_BROWSER_PROXY_BYPASS`, `NO_PROXY`.
- `--ignore-https-errors`: ignore HTTPS certificate errors. Environment: `AGENT_BROWSER_IGNORE_HTTPS_ERRORS`.
- `--ca-cert <path>`: add a PEM bundle or DER certificate to CLI HTTPS trust on every platform. Environment: `AGENT_BROWSER_CA_CERT`. For `read`, explicit CLI trust is retained per native session through daemon restarts until close; `--no-ca-cert` / `AGENT_BROWSER_CLEAR_CA_CERT` clears it. An unusable explicit file fails; an unusable ambient `SSL_CERT_FILE` fallback is ignored with a warning. CLI trust does not launch a browser or configure remote CDP/provider TLS.
- `--use-system-ca`: use OS roots instead of built-in Mozilla roots for CLI requests from `read`, `install`, `upgrade`, and `doctor`. Environment: `AGENT_BROWSER_USE_SYSTEM_CA`; native config: `useSystemCa`. A separated `--use-system-ca false` overrides it; `read` retains explicit selections until close. A supplied CA file adds to the selected roots. Certificate and hostname verification remain enabled.
- Browser CA trust is separate: local Linux Chromium imports `--ca-cert` into an isolated NSS store and requires `certutil`. It rejects profiles, CDP/auto-connect, providers, non-Chrome engines, `--ignore-https-errors`, macOS, and Windows. The wrapper treats `--ca-cert` and `--no-ca-cert` as launch-scoped for managed browsers; use `sessionMode: "fresh"`. Automatic managed restore is disabled for CA-enabled browser sessions, and caller certificate paths pass through unchanged.
- `--allow-file-access`: upstream capability passed through unchanged from argv or `AGENT_BROWSER_ALLOW_FILE_ACCESS`. Raw `--args` / `AGENT_BROWSER_ARGS`, local file navigation, local-page follow-ups, and caller-selected paths remain upstream-owned. The wrapper adds only its fixed compatibility user-agent argument on eligible new managed launches; it does not clear or replace caller launch settings. Ambiguous page-target transitions still require `get url` before later content calls so the agent cannot silently act on the wrong page.
- `--hide-scrollbars <bool>`: explicitly show or hide native scrollbars in headless Chromium screenshots.
- `--headed`: ask upstream to show the browser window. Environment: `AGENT_BROWSER_HEADED`. Use it on the first launch, normally with `sessionMode: "fresh"` when changing an existing managed session. Successful first/fresh local wrapper-managed launches can expose `details.browserWindow.visibility: "unverified"` and a login handoff; attached browsers cannot, but still verify actual OS visibility with the user or screenshot/tab evidence.
- `--webgpu`: enable upstream's platform-specific WebGPU launch preset. Environment: `AGENT_BROWSER_WEBGPU`; config: `"webgpu": true`. Use it on a fresh local launch. It is incompatible while enabled with `--cdp`, `--auto-connect`, and provider launches. `AGENT_BROWSER_NO_XVFB=1` disables upstream's automatic Xvfb for displayless headed Linux sessions.
- `--no-webmcp`: disable experimental WebMCP support, which upstream 0.36.0 enables by default for locally managed Chrome. Environment: `AGENT_BROWSER_NO_WEBMCP`; config: `noWebmcp`. Use it on a fresh launch; `--no-webmcp false` explicitly enables the launch feature when config or environment disabled it.
- `--cdp <port|url>`: connect through Chrome DevTools Protocol. Use it, `--auto-connect`, or `connect <port|url>` once on a named/fresh session, verify with `get url`, then reuse that session without repeating the attach flag. After a successful attachment the wrapper avoids re-emitting its own compatibility launch argument; caller launch/config/file-access settings remain unchanged. Content-bearing first use is blocked until URL verification; later page reads/interactions live-check the URL because the attached browser can drift externally. `close` clears attachment state.
- `--cdp-headers <json>`: send a JSON object of string-valued headers for native CDP HTTP discovery and WebSocket authentication. Environment: `AGENT_BROWSER_CDP_HEADERS`. Supply it with the initial `--cdp` call or an explicit `connect`; these are transport credentials, not page/origin `--headers`. Values pass through unchanged and are redacted from invocation presentation. Published stock help advertises this flag.
- `--color-scheme <scheme>`: `dark`, `light`, or `no-preference`. Environment: `AGENT_BROWSER_COLOR_SCHEME`.
- `--download-path <path>`: default browser download directory. Environment: `AGENT_BROWSER_DOWNLOAD_PATH`.
- `--engine <name>`: `chrome` by default, `lightpanda`, or experimental `obscura`. Environment: `AGENT_BROWSER_ENGINE`. Launch-scoped; use `sessionMode: "fresh"` when changing a managed browser. See [Lightpanda](#lightpanda-engine) and [Obscura](#obscura-engine-experimental).

On Android/Termux, follow the [native Android setup](REFERENCE.md#android--termux) to build an Android-native CLI, install Termux's `which`, and expose its Chromium launcher as `$PREFIX/bin/chromium`. Do not substitute the packaged Linux-musl executable: its CLI HTTP requests can fail hostname resolution even when browser navigation works. Prefer native PATH-based system-browser discovery over ambient `AGENT_BROWSER_EXECUTABLE_PATH`: it survives isolated `HOME` values and works for ordinary native calls. Wrapper-generated Android managed identities use a compact 80-bit digest so ordinary namespaces and fresh rotations fit upstream's Unix socket path.

- `--no-auto-dialog`: disable automatic dismissal of alert/beforeunload dialogs. Environment: `AGENT_BROWSER_NO_AUTO_DIALOG`. Explicit `true`/`false` reaches all helpers in that call; keep the same selection on follow-ups to avoid native daemon replacement.
- `--idle-timeout <ms>`: native background browser lifecycle setting (also accepts `10s`, `3m`, `1h`). Caller-owned sessions retain native idle policy; an explicit flag is carried to every helper in that call. Keep it consistent between calls to avoid a native daemon restart. Only wrapper-owned sessions receive the implicit timeout and numeric mismatch check against `PI_AGENT_BROWSER_IMPLICIT_SESSION_IDLE_TIMEOUT_MS`.

### Lightpanda engine

[Lightpanda 1.0](https://lightpanda.io/blog/posts/lightpanda-1-0) is an optional headless engine, installed separately from this package and `agent-browser`. The [native engine guide](https://github.com/vercel-labs/agent-browser/blob/v0.41.0/docs/content/docs/engines/lightpanda.mdx) describes setup. Put its `lightpanda` executable on `PATH`; select it with `--engine lightpanda`, `AGENT_BROWSER_ENGINE=lightpanda`, or native config `engine`. Chrome remains the default.

```json
{ "args": ["--engine", "lightpanda", "open", "https://example.com"], "sessionMode": "fresh" }
{ "args": ["snapshot", "-i"] }
{ "args": ["screenshot", "/tmp/lightpanda-text.png"] }
{ "args": ["close"] }
```

- Engine selection belongs on launch, not routine follow-ups. Changing an active wrapper-managed browser returns the existing fresh-session recovery; caller-owned sessions retain native lifecycle semantics.
- Package `browser.defaultProfile` / `browser.executablePath` Chrome bootstrap defaults are omitted when CLI → environment → native config selects Lightpanda. Caller-selected profile, executable, config and environment values remain untouched; upstream validates combinations.
- `open`, snapshots/refs, form interaction, getters, `eval --stdin` and native batch can work, but successful dispatch is not Chrome-parity visibility or layout evidence. By default Lightpanda skips external stylesheets, images, iframes and workers. Snapshot/hidden-element and overlay/scroll assumptions differ from Chrome.
- Screenshots are PNGs rendering page markdown/text. Native engine metadata identifies them for direct and batch output; standalone geometry samples can also recognize the browser's Lightpanda brand on attachments or older native results. Identified images carry `rendering: "text"` with unknown geometry and no crop/scale mapping. They remain verified image attachments, not graphical captures or a basis for mouse coordinates. Missing provenance stays unknown.
- Lightpanda currently permits one target per browser context; `tab new` can fail. Use separate native sessions for independent pages, or Chrome when the task needs multiple tabs. Do not infer broad authentication/restore parity from a single-origin storage result.
- Native Lightpanda launch rejects Chrome profiles/extensions, headed mode, launch `--state`, WebGPU, file-access switches, Chromium `--args`, and private CA trust. Native WebMCP currently rejects this engine even though Lightpanda advertises its own WebMCP support. There is no wrapper workaround or automatic Chrome fallback; choose a fresh Chrome launch explicitly when those capabilities are needed.
- Lightpanda 1.0 enforces CORS by default, so cross-origin page `fetch`/XHR can fail where earlier Lightpanda did not. Preserve that protection; navigation is a separate capability.
- The 1.0 release provides macOS/Linux x86_64/ARM64 binaries (Linux glibc), not native Windows/Android. Remote CDP or WSL is a separate setup, not native-platform qualification. Telemetry is upstream-owned; `LIGHTPANDA_DISABLE_TELEMETRY=true` opts out.

### Obscura engine (experimental)

[Obscura](https://github.com/vercel-labs/agent-browser/blob/v0.41.0/docs/content/docs/engines/obscura.mdx) is an optional separately installed headless engine. Select it with `--engine obscura`, `AGENT_BROWSER_ENGINE=obscura`, or native config `engine`; `--executable-path <path>` can name its binary. Native owns spawning `obscura serve`, CDP connection, and close cleanup. The wrapper uses the existing engine/fresh-session path, not a second driver or automatic fallback.

```json
{
	"args": [
		"--engine",
		"obscura",
		"--executable-path",
		"/path/to/obscura",
		"open",
		"https://example.com"
	],
	"sessionMode": "fresh"
}
```

- Obscura v0.2.2 has known accessible-name, hidden-element, iframe, and screenshot-fidelity gaps. Successful connection or image verification does not establish Chrome parity. Prefer Chrome for tasks depending on those features.
- Native rejects Chrome profiles, launch `--state`, extensions, headed mode, file access, WebGPU, browser CA trust, Chromium `--args`, and all proxy-bypass settings, including `NO_PROXY` / `no_proxy`, even without a proxy. Remove bypass only when the task does not need it; otherwise use Chrome.
- Discovery and CDP initialization each have a 10-second deadline with bounded failed-start cleanup. Explicit Obscura launches validate this invocation's resolved bypass settings, including after clearing old settings.
- Local/private pages require `OBSCURA_ALLOW_PRIVATE_NETWORK=1` before launch. `AGENT_BROWSER_OBSCURA_STEALTH` enables optional native stealth only when the installed Obscura build supports it; accepted values are `1`, `true`, `yes`, and `on`. These are upstream options, not wrapper policy or proof of fidelity.
- Package Chrome profile/executable defaults are omitted for non-Chrome engines. Caller-selected settings remain untouched. Neither engine is bundled, and optional-engine/provider execution is separate from stock Chrome baseline qualification.

### Output, provider, policy, and AI flags

- `--json`: JSON output. The wrapper injects this automatically for normal tool execution. Environment: `AGENT_BROWSER_JSON`.
- `--annotate`: annotated screenshot with numbered labels and legend. Environment: `AGENT_BROWSER_ANNOTATE`.
- `--screenshot-dir <path>`: default screenshot output directory. Environment: `AGENT_BROWSER_SCREENSHOT_DIR`.
- `--screenshot-quality <n>`: JPEG quality `0-100`. Environment: `AGENT_BROWSER_SCREENSHOT_QUALITY`.
- `--screenshot-format <fmt>`: `png` or `jpeg`. Environment: `AGENT_BROWSER_SCREENSHOT_FORMAT`.
- `--content-boundaries`: wrap page output in boundary markers. Environment: `AGENT_BROWSER_CONTENT_BOUNDARIES`.
- `--max-output <chars>`: truncate page output to N characters. Environment: `AGENT_BROWSER_MAX_OUTPUT`.
- `--allowed-domains <list>`: restrict browser and `read` traffic to exact or `*.` wildcard domain patterns. Environment: `AGENT_BROWSER_ALLOWED_DOMAINS`. Use a fresh local Chrome context; upstream 0.32.0 owns containment and incompatible-mode rejection and disables Chromium `RTCPeerConnection` while active. The wrapper passes the setting and result through unchanged.
- `--action-policy <path>`: action policy JSON file. Environment: `AGENT_BROWSER_ACTION_POLICY`. Native 0.39.2 denies actions when the selected policy cannot be read or parsed instead of continuing without it. Explicit policy values also reach internal helpers for the current call. Keep the action-policy path consistent on follow-ups; changing or omitting it can restart the native daemon and discard pending confirmations. The established `--confirm-actions` setting is retained for same-session follow-ups.
- `--confirm-actions <list>`: action categories requiring confirmation. Environment: `AGENT_BROWSER_CONFIRM_ACTIONS`.
- `--confirm-interactive`: interactive confirmations; auto-denies when stdin is not a TTY. Environment: `AGENT_BROWSER_CONFIRM_INTERACTIVE`.
- `-p, --provider <name>`: provider such as `ios`, `browserbase`, `kernel`, `browseruse`, `browserless`, or `agentcore`. Environment: `AGENT_BROWSER_PROVIDER`.
- `--device <name>`: iOS device name. Environment: `AGENT_BROWSER_IOS_DEVICE`.
- Provider-specific iOS examples from upstream include `agent-browser -p ios device list`, `agent-browser -p ios swipe up`, and `agent-browser -p ios tap @e1`; in pi, pass those tokens through `args` rather than bash. iOS requires external Xcode/Appium setup, and cloud providers (`browserbase`, `kernel`, `browseruse`, `browserless`, `agentcore`) require their upstream accounts, credentials, and provider-specific environment variables. Common provider variables include `BROWSERBASE_API_KEY`, `BROWSERBASE_PROJECT_ID`, `BROWSERLESS_API_KEY`, `BROWSERLESS_API_URL`, `BROWSERLESS_BROWSER_TYPE`, `BROWSERLESS_STEALTH`, `BROWSERLESS_TTL`, `BROWSER_USE_API_KEY`, `BROWSER_USE_PROFILE_ID`, `BROWSER_USE_PROXY_COUNTRY`, `BROWSER_USE_ENABLE_RECORDING`, `KERNEL_API_KEY`, `KERNEL_HEADLESS`, `KERNEL_STEALTH`, `KERNEL_TIMEOUT_SECONDS`, `KERNEL_PROFILE_NAME`, `KERNEL_PROFILE_SAVE_CHANGES`, `AGENTCORE_API_KEY`, `AGENTCORE_REGION`, `AGENTCORE_BROWSER_ID`, `AGENTCORE_PROFILE_ID`, `AGENTCORE_SESSION_TIMEOUT`, plus AWS names used by AgentCore such as `AWS_PROFILE`, `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_SESSION_TOKEN`, `AWS_REGION`, and `AWS_DEFAULT_REGION`. The wrapper forwards parent environment variables plus provider flags and stays thin; it does not emulate provider setup or cloud browser behavior.
- `--model <name>`: AI model for `chat`. Environment: `AI_GATEWAY_MODEL`.
- `-v, --verbose`: show tool commands and raw output.
- `-q, --quiet`: show only AI text responses.
- `--debug`: debug output. Environment: `AGENT_BROWSER_DEBUG`. Explicit `true`/`false` reaches all helpers in that call, including overriding true config defaults; `false` removes the debug variable so native presence checks cannot enable logging. Inherited env/config behavior is unchanged.
- `AGENT_BROWSER_PLUGINS`: JSON plugin registry override for the upstream `plugin` commands.
- `--version`, `-V`: show version.

### Config precedence

Standalone `agent-browser` looks for `agent-browser.json` in these locations, from lowest to highest priority:

1. `~/.agent-browser/config.json` for user defaults.
2. `./agent-browser.json` for project overrides.
3. Environment variables, including `AGENT_BROWSER_CONFIG`.
4. CLI flags.

Native `session` and `namespace` defaults are honored by ordinary tool calls before implicit-session generation; `sessionName` is only a legacy restore key. Per-call flags override environment, which overrides project/user JSON. `--config` or `AGENT_BROWSER_CONFIG` selects one file instead of merging the discovered files; per-call config also reaches helper subprocesses. Caller-owned native `AGENT_BROWSER_SOCKET_DIR` is honored unless the wrapper-specific socket override is set.

Auto-discovered `./agent-browser.json` accepts only the [native preference allowlist](https://github.com/vercel-labs/agent-browser/blob/d52a5e90c372ec4710c69adc3837ac14bbd852aa/cli/src/flags.rs#L271-L319), also used by the pinned Android source. Native warns and ignores advanced runtime settings such as `executablePath`, `args`, `plugins`, and extensions. Put advanced settings in `~/.agent-browser/config.json`, environment, CLI flags, or explicitly select the trusted file with `--config ./agent-browser.json`. This native rule is separate from Pi's project trust, the wrapper's native explicit-file identity inspection, and the package's `.pi/config/...` layers.

Use separated `--config <path>` to load a specific upstream config; upstream 0.33.2 does not recognize `--config=<path>` as the global selector. Browser-backed and sessionless native calls preserve `--config`, `AGENT_BROWSER_CONFIG`, passive project/user config, and other upstream environment exactly as supplied. The Pi-scoped package config under `.pi/config/pi-agent-browser-native/` remains separate. Boolean flags accept optional `true` or `false` values, such as `--headed false`, `--webgpu false`, or `--no-webmcp false`, to override config. For browser extensions, use user config, an explicitly selected trusted file, environment, or CLI flags; native ignores extensions in auto-discovered project config.

Other useful environment variables include `AGENT_BROWSER_DEFAULT_TIMEOUT`, `AGENT_BROWSER_AUTOSAVE_INTERVAL_MS`, `AGENT_BROWSER_STREAM_PORT`, `AGENT_BROWSER_STREAM_QUALITY`, `AGENT_BROWSER_STREAM_MAX_WIDTH`, `AGENT_BROWSER_STREAM_MAX_HEIGHT`, `AGENT_BROWSER_IDLE_TIMEOUT_MS`, `AGENT_BROWSER_ENCRYPTION_KEY`, `AGENT_BROWSER_STATE_EXPIRE_DAYS`, `AGENT_BROWSER_IOS_DEVICE`, `AGENT_BROWSER_IOS_UDID`, `AI_GATEWAY_URL`, `AI_GATEWAY_API_KEY`, provider credential names, and AWS credential names when using AgentCore. The upstream child receives the parent environment plus wrapper overrides such as the managed socket directory, clamped default operation timeout, canonical owned-session namespace (including empty default), and Pi-transcript- plus Git-checkout-generation-scoped `AGENT_BROWSER_RESTORE` for wrapper-owned managed sessions (`buildAgentBrowserProcessEnv` in `extensions/agent-browser/lib/process.ts`, ownership carried by the wrapper's typed process options and call-scoped managed-session context). Model-facing output still redacts recognized secret values.

## Wrapper-specific behavior worth knowing

- The extension may keep following one implicit managed session across later tool calls.
- If launch-scoped flags like `--engine`, `--profile`, `--args`, `--user-agent`, `--executable-path`, `--extension`, `--proxy`, `--proxy-bypass`, `--ignore-https-errors`, `--allow-file-access`, `--hide-scrollbars`, `--color-scheme`, `--download-path`, `--capture`, `--relaunch`, `--ca-cert`, `--no-ca-cert`, `--webgpu`, `--no-webmcp`, `--restore`, `--restore-save`, restore check flags, `--namespace`, `--session-name`, `--cdp`, `--cdp-headers`, `--state`, `--auto-connect`, `--no-auto-connect`, `--init-script`, `--enable`, `--provider` / `-p`, or provider device flags like `--device` would replace or be ignored by an already-active managed session, retry with `sessionMode: "fresh"`. Native 0.42.0 would relaunch that browser and drop its page; older supported natives ignore the flag or restart the browser without reporting it. When the call explicitly names the current managed session, the structured recovery payload removes that `--session` so the fresh rotation can succeed.
- If a `sessionMode: "fresh"` call fails (including upstream failure, timeout, missing binary, or **`qa`** reclassification after a nominally successful batch), read `details.managedSessionOutcome` before assuming where the next default call will go: `preserved` means the prior managed session remains current, while `abandoned` means no managed session became current. When the failure reason is not the fresh launch itself—for example `failureCategory: "qa-failure"`—`status`/`summary` may still describe the managed-session transition while `succeeded` on this object matches the final tool outcome.

- After open/goto/navigate calls with --profile, --restore, --session-name, or --state, agent_browser best-effort re-selects the tab whose URL matches the returned page when restored tabs steal focus during launch or reconnect.
- After confirmed shutdown of an automatically restored managed session, the wrapper retains its complete recorded URL, including the fragment, until the first current-page operation (including get url and reload). Non-page calls such as tab list may start a daemon without fulfilling that reopen; explicit URL reads leave the managed browser and pending reopen untouched. The wrapper uses native open once, verifies the observed tab, and discards old refs/frame scope; it does not restore unsaved forms, JavaScript memory, or history. Explicit navigation, caller-owned/attached sessions, and restore-disabled sessions are not auto-reopened.
- For a still-live browser after tab drift or resume, the wrapper verifies/selects the intended tab before ref/semantic helpers and page commands; failed selection stops the call without navigating. Local commands, read <url>, URL a11y/vitals, diff url, window new, and explicit tab/navigation/connection/state recovery do not require the prior tab. Batch checks follow effective rows past non-page prefixes and stop at explicit context changes, preserving caller argv/stdin and continue-on-error behavior. Same-tab reselection is avoided because it clears refs. Use exact batch --bail for fail-fast, not --bail=<value>. Routine same-session calls skip tab-list preflights.
- For sessions with observed tab-drift risk, after a successful command on a known target tab, agent_browser also best-effort restores that intended tab if a restored/background tab steals focus after the command completes. Routine same-session commands skip focus correction; observed pages without a native targetId use tab list to establish their identity.
- On the automatic root browser or an explicit `--session`, launch flags pass through. When native relaunches the browser for a changed setting or `--relaunch`, the result leads with a warning that names the changed settings, records about:blank as the current page, discards prior refs, and offers `reopen-page-after-browser-relaunch` (`open <prior url>`) in details.nextActions. It does not try to re-select the prior tab, because the relaunched browser has none.
- If a known session target unexpectedly reports about:blank, agent_browser best-effort re-selects the prior intended target when it still exists; if recovery fails, it records the observed about:blank target and reports exact recovery guidance instead of treating the prior page as active.
- If upstream reports tab_gone, the pinned bound tab is gone; use details.nextActions (tab list / tab new) instead of assuming another tab is yours.

- Wrapper-spawned commands clamp `AGENT_BROWSER_DEFAULT_TIMEOUT` to the upstream documented 25-second default and use a 35-second child-process watchdog (`PI_AGENT_BROWSER_PROCESS_TIMEOUT_MS` overrides the default 35s budget; top-level `timeoutMs` overrides it per browser CLI call). Explicit `wait <ms>`, `wait --timeout <ms>`, and WebMCP `invoke` / `result --timeout <ms>` calls can exceed that default; when top-level `timeoutMs` is omitted, the wrapper derives a subprocess watchdog from the requested command duration plus a small grace window. Batch budgeting and timeout recovery read the same effective source as upstream: raw command strings when present, otherwise stdin rows. Dialog commands are additionally bounded to 5 seconds (`PI_AGENT_BROWSER_DIALOG_PROCESS_TIMEOUT_MS`), and click/tap/find refs or tokens plus `eval --stdin` snippets that look like alert/confirm/prompt/dialog triggers are bounded to 8 seconds (`PI_AGENT_BROWSER_DIALOG_TRIGGER_PROCESS_TIMEOUT_MS`). A `session info` timeout returns only an exact-session `retry-session-info` status action, without page probes, liveness claims, or changes to existing page/ref state. When a browser-operation watchdog fires, `details.timeoutPartialProgress` may include a planned step list with `status: "unknown"` (including `generatedFrom` labels for generated QA rows). Current URLs and existing files do not establish which steps ran, failed, or remained pending. Multi-step timeouts offer `inspect-current-page-after-timeout` when the target is already verified, rather than guessing a retry position. A single read-only or idempotent step may offer a `retry-timeout-step` candidate with a one-row native batch (`args: ["batch"]` plus `stdin`); inspect the current state before retrying because its outcome is still unknown. If the target is unknown, standalone snapshots are removed and visible failure text plus `details.nextActions` show `verify-page-target-after-timeout`, including its session-scoped `batch --bail` args and short stdin for fail-fast `get url` then `snapshot -i`; dialog status/accept/dismiss actions remain allowed for blocking-dialog recovery. It also includes current page URL from best-effort session `get url`, followed by `get title` only after a URL is recovered (or a planned URL inferred from the step list when the session cannot answer), and declared artifact paths such as `screenshot`, `pdf`, `download`, or `wait --download` outputs with existence/state checks. Independent artifact retry windows overlap (up to three checks per path, 25 ms apart), preserve plan order, and settle before page inspection; files finishing after their own window may remain missing. The same evidence is appended under `Timeout partial progress` in visible text with URL/path redaction.
- Oversized snapshots and oversized generic outputs may be compacted in tool content, with the full redacted output written to a spill file path shown directly in the tool result. Recent artifact metadata is bounded by `PI_AGENT_BROWSER_SESSION_ARTIFACT_MANIFEST_MAX_ENTRIES` (default 100); persisted spill files have a separate `PI_AGENT_BROWSER_SESSION_ARTIFACT_MAX_BYTES` budget (default 32 MiB; `0` disables automatic eviction).
- The wrapper keeps `--help` and `--version` stateless so they do not consume the implicit managed-session slot.

## Generated capability baseline

<!-- agent-browser-capability-baseline:start capability-token-baseline -->
<!-- Generated from scripts/agent-browser-capability-baseline.mjs. Run `npm run docs -- command-reference write` to update. Do not edit manually. -->
<details>
<summary>Generated verifier capability baseline for agent-browser 0.42.0</summary>

This generated block is review data for maintainers. The human-authored reference sections above remain the readable command guide.

#### Source evidence

- repository: `vercel-labs/agent-browser`
- upstream HEAD: `e7519957b9067c541825afa21a792fbe1f483047`
- upstream package version: `0.42.0`
- inspected: `stock npm agent-browser@0.42.0 package and official release binary`
- inspected: `v0.41.2...v0.42.0 release notes and interface source diff`
- inspected: `agent-browser --version`
- inspected: `agent-browser --help`
- inspected: `selected agent-browser <command> --help output`
- inspected: `agent-browser a11y --help`
- inspected: `agent-browser mcp --help`
- inspected: `agent-browser plugin --help`
- inspected: `agent-browser skills list`
- inspected: `agent-browser skills get core --full`
- inspected: `agent-browser skills get core --ref commands --json`
- inspected: `cli/src/skills.rs`
- inspected: `cli/src/browser_security.rs`
- inspected: `cli/src/session_settings/running.rs`
- inspected: `cli/src/session_settings/plan.rs`
- inspected: `cli/src/session_settings/spec.rs`
- inspected: `cli/src/native/flow/replay.rs`
- inspected: `agent-browser skills get derive-client --full`
- inspected: `agent-browser skills get webmcp-gen --full`
- inspected: `README.md`
- inspected: `CHANGELOG.md`
- inspected: `agent-browser.schema.json`
- inspected: `bin/agent-browser.js`
- inspected: `cli/src/ca_bundle.rs`
- inspected: `cli/src/commands.rs`
- inspected: `cli/src/connection.rs`
- inspected: `cli/src/mcp.rs`
- inspected: `cli/src/flags.rs`
- inspected: `cli/src/main.rs`
- inspected: `cli/src/session_files.rs`
- inspected: `cli/src/plugins.rs`
- inspected: `cli/src/read.rs`
- inspected: `cli/src/tls.rs`
- inspected: `cli/src/doctor/ffmpeg.rs`
- inspected: `cli/src/doctor/webgpu.rs`
- inspected: `cli/src/native/actions.rs`
- inspected: `cli/src/native/a11y/mod.rs`
- inspected: `cli/src/native/browser.rs`
- inspected: `cli/src/native/cdp/obscura.rs`
- inspected: `cli/src/native/cdp/discovery.rs`
- inspected: `cli/src/native/policy.rs`
- inspected: `cli/src/native/providers.rs`
- inspected: `cli/src/native/tab_binding.rs`
- inspected: `cli/src/native/daemon.rs`
- inspected: `cli/src/native/element.rs`
- inspected: `cli/src/native/recording.rs`
- inspected: `cli/src/native/snapshot.rs`
- inspected: `cli/src/native/state.rs`
- inspected: `cli/src/native/interaction.rs`
- inspected: `cli/src/native/screenshot.rs`
- inspected: `cli/src/native/stream/cdp_loop.rs`
- inspected: `cli/src/native/stream/dashboard.rs`
- inspected: `cli/src/native/test_fixtures/webmcp_frame_probe.html`
- inspected: `cli/src/native/test_fixtures/webmcp_probe.html`
- inspected: `cli/src/native/webmcp.rs`
- inspected: `cli/src/output.rs`
- inspected: `docs/content/docs/webgpu.mdx`
- inspected: `docs/content/docs/webmcp.mdx`
- inspected: `docs/content/docs/network.mdx`
- inspected: `docs/content/docs/proxy.mdx`
- inspected: `docs/content/docs/selectors.mdx`
- inspected: `docs/content/docs/sessions.mdx`
- inspected: `docs/content/docs/skills.mdx`
- inspected: `docs/content/docs/commands.mdx`
- inspected: `docs/content/docs/engines/obscura.mdx`
- inspected: `docs/content/docs/providers/browser-use.mdx`
- inspected: `docs/content/docs/providers/kernel.mdx`
- inspected: `cli/tests/tls_cli.rs`
- inspected: `skill-data/derive-client/SKILL.md`
- inspected: `skill-data/core/SKILL.md`
- inspected: `skill-data/core/references/video-recording.md`
- inspected: `skill-data/protected-vercel-deployments/SKILL.md`
- inspected: `skill-data/webmcp-gen/SKILL.md`
- inspected: `test/launcher.test.mjs`
- inspected: `packages/@agent-browser/eve/README.md`
- inspected: `packages/@agent-browser/eve/package.json`
- inspected: `packages/@agent-browser/eve/test/extension.test.mjs`
- inspected: `packages/@agent-browser/sandbox/README.md`
- inspected: `packages/@agent-browser/sandbox/src/shared.ts`
- inspected: `packages/@agent-browser/sandbox/src/vercel.ts`

#### Upstream help commands sampled

- root help: `agent-browser --help`
- skills help: `agent-browser skills --help`
- skills list: `agent-browser skills list`
- core skill full: `agent-browser skills get core --full`
- core command reference: `agent-browser skills get core --ref commands`
- vercel sandbox skill full: `agent-browser skills get vercel-sandbox --full`
- protected Vercel deployments skill full: `agent-browser skills get protected-vercel-deployments --full`
- WebMCP generation skill full: `agent-browser skills get webmcp-gen --full`
- open help: `agent-browser open --help`
- read help: `agent-browser read --help`
- click help: `agent-browser click --help`
- fill help: `agent-browser fill --help`
- type help: `agent-browser type --help`
- download help: `agent-browser download --help`
- key help: `agent-browser key --help`
- scroll help: `agent-browser scroll --help`
- scrollinto help: `agent-browser scrollinto --help`
- keydown help: `agent-browser keydown --help`
- keyup help: `agent-browser keyup --help`
- get help: `agent-browser get --help`
- is help: `agent-browser is --help`
- mouse help: `agent-browser mouse --help`
- drag help: `agent-browser drag --help`
- set help: `agent-browser set --help`
- tab help: `agent-browser tab --help`
- snapshot help: `agent-browser snapshot --help`
- eval help: `agent-browser eval --help`
- wait help: `agent-browser wait --help`
- screenshot help: `agent-browser screenshot --help`
- pdf help: `agent-browser pdf --help`
- close help: `agent-browser close --help`
- find help: `agent-browser find --help`
- network help: `agent-browser network --help`
- cookies help: `agent-browser cookies --help`
- storage help: `agent-browser storage --help`
- state help: `agent-browser state --help`
- session help: `agent-browser session --help`
- frame help: `agent-browser frame --help`
- dialog help: `agent-browser dialog --help`
- window help: `agent-browser window --help`
- keyboard help: `agent-browser keyboard --help`
- batch help: `agent-browser batch --help`
- auth help: `agent-browser auth --help`
- stream help: `agent-browser stream --help`
- dashboard help: `agent-browser dashboard --help`
- chat help: `agent-browser chat --help`
- doctor help: `agent-browser doctor --help`
- diff help: `agent-browser diff --help`
- trace help: `agent-browser trace --help`
- profiler help: `agent-browser profiler --help`
- record help: `agent-browser record --help`
- console help: `agent-browser console --help`
- errors help: `agent-browser errors --help`
- a11y help: `agent-browser a11y --help`
- clipboard help: `agent-browser clipboard --help`
- tap help: `agent-browser tap --help`
- swipe help: `agent-browser swipe --help`
- device help: `agent-browser device --help`
- install help: `agent-browser install --help`
- upgrade help: `agent-browser upgrade --help`
- profiles help: `agent-browser profiles --help`
- mcp help: `agent-browser mcp --help`
- plugin help: `agent-browser plugin --help`

#### Inventory sections

- Built-in skills: 20 human-doc token(s), 26 upstream token(s)
- Core page, element, navigation, and extraction commands: 91 human-doc token(s), 100 upstream token(s)
- Sessions, state, tabs, frames, dialogs, and windows: 30 human-doc token(s), 27 upstream token(s)
- Network, storage, artifacts, diagnostics, and performance: 63 human-doc token(s), 72 upstream token(s)
- Batch, auth, confirmations, setup, dashboard, devices, and AI commands: 45 human-doc token(s), 55 upstream token(s)
- Global flags, config, providers, policy, and environment: 170 human-doc token(s), 138 upstream token(s)

#### Human-authored doc tokens required

##### Built-in skills

- `skills list`
- `skills get core`
- `skills get core --full`
- `skills get <name>`
- `skills get <name> --full`
- `skills get <name> --ref <ref>`
- `skills get --all`
- `skills get electron`
- `skills get slack`
- `skills get dogfood`
- `skills get vercel-sandbox`
- `skills get protected-vercel-deployments`
- `skills get agentcore`
- `skills get derive-client`
- `skills get webmcp-gen`
- `webmcp.init.js`
- `@agent-browser/sandbox`
- `installSystemDependencies: false`
- `skills path [name]`
- `AGENT_BROWSER_SKILLS_DIR`

##### Core page, element, navigation, and extraction commands

- `open [url]`
- `open <url>`
- `goto <url>`
- `navigate <url>`
- `read [url]`
- `read <url> --raw`
- `read <url> --require-md`
- `read <url> --llms <index|full>`
- `read <url> --outline`
- `read <url> --filter <text>`
- `read <url> --timeout <ms>`
- `click <sel>`
- `click <sel> --new-tab`
- `dblclick <sel>`
- `type <sel> <text>`
- `type <selector> [--clear] [--delay <ms>] [--] <text>`
- `fill <sel> <text>`
- `fill <selector> [--] <text>`
- `press <key>`
- `key <key>`
- `keydown <key>`
- `keyup <key>`
- `keyboard type <text>`
- `keyboard inserttext <text>`
- `keydown Shift`
- `keyup Shift`
- `hover <sel>`
- `focus <sel>`
- `check <sel>`
- `uncheck <sel>`
- `select <sel> <val...>`
- `drag <src> <dst>`
- `upload <sel> <files...>`
- `download <sel> <path>`
- `scroll <dir> [px]`
- `scroll <dir> [px] --selector <sel>`
- `scrollintoview <sel>`
- `scrollinto <sel>`
- `wait <sel|ms>`
- `wait --url <pattern>`
- `wait --load <state>`
- `wait --fn <expression>`
- `wait --text <text>`
- `wait --download [path]`
- `screenshot [selector] [path]`
- `screenshot [path]`
- `screenshot --full`
- `screenshot --annotate`
- `screenshot --if-changed`
- `screenshot --threshold <0-1>`
- `snapshot --delta`
- `snapshot --delta --full`
- `click <sel> --human`
- `drag <src> <dst> --human`
- `mouse move <x> <y> --duration <ms> --steps <n> --human --seed <n>`
- `pdf <path>`
- `snapshot`
- `snapshot --cursor`
- `snapshot --interactive`
- `snapshot --urls`
- `snapshot --compact`
- `snapshot --depth <n>`
- `snapshot --selector <sel>`
- `eval <js>`
- `eval --stdin`
- `eval -b <base64>`
- `connect <port|url>`
- `close [--all]`
- `quit`
- `exit`
- `back`
- `forward`
- `reload`
- `pushstate <url>`
- `get <what> [selector]`
- `get cdp-url`
- `get box <selector>`
- `get styles <selector>`
- `is <what> <selector>`
- `find <locator> <value> <action>`
- `find first <sel>`
- `find last <sel>`
- `find nth <n> <sel>`
- `find role <role> --name <name>`
- `find role heading text --name`
- `find ... --exact`
- `mouse <action> [args]`
- `set <setting> [value]`
- `set media <features>`
- `tap <selector>`
- `swipe <direction> [distance]`

##### Sessions, state, tabs, frames, dialogs, and windows

- `session`
- `session id`
- `session id --scope worktree --prefix <name>`
- `session info`
- `session info --json`
- `session list`
- `state save <path>`
- `state load <path>`
- `skippedOrigins`
- `restoreSkippedOrigins`
- `state list`
- `state show <filename>`
- `state rename <old-name> <new-name>`
- `state clear [session-name] [--all]`
- `state clear -a`
- `state clean --older-than <days>`
- `tab list`
- `tab new [url]`
- `tab new --label <name> [url]`
- `tab close [target]`
- `tab <t<N>|label>`
- `tab_gone`
- `data.targetId`
- `data.lastUrl`
- `CDP target ids`
- `frame <selector|main>`
- `dialog accept [text]`
- `dialog dismiss`
- `dialog status`
- `window new`

##### Network, storage, artifacts, diagnostics, and performance

- `network <action>`
- `network route <url> [--abort|--body <json> [--allow-origin <origin>]] [--resource-type <csv>]`
- `--allow-origin <origin>`
- `network unroute [url]`
- `network requests [--clear] [--filter <pattern>] [--type <csv>] [--method <method>] [--status <code|range>]`
- `network request <requestId>`
- `network har start`
- `network har start --content all`
- `network har start --content none`
- `network har start --content text`
- `network har stop [path]`
- `cookies [get|set|clear]`
- `cookies set <name> <value> --url <url> --domain <domain> --path <path> --httpOnly --secure --sameSite <Strict|Lax|None> --expires <timestamp>`
- `cookies set --curl <file>`
- `storage <local|session>`
- `webmcp list`
- `webmcp list [tool] [--frame <frame-id>]`
- `webmcp invoke <tool>`
- `webmcp invoke <tool> --params <json|@file>`
- `webmcp invoke <tool> --frame <frame-id>`
- `webmcp invoke <tool> --detach`
- `webmcp invoke <tool> --timeout <ms>`
- `webmcp result <id>`
- `webmcp cancel <id>`
- `diff snapshot`
- `diff snapshot --baseline <file> --selector <sel> --compact --depth <n>`
- `diff screenshot --baseline`
- `diff screenshot --baseline <file> --output <file> --threshold <0-1> --selector <sel> --full`
- `diff url <u1> <u2>`
- `diff url <u1> <u2> --screenshot --wait-until <strategy> --selector <sel> --compact --depth <n>`
- `trace start`
- `trace stop [path]`
- `profiler start|stop [path]`
- `record start <path> [url]`
- `record restart <path> [url]`
- `--fps <n>`
- `--cursor`
- `--contact-sheet`
- `--contact-sheet-threshold <n>`
- `record stop`
- `console [--clear]`
- `errors [--clear]`
- `highlight <sel>`
- `inspect`
- `clipboard <op> [text]`
- `clipboard read`
- `clipboard write <text>`
- `clipboard copy`
- `clipboard paste`
- `stream enable [--port <n>]`
- `stream disable`
- `stream status`
- `react tree`
- `react inspect <id>`
- `react renders start`
- `react renders stop [--json]`
- `react suspense [--only-dynamic] [--json]`
- `vitals [url] [--json]`
- `web-vitals [url] [--json]`
- `a11y [url]`
- `a11y --tags wcag2a,wcag2aa`
- `a11y --selector "#main"`
- `removeinitscript <id>`

##### Batch, auth, confirmations, setup, dashboard, devices, and AI commands

- `batch [--bail]`
- `batch --bail --omit-command`
- `flow steps [--json]`
- `flow save <name>`
- `flow run <name>`
- `flow list [--origin <host>]`
- `AGENT_BROWSER_FLOWS_DIR`
- `auth save <name>`
- `auth save <name> --url <url> --username <user> --password <pass>`
- `auth save <name> --username-selector <s> --password-selector <s> --submit-selector <s>`
- `auth save <name> --password-stdin`
- `auth login <name>`
- `auth login <name> --no-navigate`
- `auth list`
- `auth show <name>`
- `auth delete <name>`
- `auth remove <name>`
- `confirm <id>`
- `deny <id>`
- `chat <message>`
- `dashboard [start]`
- `dashboard start --port <n>`
- `dashboard start --allowed-origins <origins>`
- `AGENT_BROWSER_DASHBOARD_ALLOWED_ORIGINS`
- `dashboard stop`
- `device list`
- `install`
- `install --with-deps`
- `install --with-deps exits nonzero`
- `upgrade`
- `doctor [--fix]`
- `doctor --offline --quick`
- `doctor --webgpu`
- `doctor --webgpu --headed`
- `doctor --json`
- `mcp`
- `mcp call <tool>`
- `mcp --tools core,webmcp`
- `plugin add <ref>`
- `plugin add <ref> --project`
- `plugin [list]`
- `plugin show <name>`
- `plugin run <name> <type>`
- `auth login <name> --credential-provider <plugin>`
- `profiles`

##### Global flags, config, providers, policy, and environment

- `--profile <name|path>`
- `AGENT_BROWSER_PROFILE`
- `--session <name>`
- `AGENT_BROWSER_SESSION`
- `--namespace <name>`
- `AGENT_BROWSER_NAMESPACE`
- `--restore [name]`
- `AGENT_BROWSER_RESTORE`
- `--restore-save <policy>`
- `AGENT_BROWSER_RESTORE_SAVE`
- `--restore-check-url <glob>`
- `AGENT_BROWSER_RESTORE_CHECK_URL`
- `--restore-check-text <txt>`
- `AGENT_BROWSER_RESTORE_CHECK_TEXT`
- `--restore-check-fn <js>`
- `AGENT_BROWSER_RESTORE_CHECK_FN`
- `--session-name <name>`
- `AGENT_BROWSER_SESSION_NAME`
- `--state <path>`
- `AGENT_BROWSER_STATE`
- `--auto-connect`
- `--no-auto-connect`
- `AGENT_BROWSER_AUTO_CONNECT`
- `--relaunch`
- `--capture <list>`
- `AGENT_BROWSER_CAPTURE`
- `--pin-tab`
- `--no-pin-tab`
- `AGENT_BROWSER_PIN_TAB`
- `--headers <json>`
- `--init-script <path>`
- `AGENT_BROWSER_INIT_SCRIPTS`
- `--enable <feature>`
- `AGENT_BROWSER_ENABLE`
- `--executable-path <path>`
- `AGENT_BROWSER_EXECUTABLE_PATH`
- `--extension <path>`
- `AGENT_BROWSER_EXTENSIONS`
- `--args <args>`
- `AGENT_BROWSER_ARGS`
- `--user-agent <ua>`
- `AGENT_BROWSER_USER_AGENT`
- `--proxy <server>`
- `AGENT_BROWSER_PROXY`
- `HTTP_PROXY`
- `HTTPS_PROXY`
- `ALL_PROXY`
- `--proxy-bypass <hosts>`
- `AGENT_BROWSER_PROXY_BYPASS`
- `NO_PROXY`
- `--ignore-https-errors`
- `AGENT_BROWSER_IGNORE_HTTPS_ERRORS`
- `--ca-cert <path>`
- `--no-ca-cert`
- `AGENT_BROWSER_CA_CERT`
- `AGENT_BROWSER_CLEAR_CA_CERT`
- `--use-system-ca`
- `AGENT_BROWSER_USE_SYSTEM_CA`
- `SSL_CERT_FILE`
- `--allow-file-access`
- `AGENT_BROWSER_ALLOW_FILE_ACCESS`
- `--hide-scrollbars <bool>`
- `--headed`
- `AGENT_BROWSER_HEADED`
- `--webgpu`
- `AGENT_BROWSER_WEBGPU`
- `--no-webmcp`
- `AGENT_BROWSER_NO_WEBMCP`
- `noWebmcp`
- `AGENT_BROWSER_NO_XVFB`
- `AGENT_BROWSER_NO_VERSION_CHECK`
- `"webgpu": true`
- `--cdp <port|url>`
- `--cdp-headers <json>`
- `AGENT_BROWSER_CDP_HEADERS`
- `--color-scheme <scheme>`
- `AGENT_BROWSER_COLOR_SCHEME`
- `--download-path <path>`
- `AGENT_BROWSER_DOWNLOAD_PATH`
- `--engine <name>`
- `AGENT_BROWSER_ENGINE`
- `--engine obscura`
- `OBSCURA_ALLOW_PRIVATE_NETWORK`
- `AGENT_BROWSER_OBSCURA_STEALTH`
- `--input-mode <mode>`
- `--no-auto-dialog`
- `AGENT_BROWSER_NO_AUTO_DIALOG`
- `--json`
- `AGENT_BROWSER_JSON`
- `--annotate`
- `AGENT_BROWSER_ANNOTATE`
- `--screenshot-dir <path>`
- `AGENT_BROWSER_SCREENSHOT_DIR`
- `--screenshot-quality <n>`
- `AGENT_BROWSER_SCREENSHOT_QUALITY`
- `--screenshot-format <fmt>`
- `AGENT_BROWSER_SCREENSHOT_FORMAT`
- `--content-boundaries`
- `AGENT_BROWSER_CONTENT_BOUNDARIES`
- `--max-output <chars>`
- `AGENT_BROWSER_MAX_OUTPUT`
- `--allowed-domains <list>`
- `AGENT_BROWSER_ALLOWED_DOMAINS`
- `--action-policy <path>`
- `AGENT_BROWSER_ACTION_POLICY`
- `--confirm-actions <list>`
- `AGENT_BROWSER_CONFIRM_ACTIONS`
- `--confirm-interactive`
- `AGENT_BROWSER_CONFIRM_INTERACTIVE`
- `-p, --provider <name>`
- `AGENT_BROWSER_PROVIDER`
- `AGENT_BROWSER_PLUGINS`
- `browserbase`
- `kernel`
- `browseruse`
- `browserless`
- `agentcore`
- `--device <name>`
- `AGENT_BROWSER_IOS_DEVICE`
- `agent-browser -p ios device list`
- `agent-browser -p ios swipe up`
- `agent-browser -p ios tap @e1`
- `--model <name>`
- `AI_GATEWAY_MODEL`
- `-v, --verbose`
- `-q, --quiet`
- `--debug`
- `AGENT_BROWSER_DEBUG`
- `AGENT_BROWSER_CONFIG`
- `AGENT_BROWSER_DEFAULT_TIMEOUT`
- `--idle-timeout <ms>`
- `AGENT_BROWSER_AUTOSAVE_INTERVAL_MS`
- `AGENT_BROWSER_STREAM_PORT`
- `AGENT_BROWSER_STREAM_QUALITY`
- `AGENT_BROWSER_STREAM_MAX_WIDTH`
- `AGENT_BROWSER_STREAM_MAX_HEIGHT`
- `AGENT_BROWSER_IDLE_TIMEOUT_MS`
- `AGENT_BROWSER_ENCRYPTION_KEY`
- `AGENT_BROWSER_STATE_EXPIRE_DAYS`
- `AGENT_BROWSER_IOS_UDID`
- `AI_GATEWAY_URL`
- `AI_GATEWAY_API_KEY`
- `BROWSERBASE_API_KEY`
- `BROWSERBASE_PROJECT_ID`
- `BROWSERLESS_API_KEY`
- `BROWSERLESS_API_URL`
- `BROWSERLESS_BROWSER_TYPE`
- `BROWSERLESS_STEALTH`
- `BROWSERLESS_TTL`
- `BROWSER_USE_API_KEY`
- `BROWSER_USE_PROFILE_ID`
- `BROWSER_USE_PROXY_COUNTRY`
- `BROWSER_USE_ENABLE_RECORDING`
- `KERNEL_API_KEY`
- `KERNEL_HEADLESS`
- `KERNEL_STEALTH`
- `KERNEL_TIMEOUT_SECONDS`
- `KERNEL_PROFILE_NAME`
- `KERNEL_PROFILE_SAVE_CHANGES`
- `AGENTCORE_API_KEY`
- `AGENTCORE_REGION`
- `AGENTCORE_BROWSER_ID`
- `AGENTCORE_PROFILE_ID`
- `AGENTCORE_SESSION_TIMEOUT`
- `AWS_PROFILE`
- `AWS_ACCESS_KEY_ID`
- `AWS_SECRET_ACCESS_KEY`
- `AWS_SESSION_TOKEN`
- `AWS_REGION`
- `AWS_DEFAULT_REGION`

#### Upstream help tokens expected

##### Built-in skills

- root help: `skills get core --full`
- skills help: `get <name> --full`
- skills help: `get <name> --ref <ref>`
- core command reference: `# Command Reference`
- skills help: `get --all`
- skills help: `AGENT_BROWSER_SKILLS_DIR`
- skills list: `core`
- skills list: `electron`
- skills list: `slack`
- skills list: `dogfood`
- skills list: `vercel-sandbox`
- skills list: `protected-vercel-deployments`
- skills list: `agentcore`
- skills list: `derive-client`
- skills list: `webmcp-gen`
- WebMCP generation skill full: `webmcp.init.js`
- WebMCP generation skill full: `agent-browser webmcp invoke <tool> --params @fixture.json`
- vercel sandbox skill full: `@agent-browser/sandbox`
- vercel sandbox skill full: `installSystemDependencies: false`
- protected Vercel deployments skill full: `x-vercel-trusted-oidc-idp-token`
- protected Vercel deployments skill full: `vc project token`
- core skill full: `agent-browser frame @e3`
- core skill full: `agent-browser dialog accept`
- core skill full: `agent-browser --session "$SESSION" --restore open https://app.example.com`
- core skill full: `network har start --content all`
- core skill full: `implicit roles work`

##### Core page, element, navigation, and extraction commands

- open help: `open [url]`
- open help: `aliases still require a URL.`
- open help: `agent-browser webmcp list`
- root help: `open <url>`
- root help: `read [url]`
- read help: `read [url]`
- read help: `--raw`
- read help: `--require-md`
- read help: `--llms <index|full>`
- read help: `--outline`
- read help: `--filter <text>`
- read help: `--timeout <ms>`
- root help: `click <sel>`
- click help: `--new-tab`
- root help: `dblclick <sel>`
- root help: `type <sel> <text>`
- type help: `type <selector> [--clear] [--delay <ms>] [--] <text>`
- root help: `fill <sel> <text>`
- fill help: `fill <selector> [--] <text>`
- fill help: `Text after -- is literal`
- root help: `press <key>`
- key help: `Aliases: key`
- keydown help: `keydown <key>`
- keyup help: `keyup <key>`
- root help: `keyboard type <text>`
- root help: `keyboard inserttext <text>`
- root help: `hover <sel>`
- root help: `focus <sel>`
- root help: `check <sel>`
- root help: `uncheck <sel>`
- root help: `select <sel> <val...>`
- root help: `drag <src> <dst>`
- root help: `upload <sel> <files...>`
- root help: `download <sel> <path>`
- download help: `Only works with a browser agent-browser launched`
- root help: `Unknown commands exit with status 1`
- mouse help: `Coordinates and wheel deltas accept finite numbers`
- root help: `scroll <dir> [px]`
- scroll help: `--selector <sel>`
- root help: `scrollintoview <sel>`
- scrollinto help: `Aliases: scrollinto`
- root help: `wait <sel|ms>`
- wait help: `--url <pattern>`
- wait help: `--load <state>`
- wait help: `--fn <expression>`
- wait help: `--text <text>`
- wait help: `--download [path]`
- root help: `screenshot [path]`
- screenshot help: `screenshot [selector] [path]`
- root help: `pdf <path>`
- pdf help: `Save page as PDF`
- root help: `snapshot`
- snapshot help: `--interactive`
- snapshot help: `--urls`
- snapshot help: `--compact`
- snapshot help: `--depth <n>`
- snapshot help: `--selector <sel>`
- root help: `eval <js>`
- eval help: `--stdin`
- eval help: `-b, --base64`
- root help: `connect <port|url>`
- root help: `close [--all]`
- close help: `Aliases: quit, exit`
- root help: `back`
- root help: `forward`
- root help: `reload`
- root help: `pushstate <url>`
- root help: `Get Info:  agent-browser get <what> [selector]`
- get help: `box <selector>`
- get help: `styles <selector>`
- get help: `cdp-url`
- root help: `Check State:  agent-browser is <what> <selector>`
- root help: `Find Elements:  agent-browser find <locator> <value> <action> [text]`
- find help: `first <selector>`
- find help: `last <selector>`
- find help: `nth <index> <selector>`
- find help: `--name <name>`
- find help: `--exact`
- find help: `case-insensitive`
- find help: `click, fill, check, hover, text`
- root help: `Mouse:  agent-browser mouse <action> [args]`
- root help: `Browser Settings:  agent-browser set <setting> [value]`
- set help: `media [dark|light]`
- keyboard help: `type <text>`
- keyboard help: `inserttext <text>`
- screenshot help: `--full, -f`
- screenshot help: `--annotate`
- screenshot help: `--if-changed`
- screenshot help: `--threshold <0-1>`
- snapshot help: `--delta`
- snapshot help: `--full`
- click help: `--human`
- drag help: `--human`
- mouse help: `--duration <ms>`
- mouse help: `--steps <n>`
- mouse help: `--seed <n>`
- find help: `role <role>`
- find help: `testid <id>`
- tap help: `tap <selector>`
- swipe help: `swipe <direction> [distance]`

##### Sessions, state, tabs, frames, dialogs, and windows

- root help: `session list`
- session help: `id`
- session help: `info`
- session help: `--scope worktree`
- session help: `--namespace <name>`
- state help: `save <path>`
- state help: `load <path>`
- state help: `elsewhere are skipped and listed`
- state help: `list`
- state help: `show <filename>`
- state help: `rename <old-name> <new-name>`
- state help: `clear [session-name] [--all]`
- state help: `agent-browser state clear --all`
- state help: `clean --older-than <days>`
- tab help: `new [url]`
- tab help: `new --label <name> [url]`
- tab help: `close [t<N>|label|target]`
- tab help: `Stable tab ids`
- tab help: `overrides before their first document loads.`
- tab help: `tab_gone`
- tab help: `data.targetId`
- tab help: `data.lastUrl`
- core skill full: `--pin-tab`
- core skill full: `tab_gone`
- frame help: `frame <selector|main>`
- dialog help: `dialog <accept|dismiss|status> [text]`
- window help: `window <operation>`

##### Network, storage, artifacts, diagnostics, and performance

- root help: `network <action>`
- root help: `--resource-type <csv>`
- network help: `unroute [url]`
- network help: `--allow-origin <origin>`
- network help: `network har start`
- network help: `network har start --content all`
- network help: `--content <mode>`
- network help: `network har stop ./capture.har`
- root help: `cookies [get|set|clear]`
- root help: `cookies set --curl <file>`
- root help: `storage <local|session>`
- root help: `webmcp list [tool]`
- root help: `webmcp invoke <tool>`
- root help: `--params <json|@file>`
- root help: `--frame <frame-id>`
- root help: `--detach`
- root help: `webmcp result <id>`
- root help: `webmcp cancel <id>`
- root help: `diff snapshot`
- root help: `diff screenshot --baseline`
- root help: `trace start`
- root help: `trace stop [path]`
- root help: `profiler start|stop [path]`
- root help: `record start <path> [url]`
- root help: `record stop`
- root help: `console [--clear]`
- root help: `errors [--clear]`
- root help: `highlight <sel>`
- root help: `inspect`
- root help: `clipboard <op> [text]`
- clipboard help: `read`
- clipboard help: `write <text>`
- clipboard help: `copy`
- clipboard help: `paste`
- root help: `stream enable [--port <n>]`
- root help: `stream disable`
- root help: `stream status`
- root help: `react tree`
- root help: `react inspect <id>`
- root help: `react renders start`
- root help: `react renders stop [--json]`
- root help: `react suspense [--only-dynamic] [--json]`
- root help: `vitals [url] [--json]`
- root help: `a11y [url] [--tags <t1,t2>] [--selector <css>] [--json]`
- a11y help: `a11y [url]`
- a11y help: `--tags <tag1,tag2>`
- a11y help: `-s, --selector <css>`
- core skill full: `agent-browser a11y`
- root help: `removeinitscript <id>`
- network help: `requests [options]`
- network help: `--type <types>`
- network help: `--method <method>`
- network help: `--status <code>`
- network help: `request <requestId>`
- network help: `har <start|stop>`
- storage help: `set <key> <value>`
- diff help: `diff snapshot [options]`
- diff help: `--baseline <f>`
- diff help: `--output <file>`
- diff help: `--threshold <0-1>`
- diff help: `--wait-until <strategy>`
- diff help: `diff screenshot --baseline <f>`
- trace help: `trace start`
- trace help: `trace stop [path]`
- profiler help: `--categories <list>`
- record help: `record restart <path.webm|path.mp4> [url] [--fps <n>]`
- record help: `--fps <n>`
- record help: `--cursor`
- record help: `--contact-sheet`
- record help: `--contact-sheet-threshold <n>`
- console help: `--clear`
- errors help: `--clear`

##### Batch, auth, confirmations, setup, dashboard, devices, and AI commands

- root help: `batch [options] ["cmd" ...]`
- root help: `auth save <name>`
- root help: `auth login <name>`
- root help: `confirm <id>`
- root help: `deny <id>`
- root help: `chat <message>`
- root help: `dashboard start --port <n>`
- root help: `dashboard start --allowed-origins <origins>`
- dashboard help: `--allowed-origins <origins>`
- dashboard help: `AGENT_BROWSER_DASHBOARD_ALLOWED_ORIGINS`
- device help: `device list`
- root help: `install --with-deps`
- install help: `directly as root; non-root uses sudo.`
- root help: `upgrade`
- root help: `doctor [--fix]`
- root help: `profiles`
- batch help: `--bail`
- batch help: `--omit-command`
- batch help: `does not make output safe for secrets`
- batch help: `Keep command-specific options and literal command arguments inside`
- root help: `flow steps [--json]`
- root help: `flow save <name>`
- root help: `flow run <name>`
- root help: `flow list [--origin <host>]`
- core command reference: `AGENT_BROWSER_FLOWS_DIR`
- cookies help: `Unknown operations return an error.`
- mcp help: `structuredContent.response`
- auth help: `--url <url>`
- auth help: `--username <user>`
- auth help: `--password <pass>`
- auth help: `--password-stdin`
- auth help: `--username-selector <s>`
- auth help: `--password-selector <s>`
- auth help: `--submit-selector <s>`
- dashboard help: `dashboard [start|stop] [options]`
- chat help: `chat <message>`
- doctor help: `--offline`
- doctor help: `--webgpu`
- doctor help: `--headed`
- doctor help: `--json`
- root help: `Start an MCP stdio server`
- root help: `plugin add <ref>`
- root help: `plugin [list]`
- root help: `plugin show <name>`
- root help: `plugin run <name> <type>`
- auth help: `--credential-provider <p>`
- auth help: `--no-navigate`
- mcp help: `agent_browser_open`
- mcp help: `mcp call <tool>`
- mcp help: `_meta.agentBrowserVersion`
- mcp help: `--tools`
- plugin help: `Add a plugin from npm or GitHub`
- plugin help: `plugin add writes ~/.agent-browser/config.json by default`
- plugin help: `--project`
- plugin help: `credential.read`

##### Global flags, config, providers, policy, and environment

- root help: `--profile <name|path>`
- root help: `AGENT_BROWSER_PROFILE`
- root help: `--session <name>`
- root help: `AGENT_BROWSER_SESSION`
- root help: `--namespace <name>`
- root help: `AGENT_BROWSER_NAMESPACE`
- root help: `--restore [name]`
- root help: `AGENT_BROWSER_RESTORE`
- root help: `--restore-save <policy>`
- root help: `AGENT_BROWSER_RESTORE_SAVE`
- root help: `--restore-check-url <glob>`
- root help: `AGENT_BROWSER_RESTORE_CHECK_URL`
- root help: `--restore-check-text <txt>`
- root help: `AGENT_BROWSER_RESTORE_CHECK_TEXT`
- root help: `--restore-check-fn <js>`
- root help: `AGENT_BROWSER_RESTORE_CHECK_FN`
- root help: `--session-name <name>`
- root help: `AGENT_BROWSER_SESSION_NAME`
- root help: `--state <path>`
- root help: `AGENT_BROWSER_STATE`
- root help: `--auto-connect`
- root help: `--no-auto-connect`
- root help: `AGENT_BROWSER_AUTO_CONNECT`
- root help: `--relaunch`
- root help: `--capture <list>`
- root help: `AGENT_BROWSER_CAPTURE`
- root help: `Credentials are percent-decoded`
- root help: `--pin-tab`
- root help: `--no-pin-tab`
- root help: `AGENT_BROWSER_PIN_TAB`
- root help: `--headers <json>`
- root help: `--init-script <path>`
- root help: `AGENT_BROWSER_INIT_SCRIPTS`
- root help: `--enable <feature>`
- root help: `AGENT_BROWSER_ENABLE`
- root help: `--executable-path <path>`
- root help: `AGENT_BROWSER_EXECUTABLE_PATH`
- root help: `--extension <path>`
- root help: `AGENT_BROWSER_EXTENSIONS`
- root help: `--args <args>`
- root help: `AGENT_BROWSER_ARGS`
- root help: `--user-agent <ua>`
- root help: `AGENT_BROWSER_USER_AGENT`
- root help: `--proxy <server>`
- root help: `AGENT_BROWSER_PROXY`
- root help: `HTTP_PROXY / HTTPS_PROXY`
- root help: `ALL_PROXY`
- root help: `--proxy-bypass <hosts>`
- root help: `AGENT_BROWSER_PROXY_BYPASS`
- root help: `NO_PROXY`
- root help: `--ignore-https-errors`
- root help: `AGENT_BROWSER_IGNORE_HTTPS_ERRORS`
- root help: `--ca-cert <path>`
- root help: `--no-ca-cert`
- root help: `AGENT_BROWSER_CA_CERT`
- root help: `AGENT_BROWSER_CLEAR_CA_CERT`
- root help: `--use-system-ca`
- root help: `AGENT_BROWSER_USE_SYSTEM_CA`
- core skill full: `SSL_CERT_FILE`
- root help: `--allow-file-access`
- root help: `AGENT_BROWSER_ALLOW_FILE_ACCESS`
- root help: `--hide-scrollbars <bool>`
- root help: `--headed`
- root help: `AGENT_BROWSER_HEADED`
- root help: `--webgpu`
- root help: `AGENT_BROWSER_WEBGPU`
- root help: `--no-webmcp`
- root help: `AGENT_BROWSER_NO_WEBMCP`
- root help: `--cdp <port|url>`
- root help: `--cdp-headers <json>`
- root help: `AGENT_BROWSER_CDP_HEADERS`
- root help: `AGENT_BROWSER_NO_VERSION_CHECK`
- root help: `--color-scheme <scheme>`
- root help: `AGENT_BROWSER_COLOR_SCHEME`
- root help: `--download-path <path>`
- root help: `AGENT_BROWSER_DOWNLOAD_PATH`
- root help: `--engine <name>`
- root help: `AGENT_BROWSER_ENGINE`
- root help: `--engine obscura`
- root help: `OBSCURA_ALLOW_PRIVATE_NETWORK`
- root help: `AGENT_BROWSER_OBSCURA_STEALTH`
- root help: `BROWSER_USE_PROFILE_ID`
- root help: `BROWSER_USE_PROXY_COUNTRY`
- root help: `BROWSER_USE_ENABLE_RECORDING`
- root help: `--input-mode <mode>`
- root help: `--no-auto-dialog`
- root help: `AGENT_BROWSER_NO_AUTO_DIALOG`
- root help: `--json`
- root help: `AGENT_BROWSER_JSON`
- root help: `--annotate`
- root help: `AGENT_BROWSER_ANNOTATE`
- root help: `--screenshot-dir <path>`
- root help: `AGENT_BROWSER_SCREENSHOT_DIR`
- root help: `--screenshot-quality <n>`
- root help: `AGENT_BROWSER_SCREENSHOT_QUALITY`
- root help: `--screenshot-format <fmt>`
- root help: `AGENT_BROWSER_SCREENSHOT_FORMAT`
- root help: `--content-boundaries`
- root help: `AGENT_BROWSER_CONTENT_BOUNDARIES`
- root help: `--max-output <chars>`
- root help: `AGENT_BROWSER_MAX_OUTPUT`
- root help: `--allowed-domains <list>`
- root help: `AGENT_BROWSER_ALLOWED_DOMAINS`
- root help: `--action-policy <path>`
- root help: `AGENT_BROWSER_ACTION_POLICY`
- root help: `--confirm-actions <list>`
- root help: `AGENT_BROWSER_CONFIRM_ACTIONS`
- root help: `--confirm-interactive`
- root help: `AGENT_BROWSER_CONFIRM_INTERACTIVE`
- root help: `--provider <name>`
- root help: `AGENT_BROWSER_PROVIDER`
- root help: `AGENT_BROWSER_PLUGINS`
- root help: `agent-browser -p ios device list`
- root help: `agent-browser -p ios swipe up`
- root help: `agent-browser -p ios tap @e1`
- root help: `--device <name>`
- root help: `AGENT_BROWSER_IOS_DEVICE`
- root help: `--model <name>`
- root help: `AI_GATEWAY_MODEL`
- root help: `--verbose`
- root help: `--quiet`
- root help: `--debug`
- root help: `AGENT_BROWSER_DEBUG`
- root help: `--config <path>`
- root help: `The auto-discovered ./agent-browser.json accepts only:`
- root help: `AGENT_BROWSER_CONFIG`
- root help: `AGENT_BROWSER_DEFAULT_TIMEOUT`
- root help: `AGENT_BROWSER_AUTOSAVE_INTERVAL_MS`
- root help: `AGENT_BROWSER_STREAM_PORT`
- root help: `AGENT_BROWSER_STREAM_QUALITY`
- root help: `AGENT_BROWSER_STREAM_MAX_WIDTH`
- root help: `AGENT_BROWSER_STREAM_MAX_HEIGHT`
- root help: `AGENT_BROWSER_IDLE_TIMEOUT_MS`
- root help: `AGENT_BROWSER_ENCRYPTION_KEY`
- root help: `AGENT_BROWSER_STATE_EXPIRE_DAYS`
- root help: `AGENT_BROWSER_IOS_UDID`
- root help: `AI_GATEWAY_URL`
- root help: `AI_GATEWAY_API_KEY`

</details>
<!-- agent-browser-capability-baseline:end capability-token-baseline -->

## Maintenance rule

Whenever the upstream `agent-browser` binary version changes in this project:

1. run `agent-browser --version`, `agent-browser --help`, `agent-browser tab --help`, `agent-browser snapshot --help`, and `agent-browser wait --help`
2. update the canonical version in `scripts/agent-browser-target.mjs` and the help/doc inventory in `scripts/agent-browser-capability-baseline.mjs`
3. update the human-authored command reference sections if command semantics or recommended workflows changed
4. run `npm run docs -- command-reference write` to regenerate capability baseline blocks; do not manually edit generated blocks
5. run `npm run verify -- command-reference`
6. update tool prompt guidance if the recommended agent workflow changed
7. update README and release docs if user-visible behavior changed
8. validate the extension still exposes local documentation that is at least as usable as the blocked direct-binary path for normal agent work
