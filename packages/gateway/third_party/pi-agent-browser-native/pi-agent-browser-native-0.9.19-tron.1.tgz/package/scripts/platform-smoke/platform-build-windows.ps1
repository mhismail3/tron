param(
  [Parameter(Mandatory=$true)][string]$PackageName,
  [Parameter(Mandatory=$true)][string]$NodeValidationVersion,
  [string]$CandidatePath = "",
  [string]$CandidateSha256 = ""
)

$ErrorActionPreference = "Continue"
$SourceRoot = (Get-Location).Path
$RunRoot = Join-Path ".platform-smoke-runs" ("platform-build-{0}-{1}" -f ((Get-Date).ToUniversalTime().ToString("yyyyMMddTHHmmssZ")), $PID)
$PackDir = Join-Path $SourceRoot (Join-Path $RunRoot "pack")
$PiProject = Join-Path $SourceRoot (Join-Path $RunRoot "pi-project")
New-Item -ItemType Directory -Force -Path $PackDir, $PiProject | Out-Null

function Write-Section($Name, $Path) {
  Write-Output "--- $Name START ---"
  if (Test-Path $Path) { Get-Content -Raw $Path }
  Write-Output "--- $Name END ---"
}

Write-Output "Starting platform-build in $SourceRoot at $((Get-Date).ToUniversalTime().ToString('o'))"
Write-Output "PLATFORM_RUN_ROOT=$RunRoot"

$NodeVersion = (& node --version 2>$null)
Write-Output "PLATFORM_NODE_VERSION=$NodeVersion"
$NodeVersionExit = 1
try { if ([version]$NodeVersion.TrimStart("v") -ge [version]$NodeValidationVersion) { $NodeVersionExit = 0 } } catch {}
Write-Output "PLATFORM_NODE_VERSION_EXIT=$NodeVersionExit"

& git init --quiet
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

& npm ci 2>&1
$NpmCiExit = $LASTEXITCODE
Write-Output "PLATFORM_NPM_CI_EXIT=$NpmCiExit"

& npm run verify -- platform-target 2>&1
$VerifyExit = $LASTEXITCODE
Write-Output "PLATFORM_VERIFY_EXIT=$VerifyExit"

$PackStderr = Join-Path $PackDir "npm-pack.stderr.txt"
$PackOutput = (& npm pack --silent --pack-destination $PackDir 2>$PackStderr)
$PackExit = $LASTEXITCODE
$PackTarball = ($PackOutput | Select-Object -Last 1)
$PackFile = if ($PackTarball) { Join-Path $PackDir $PackTarball } else { "" }
if (Test-Path $PackStderr) { Get-Content -Raw $PackStderr }
Write-Output "PLATFORM_NPM_PACK_EXIT=$PackExit"
$CandidateExit = 0
if ($CandidatePath) {
  $PackFile = Join-Path $PackDir "release-candidate.tgz"
  $CandidateBefore = ""
  try {
    Copy-Item -LiteralPath (Join-Path $SourceRoot $CandidatePath) -Destination $PackFile -ErrorAction Stop
    $CandidateBefore = (Get-FileHash -LiteralPath $PackFile -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()
  } catch { $CandidateExit = 1 }
  Write-Output "PLATFORM_CANDIDATE_SHA256_BEFORE=$CandidateBefore"
  if ($CandidateBefore -ne $CandidateSha256) { $CandidateExit = 1 }
}
Write-Output "PLATFORM_PACKED_TARBALL=$PackFile"

$PiCli = Join-Path $SourceRoot "node_modules/.bin/pi.cmd"
if (-not (Test-Path $PiCli)) { $PiCli = Join-Path $SourceRoot "node_modules/.bin/pi" }
if (-not (Test-Path $PiCli)) { $PiCli = "pi" }
Write-Output "PLATFORM_PI_CLI=$PiCli"

$PackedNodeInstallStdout = Join-Path $PackDir "packed-node-install.stdout.txt"
$PackedNodeInstallStderr = Join-Path $PackDir "packed-node-install.stderr.txt"
if ($CandidateExit -eq 0 -and $PackFile -and (Test-Path $PackFile)) {
  Push-Location $PiProject
  & npm init -y >$PackedNodeInstallStdout 2>$PackedNodeInstallStderr
  if ($LASTEXITCODE -eq 0) {
    & npm install --no-save $PackFile >>$PackedNodeInstallStdout 2>>$PackedNodeInstallStderr
  }
  $PackedNodeInstallExit = $LASTEXITCODE
  Pop-Location
} else {
  "missing tarball" | Set-Content $PackedNodeInstallStderr
  $PackedNodeInstallExit = 1
}
Write-Output "PLATFORM_PACKED_NODE_INSTALL_EXIT=$PackedNodeInstallExit"
Write-Section "PACKED_NODE_INSTALL_STDOUT" $PackedNodeInstallStdout
Write-Section "PACKED_NODE_INSTALL_STDERR" $PackedNodeInstallStderr

$PiInstallStdout = Join-Path $PackDir "pi-install.stdout.txt"
$PiInstallStderr = Join-Path $PackDir "pi-install.stderr.txt"
if ($PackedNodeInstallExit -eq 0) {
  Push-Location $PiProject
  $env:PI_OFFLINE = "1"
  & $PiCli install -l --approve ".\node_modules\$PackageName" >$PiInstallStdout 2>$PiInstallStderr
  $PiInstallExit = $LASTEXITCODE
  Remove-Item Env:\PI_OFFLINE -ErrorAction SilentlyContinue
  Pop-Location
} else {
  "packed npm install failed" | Set-Content $PiInstallStderr
  $PiInstallExit = 1
}
Write-Output "PLATFORM_PI_INSTALL_EXIT=$PiInstallExit"
Write-Section "PI_INSTALL_STDOUT" $PiInstallStdout
Write-Section "PI_INSTALL_STDERR" $PiInstallStderr

$PiListStdout = Join-Path $PackDir "pi-list.stdout.txt"
$PiListStderr = Join-Path $PackDir "pi-list.stderr.txt"
Push-Location $PiProject
$env:PI_OFFLINE = "1"
& $PiCli list --approve >$PiListStdout 2>$PiListStderr
$PiListExit = $LASTEXITCODE
Remove-Item Env:\PI_OFFLINE -ErrorAction SilentlyContinue
Pop-Location
Write-Output "PLATFORM_PI_LIST_EXIT=$PiListExit"
Write-Section "PI_LIST_STDOUT" $PiListStdout
Write-Section "PI_LIST_STDERR" $PiListStderr

if ($CandidatePath) {
  $CandidateAfter = ""
  try { $CandidateAfter = (Get-FileHash -LiteralPath $PackFile -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant() } catch { $CandidateExit = 1 }
  Write-Output "PLATFORM_CANDIDATE_SHA256_AFTER=$CandidateAfter"
  if ($CandidateAfter -ne $CandidateSha256) { $CandidateExit = 1 }
}

if ($NodeVersionExit -ne 0 -or $NpmCiExit -ne 0 -or $VerifyExit -ne 0 -or $PackExit -ne 0 -or $PackedNodeInstallExit -ne 0 -or $PiInstallExit -ne 0 -or $PiListExit -ne 0 -or $CandidateExit -ne 0) {
  Write-Output "PLATFORM_BUILD_FAILED"
  exit 1
}

Write-Output "PLATFORM_BUILD_OK"
