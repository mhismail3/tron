#!/usr/bin/env node
/**
 * Purpose: Manage pi-agent-browser-native package config under Pi-scoped config paths.
 * Responsibilities: Thin CLI argument parsing and config-file mutation around the shared config policy; preserve safe permissions and avoid echoing secrets.
 * Scope: Maintainer/user setup CLI only; canonical config validation, merge, provider descriptors, and status projection live in extensions/agent-browser/lib/config-policy.js.
 */

import { chmodSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";
import process from "node:process";

import { loadConfigPolicyModule } from "./config-policy-loader.mjs";

const {
	AGENT_BROWSER_CONFIG_ENV,
	BRAVE_API_KEY_ENV,
	DEFAULT_WEB_SEARCH_PROVIDER,
	EXA_API_KEY_ENV,
	WEB_SEARCH_PROVIDERS,
	formatBrowserExecutableStatus,
	formatBrowserProfileStatus,
	getAgentBrowserConfigPaths,
	getCredentialSourceSummary,
	getWebSearchProviderConfigKey,
	getWebSearchProviderEnvVar,
	getWebSearchProviderLabel,
	isWebSearchProvider,
	isConfigObject,
	loadAgentBrowserConfigStateSync,
	normalizeBrowserDefaultProfileName,
	parseAgentBrowserConfigJson,
	resolveBrowserDefaultProfilePolicy,
	summarizeConfigFiles,
} = await loadConfigPolicyModule();

/** @typedef {Readonly<Record<string, unknown>>} ConfigDocument */
/** @typedef {{ readonly switches: ReadonlySet<string>; readonly values: ReadonlyMap<string, string> }} ConfigFlags */
/** @typedef {import("../extensions/agent-browser/lib/config-providers.js").WebSearchProvider} WebSearchProvider */

const DEFAULT_CONFIG = { version: 1 };

class UsageError extends Error {
	/** @param {string} message */
	constructor(message) {
		super(message);
		this.name = "UsageError";
	}
}

function usage() {
	return `pi-agent-browser-native config helper

Usage through npm exec:
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config paths
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config show
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search status
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search set-key --stdin --provider <exa|brave> [--global|--project]
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search set-env <ENV_VAR> [--provider brave|exa] [--global|--project]
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search set-command <command> --provider <exa|brave> [--global|--project]
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search clear --provider <exa|brave|all> [--global|--project]
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search prefer <exa|brave|auto> [--global|--project]
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search enable [--global|--project]
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config web-search disable [--global|--project]
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config browser profile status
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config browser profile set <name|path> [--policy explicit-only|authenticated-only|always] [--global|--project]
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config browser profile clear [--global|--project]
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config browser executable status
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config browser executable set <path> [--global|--project]
  npm exec --yes --package pi-agent-browser-native -- pi-agent-browser-config browser executable clear [--global|--project]

Notes:
  Global config:  ~/.pi/config/pi-agent-browser-native/config.json
  Project config: .pi/config/pi-agent-browser-native/config.json
  Override:       ${AGENT_BROWSER_CONFIG_ENV}=/path/to/config.json
  Loaded config may use plaintext, environment interpolation, or !command credential sources; displayed status redacts resolved keys.
  Use --provider for set-key, set-command, and clear; set-env infers exa/brave from ${EXA_API_KEY_ENV} or ${BRAVE_API_KEY_ENV}.
`;
}

/** @param {ArrayIterator<string>} tokens
 * @param {string} option */
function readOptionValue(tokens, option) {
	const value = tokens.next().value;
	if (value === undefined || value.length === 0 || value.startsWith("--")) {
		throw new UsageError(`${option} requires a value.`);
	}
	return value;
}

/** @param {readonly string[]} argv */
function parseArgs(argv) {
	const positional = [];
	const switches = new Set();
	/** @type {Map<string, string>} */
	const values = new Map();
	const tokens = argv.values();
	for (const arg of tokens) {
		if (!arg.startsWith("--")) {
			positional.push(arg);
			continue;
		}
		if (["--global", "--project", "--stdin", "--help"].includes(arg)) {
			switches.add(arg);
			continue;
		}
		if (arg === "--policy" || arg === "--provider") {
			values.set(arg, readOptionValue(tokens, arg));
			continue;
		}
		throw new UsageError(`Unknown option: ${arg}`);
	}
	if (switches.has("--global") && switches.has("--project")) {
		throw new UsageError("Use only one of --global or --project.");
	}
	return { flags: { switches, values }, positional };
}

/** @param {string} path
 * @returns {ConfigDocument} */
function readConfig(path) {
	if (!existsSync(path)) {
		return { ...DEFAULT_CONFIG };
	}
	const parsed = parseAgentBrowserConfigJson(readFileSync(path, "utf8"));
	if (!parsed.ok) {
		throw new Error(`${path}: ${parsed.error}`);
	}
	if (!isConfigObject(parsed.value)) {
		throw new Error(`${path} must contain a JSON object.`);
	}
	return { ...DEFAULT_CONFIG, ...parsed.value };
}

/** @param {string} path
 * @param {ConfigDocument} config */
function writeConfig(path, config) {
	mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
	writeFileSync(path, `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600 });
	try {
		chmodSync(dirname(path), 0o700);
		chmodSync(path, 0o600);
	} catch {
		// Best effort on platforms/filesystems that do not support POSIX modes.
	}
}

/** @param {ConfigFlags} flags */
function selectWritePath(flags) {
	const paths = getAgentBrowserConfigPaths();
	if (flags.switches.has("--project")) {
		return { path: paths.project, scope: "project" };
	}
	return { path: paths.global, scope: "global" };
}

/** @param {unknown} provider
 * @param {{readonly allowAll?: boolean}} [options] */
function validateWebSearchProviderArg(provider, { allowAll = false } = {}) {
	if (isWebSearchProvider(provider) || (allowAll && provider === "all")) {
		return provider;
	}
	throw new UsageError(
		`--provider must be one of ${allowAll ? `${WEB_SEARCH_PROVIDERS.join(", ")}, all` : WEB_SEARCH_PROVIDERS.join(", ")}.`,
	);
}

/** @param {string} envName */
function inferWebSearchProviderFromEnvName(envName) {
	for (const provider of WEB_SEARCH_PROVIDERS) {
		if (envName === getWebSearchProviderEnvVar(provider)) {
			return provider;
		}
	}
	return;
}

/** @overload
 * @param {ConfigFlags} flags
 * @param {{readonly allowAll: true; readonly envName?: string}} options
 * @returns {WebSearchProvider | "all"} */
/** @overload
 * @param {ConfigFlags} flags
 * @param {{readonly allowAll?: false; readonly envName?: string}} [options]
 * @returns {WebSearchProvider} */
/** @param {ConfigFlags} flags
 * @param {{readonly allowAll?: boolean; readonly envName?: string}} [options] */
function getWebSearchProvider(flags, options = {}) {
	const configured = flags.values.get("--provider");
	if (configured !== undefined && configured !== "") {
		return validateWebSearchProviderArg(configured, options);
	}
	const inferred =
		options.envName !== undefined && options.envName.length > 0
			? inferWebSearchProviderFromEnvName(options.envName)
			: undefined;
	if (inferred !== undefined) {
		return inferred;
	}
	throw new UsageError(
		options.allowAll === true
			? "--provider is required and must be exa, brave, or all."
			: "--provider is required and must be exa or brave.",
	);
}

/** Config edits retain arbitrary JSON fields; loading owns config validation.
 * @param {unknown} value
 * @returns {Record<string, unknown>} */
function copyConfigSection(value) {
	return Object.fromEntries(Object.entries(value ?? {}));
}

/** @param {ConfigDocument} config
 * @param {WebSearchProvider} provider
 * @param {string} value */
function setWebSearchCredential(config, provider, value) {
	return {
		...config,
		webSearch: {
			...copyConfigSection(config.webSearch),
			[getWebSearchProviderConfigKey(provider)]: value,
		},
	};
}

/** @param {ConfigDocument} config
 * @param {WebSearchProvider} provider */
function clearWebSearchCredential(config, provider) {
	const hasWebSearch = Boolean(config.webSearch);
	if (!hasWebSearch) {
		return config;
	}
	const webSearch = copyConfigSection(config.webSearch);
	delete webSearch[getWebSearchProviderConfigKey(provider)];
	return { ...config, webSearch };
}

function printPaths() {
	const paths = getAgentBrowserConfigPaths();
	console.log(`Global: ${paths.global}`);
	console.log(`Project: ${paths.project}`);
	console.log(`Override: ${paths.override ?? `${AGENT_BROWSER_CONFIG_ENV} not set`}`);
}

function printStatus() {
	const state = loadAgentBrowserConfigStateSync({ cwd: process.cwd(), env: process.env });
	printPaths();
	console.log("");
	console.log("Config files:");
	for (const file of summarizeConfigFiles(state)) {
		console.log(`  ${file.scope}: ${file.path} ${file.exists ? "[exists]" : "[missing]"}`);
	}
	console.log("");
	console.log("Effective config:");
	console.log(`  webSearch.enabled: ${state.webSearchEnabled ? "true" : "false"}`);
	console.log(
		`  webSearch.preferredProvider: ${state.config.webSearch?.preferredProvider ?? `auto (default ${DEFAULT_WEB_SEARCH_PROVIDER})`}`,
	);
	console.log(
		`  webSearch.defaultSearchType: ${state.config.webSearch?.defaultSearchType ?? "not configured (Exa auto)"}`,
	);
	for (const provider of WEB_SEARCH_PROVIDERS) {
		const field = getWebSearchProviderConfigKey(provider);
		console.log(
			`  webSearch.${field}: ${getCredentialSourceSummary(state.webSearchCredentialSources[provider], provider)}`,
		);
	}
	console.log(`  browser.defaultProfile: ${formatBrowserProfileStatus(state)}`);
	console.log(`  browser.executablePath: ${formatBrowserExecutableStatus(state)}`);
	if (state.layers.length === 0) {
		console.log("  layers: none");
	}
	printDiagnostics("Warnings", state.warnings);
	printDiagnostics("Validation errors", state.errors);
}

/** @param {string} label
 * @param {readonly string[]} diagnostics */
function printDiagnostics(label, diagnostics) {
	if (diagnostics.length > 0) {
		console.log("");
		console.log(`${label}:`);
		for (const diagnostic of diagnostics) {
			console.log(`  - ${diagnostic}`);
		}
	}
}

/** @param {boolean} useStdin */
async function readSecretFromStdin(useStdin) {
	if (!useStdin) {
		throw new UsageError(
			"set-key requires --stdin so the key is not passed through argv or an echoed prompt.",
		);
	}
	let input = "";
	for await (const chunk of process.stdin) {
		input += String(chunk);
	}
	const value = input.trim();
	if (value.length === 0) {
		throw new UsageError("No key was provided on stdin.");
	}
	return value;
}

/** @param {string} path
 * @param {(config: ConfigDocument) => ConfigDocument} mutate */
function mutateConfig(path, mutate) {
	const config = readConfig(path);
	writeConfig(path, mutate(config));
}

/** @param {readonly string[]} args
 * @param {ConfigFlags} flags */
async function handleWebSearch(args, flags) {
	const action = args[0];
	if (action === "prefer" || action === "enable" || action === "disable") {
		handleWebSearchPreference(action, args, flags);
		return;
	}
	if (action === "status") {
		printStatus();
		return;
	}
	if (action === "clear") {
		clearWebSearch(flags);
		return;
	}
	await handleWebSearchCredential(action, args, flags);
}

/** @param {string | undefined} action
 * @param {readonly string[]} args
 * @param {ConfigFlags} flags */
async function handleWebSearchCredential(action, args, flags) {
	if (action === "set-key") {
		const provider = getWebSearchProvider(flags);
		const key = await readSecretFromStdin(flags.switches.has("--stdin"));
		const { path, scope } = selectWritePath(flags);
		mutateConfig(path, (config) => setWebSearchCredential(config, provider, key));
		console.log(`Saved ${getWebSearchProviderLabel(provider)} key to ${scope} config: ${path}`);
		return;
	}
	if (action === "set-env") {
		const envName = args[1];
		if (
			envName === undefined ||
			envName.length === 0 ||
			!/^[A-Za-z_][A-Za-z0-9_]*$/.test(envName)
		) {
			throw new UsageError("set-env requires a valid environment variable name.");
		}
		const provider = getWebSearchProvider(flags, { envName });
		const envReference = `$${envName}`;
		const { path, scope } = selectWritePath(flags);
		mutateConfig(path, (config) => setWebSearchCredential(config, provider, envReference));
		console.log(`Saved ${getWebSearchProviderLabel(provider)} ${scope} env reference to: ${path}`);
		return;
	}
	if (action === "set-command") {
		const provider = getWebSearchProvider(flags);
		const command = args.slice(1).join(" ").trim();
		if (command.length === 0) {
			throw new UsageError("set-command requires a command string.");
		}
		const { path, scope } = selectWritePath(flags);
		mutateConfig(path, (config) => setWebSearchCredential(config, provider, `!${command}`));
		console.log(`Saved ${getWebSearchProviderLabel(provider)} ${scope} command source to: ${path}`);
		return;
	}
	throw new UsageError(`Unsupported web-search action: ${action ?? ""}`);
}

/** @param {ConfigFlags} flags */
function clearWebSearch(flags) {
	const provider = getWebSearchProvider(flags, { allowAll: true });
	const { path, scope } = selectWritePath(flags);
	mutateConfig(path, (config) => {
		const providers = provider === "all" ? WEB_SEARCH_PROVIDERS : [provider];
		return providers.reduce(clearWebSearchCredential, config);
	});
	console.log(
		`Cleared ${provider === "all" ? "all web-search" : getWebSearchProviderLabel(provider)} credential source in ${scope} config: ${path}`,
	);
}

/** @param {string} action
 * @param {readonly string[]} args
 * @param {ConfigFlags} flags */
function handleWebSearchPreference(action, args, flags) {
	if (action === "prefer") {
		const provider = args[1];
		if (!isWebSearchProvider(provider) && provider !== "auto") {
			throw new UsageError("prefer requires exa, brave, or auto.");
		}
		const { path, scope } = selectWritePath(flags);
		mutateConfig(path, (config) => {
			const webSearch = copyConfigSection(config.webSearch);
			if (provider === "auto") {
				delete webSearch.preferredProvider;
			} else {
				webSearch.preferredProvider = provider;
			}
			return { ...config, webSearch };
		});
		console.log(
			`${provider === "auto" ? "Cleared" : "Saved"} web-search preferred provider in ${scope} config: ${path}`,
		);
		return;
	}
	if (action === "enable" || action === "disable") {
		const { path, scope } = selectWritePath(flags);
		mutateConfig(path, (config) => ({
			...config,
			webSearch: { ...copyConfigSection(config.webSearch), enabled: action === "enable" },
		}));
		console.log(
			`${action === "enable" ? "Enabled" : "Disabled"} agent_browser_web_search in ${scope} config: ${path}`,
		);
		return;
	}
	throw new UsageError(`Unsupported web-search action: ${action}`);
}

/** @param {ConfigDocument} config
 * @param {"defaultProfile" | "executablePath"} key */
function clearBrowserSetting(config, key) {
	const hasBrowser = Boolean(config.browser);
	if (!hasBrowser) {
		return config;
	}
	const browser = copyConfigSection(config.browser);
	delete browser[key];
	return { ...config, browser };
}

/** @param {readonly string[]} args
 * @param {ConfigFlags} flags */
function handleBrowserProfile(args, flags) {
	const action = args[1];
	if (action === "status") {
		printStatus();
		return;
	}
	if (action === "set") {
		const name = normalizeBrowserDefaultProfileName(args.slice(2).join(" "));
		if (name === undefined) {
			throw new UsageError(
				"browser profile set requires a profile name or profile directory path.",
			);
		}
		const policy = resolveBrowserDefaultProfilePolicy(flags.values.get("--policy"));
		if (policy === undefined) {
			throw new UsageError("Invalid --policy value.");
		}
		const { path, scope } = selectWritePath(flags);
		mutateConfig(path, (config) => ({
			...config,
			browser: { ...copyConfigSection(config.browser), defaultProfile: { name, policy } },
		}));
		console.log(`Saved browser default profile in ${scope} config: ${path}`);
		return;
	}
	if (action === "clear") {
		const { path, scope } = selectWritePath(flags);
		mutateConfig(path, (config) => clearBrowserSetting(config, "defaultProfile"));
		console.log(`Cleared browser default profile in ${scope} config: ${path}`);
		return;
	}
	throw new UsageError(`Unsupported browser profile action: ${action ?? ""}`);
}

/** @param {readonly string[]} args
 * @param {ConfigFlags} flags */
function handleBrowserExecutable(args, flags) {
	const action = args[1];
	if (action === "status") {
		printStatus();
		return;
	}
	if (action === "set") {
		const executablePath = args.slice(2).join(" ").trim();
		if (executablePath.length === 0) {
			throw new UsageError("browser executable set requires a browser executable path.");
		}
		const { path, scope } = selectWritePath(flags);
		mutateConfig(path, (config) => ({
			...config,
			browser: { ...copyConfigSection(config.browser), executablePath },
		}));
		console.log(`Saved browser executable path in ${scope} config: ${path}`);
		return;
	}
	if (action === "clear") {
		const { path, scope } = selectWritePath(flags);
		mutateConfig(path, (config) => clearBrowserSetting(config, "executablePath"));
		console.log(`Cleared browser executable path in ${scope} config: ${path}`);
		return;
	}
	throw new UsageError(`Unsupported browser executable action: ${action ?? ""}`);
}

/** @param {readonly string[]} args
 * @param {ConfigFlags} flags */
function handleBrowser(args, flags) {
	const target = args[0];
	if (target === "profile") {
		handleBrowserProfile(args, flags);
		return;
	}
	if (target === "executable") {
		handleBrowserExecutable(args, flags);
		return;
	}
	throw new UsageError(`Unsupported browser action: ${target ?? ""}`);
}

/** @param {readonly string[]} argv
 * @returns {Promise<number>} */
export async function main(argv = process.argv.slice(2)) {
	const { flags, positional } = parseArgs(argv);
	const command = positional.at(0);
	if (flags.switches.has("--help") || command === undefined) {
		console.log(usage());
		return 0;
	}
	if (command === "paths") {
		printPaths();
		return 0;
	}
	if (command === "show") {
		printStatus();
		return 0;
	}
	if (command === "web-search") {
		await handleWebSearch(positional.slice(1), flags);
		return 0;
	}
	if (command === "browser") {
		handleBrowser(positional.slice(1), flags);
		return 0;
	}
	throw new UsageError(`Unknown command: ${command}`);
}

if (import.meta.main) {
	main().catch(
		/** @param {unknown} error */ (error) => {
			if (error instanceof UsageError) {
				console.error(error.message);
				console.error(usage());
				process.exit(2);
			}
			console.error(error instanceof Error ? error.message : String(error));
			process.exit(1);
		},
	);
}
