#!/usr/bin/env node
/**
 * Purpose: Build generated dist output for GitHub/source installs even when Pi invokes npm install --omit=dev.
 * Responsibilities: Detect missing source-build dependencies, install dev dependencies with lifecycle scripts disabled, then run the canonical build.
 * Scope: Package install lifecycle only; npm tarball contents and runtime behavior remain owned by scripts/build.mjs.
 * Usage: package.json prepare script.
 */

import { execFile as execFileCallback } from "node:child_process";
import { existsSync } from "node:fs";
import { join } from "node:path";
import process from "node:process";
import { promisify } from "node:util";

const execFile = promisify(execFileCallback);
const REQUIRED_SOURCE_BUILD_MODULES = [
	"typescript",
	"esbuild",
	"typebox",
	"@earendil-works/pi-coding-agent",
	"@earendil-works/pi-tui",
];

function canResolveBuildDependencies() {
	return REQUIRED_SOURCE_BUILD_MODULES.every((moduleName) => {
		try {
			return existsSync(new URL(import.meta.resolve(moduleName)));
		} catch {
			return false;
		}
	});
}

async function runNpmInstallDevDependencies() {
	const npmExecPath = process.env.npm_execpath;
	const options = process.platform === "win32" ? { shell: true } : {};
	if (npmExecPath !== undefined && npmExecPath.length > 0) {
		await execFile(
			process.execPath,
			[npmExecPath, "install", "--include=dev", "--ignore-scripts"],
			{
				...options,
				cwd: process.cwd(),
				maxBuffer: 20 * 1024 * 1024,
			},
		);
		return;
	}
	await execFile("npm", ["install", "--include=dev", "--ignore-scripts"], {
		...options,
		cwd: process.cwd(),
		maxBuffer: 20 * 1024 * 1024,
	});
}

async function main() {
	if (!canResolveBuildDependencies()) {
		await runNpmInstallDevDependencies();
	}
	await execFile(process.execPath, [join(process.cwd(), "scripts", "build.mjs")], {
		cwd: process.cwd(),
		maxBuffer: 20 * 1024 * 1024,
	});
}

main().catch((/** @type {unknown} */ error) => {
	if (error !== null && typeof error === "object") {
		if ("stdout" in error && typeof error.stdout === "string" && error.stdout.length > 0) {
			process.stdout.write(error.stdout);
		}
		if ("stderr" in error && typeof error.stderr === "string" && error.stderr.length > 0) {
			process.stderr.write(error.stderr);
		}
	}
	console.error(error instanceof Error ? error.message : String(error));
	process.exitCode = 1;
});
