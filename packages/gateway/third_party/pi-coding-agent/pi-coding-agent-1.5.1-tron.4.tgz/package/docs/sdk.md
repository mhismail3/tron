# SDK

`@earendil-works/pi-coding-agent` embeds Pi in a Node.js or Bun process. It provides direct TypeScript access to the agent, sessions, tools, models, and resources used by the command-line application.

Use the SDK for in-process TypeScript integration. For a language-independent or isolated subprocess, see [CLI Integration](cli-integration.md).

```typescript
import { createAgentSession } from "@earendil-works/pi-coding-agent";

const { session } = await createAgentSession();

try {
  await session.prompt("What files are in the current directory?");
  console.log(session.getLastAssistantText());
} finally {
  session.dispose();
}
```

This uses the working directory, discovered resources, stored settings, and configured credentials. `prompt()` resolves when the run finishes.

The [complete minimal example](../examples/sdk/01-minimal.ts) also streams text events. All [SDK examples](../examples/sdk/) are typechecked with the repository.

<a id="session-management"></a>

## Session lifecycle

`createAgentSession()` creates an `AgentSession`. The session owns one conversation, its model and tools, queued messages, compaction state, and extension runtime.

Read current state through `session.messages`, `session.model`, `session.thinkingLevel`, `session.systemPrompt`, and `session.getActiveToolNames()`.

`createAgentSession` and `createAgentSessionFromServices` accept a host-owned `preamble`. It replaces the default harness identity without suppressing tool snippets, tool-contributed guidelines or documentation. With a custom system prompt, the custom text becomes a separate `role` section after that preamble. Extensions can update the run's preamble through `before_agent_start` prompt options.

`session.systemPrompt` is read-only and returns the current effective system prompt, including changes that have not yet been sent to the model. Tool changes are declared to the model before the next request. During a run it is the run's prompt, forced text included. Between runs it is the base prompt plus the extension sections the transcript still gives the model, such as the `mcp_servers` listing; a `before_agent_start` handler that stops setting a section removes it at the next request.

<a id="sessionmanager-api"></a>

### Session storage

Sessions are persistent by default. `SessionManager` owns the persisted or in-memory entry tree and tracks its active leaf. Branching changes that leaf without deleting abandoned branches. When Pi reconstructs model context, the manager selects the active branch and applies compaction.

`SessionManager` is authoritative for finalized model context. Restore external history by constructing the session with a manager containing those entries. Assigning `session.agent.state.messages` does not replace persisted context.

Use an in-memory manager when the host does not want session files:

```typescript
import { createAgentSession, SessionManager } from "@earendil-works/pi-coding-agent";

const { session } = await createAgentSession({
  sessionManager: SessionManager.inMemory(),
});
```

See the checked [sessions example](../examples/sdk/11-sessions.ts) for creating, opening, continuing, listing, and forking sessions. [Session File Format](session-format.md) defines the persisted JSONL contract, and [Message Types](message-types.md) defines transcript values. For exact methods and signatures, use the exported TypeScript declarations or [`session-manager.ts`](../src/core/session-manager.ts).

`cwd` selects the workspace used for project resource discovery, context files, session grouping, and built-in tool paths. Pass it explicitly when the target differs from `process.cwd()`.

`projectDir` selects the directory whose `.pi` holds the project configuration when it is not `cwd`, for example the repository root of a session that runs in a subdirectory. Project settings, resources, packages, `SYSTEM.md`, and MCP servers then come from `<projectDir>/.pi`, and stdio MCP servers start in `projectDir`. Tools, context files, `.agents/skills` discovery, and session grouping still use `cwd`. Extensions read it as `ctx.projectDir`. `createAgentSessionServices()` passes it to the settings manager and resource loader it creates; when you construct them yourself, pass the same directory to `SettingsManager.create()`, `DefaultResourceLoader`, and `createAgentSession()`. Decide project trust for `projectDir`, since it gates that configuration; `hasTrustRequiringProjectResources(cwd, projectDir)` reports whether a decision is needed. `AgentSessionRuntime` calls its factory with the target `cwd` only, so a factory that uses `projectDir` resolves it for that `cwd`.

`session.dispose()` aborts active work, invalidates extension contexts, disconnects from the agent, and removes event listeners. Call it when the session is no longer needed.

`AgentSessionRuntime` adds `newSession()`, `switchSession()`, `fork()`, and `importFromJsonl()`. Each operation replaces the active `AgentSession` and recreates services for the target working directory.

After a runtime replacement, subscriptions belong to the old `AgentSession` and must be rebound. See the [session runtime example](../examples/sdk/13-session-runtime.ts).

## Prompting

`prompt()` handles extension commands and expands file-based prompt templates before ordinary user messages enter the agent. For an accepted agent run, it resolves after the run finishes, including automatic retries.

A prompt sent while the session is already streaming must specify whether it should steer the current run or follow it. Calling `prompt()` without that choice rejects rather than guessing.

A steering message enters after the current assistant turn and its tool calls. A follow-up enters after the current run finishes its pending work. `steer()` and `followUp()` expose those behaviors directly and return `"queued"` if the input was queued (including after an extension transformed it), or `"handled"` if an extension consumed it.

`abort()` stops the active operation and waits for the session to become idle. `waitForIdle()` waits without aborting it.

## Subscribing to events

Subscribe before prompting when the host needs streamed output:

```typescript
const unsubscribe = session.subscribe((event) => {
  if (event.type === "message_update" && event.assistantMessageEvent.type === "text_delta") {
    process.stdout.write(event.assistantMessageEvent.delta);
  }
});

try {
  await session.prompt("Explain this repository");
} finally {
  unsubscribe();
}
```

Session events report message updates, tool execution, queues, compaction, retries, and run lifecycle changes.

`message_end` contains the authoritative completed message. `agent_end` marks the end of one low-level agent run, but automatic recovery or queued work can still follow.

Use `agent_settled` when the host needs to know that Pi will not continue automatically.

## Configuring a session

Without overrides, the factory creates a `ModelRuntime`, file-backed `SettingsManager`, persistent `SessionManager`, `DefaultResourceLoader`, and the configured default tools.

Each boundary can be supplied explicitly:

- `modelRuntime`, `model`, `thinkingLevel`, and `scopedModels` control model access and selection.
- `settingsManager` supplies merged settings or an in-memory configuration.
- `sessionManager` supplies persistent or in-memory conversation history.
- `resourceLoader` supplies extensions, skills, prompt templates, themes, and context files.
- `tools`, `noTools`, `excludeTools`, and `customTools` control the active tool set.

Use `DefaultResourceLoader` when you want standard discovery with selected overrides. Supply a custom `ResourceLoader` when the host owns resource storage and discovery completely.

### Remove global settings with a backup

`await settingsManager.unsetGlobalSettings(["theme", "hideThinkingBlock"])` removes declared top-level keys from file-backed global settings. It does not remove project overrides or change the host's approval policy. In-memory/custom storage and unknown keys are refused. An absent key is a no-op, without a backup.

The operation shares the settings write queue and file lock with setters. It reads the current file under that lock, preserves unknown and unrelated parsed fields, and writes an exclusive, exact-byte `0600` backup beside `settings.json`. The backup and its directory are flushed before an atomic `0600` replacement, which is also flushed. The source must be a single-link regular file owned by the current POSIX user, with owner read/write permissions and no bits outside `0644`. Symlinked files or containing directories, unsafe source modes, invalid UTF-8/JSON, and detected file/directory identity, content, ownership or mode changes are refused. Directory identity is fenced from before lock acquisition through reading and replacement. This relies on the settings lock for cooperating writers; it is not an operating-system sandbox against an adversarial writer racing the final check and rename. Directory flushing requires a supporting filesystem. Retained backup files are not pruned automatically.

The promise rejects on refusal or error; queued storage errors are also recorded by `drainErrors()`. A successful receipt contains only `status: "unchanged"` and `changedKeys: []`, or `status: "applied"`, changed key names, `backupPath`, and before/after SHA-256 digests. It never contains setting values. Await this promise for its own result; `flush()` joins the queue but retains its existing error-collection behavior. Failed setter edits remain owned until persistence succeeds or a successful unset explicitly deletes them. Later setters remain ordered after deletion, rebased at their field or map-entry granularity without reviving deleted siblings. Effective getters still include project settings.

Filesystem failures reject with `SettingsUnsetError`: fixed message, `phase`, `replacement` (`"not-attempted"` or `"uncertain"`), optional `recovery`, and secondary `cleanupFailures`. The primary phase is preserved if descriptor close or lock release also fails. Before a rename attempt this operation has not replaced the source, but another writer may have changed it. Any failure from the rename attempt onward is conservatively uncertain, never an applied/unchanged receipt. The manager then refuses further global persistence and unset operations until explicit `reload()` reconciles its view with storage; a successful reload discards only pending global edits accepted before its call boundary, so the host must settle that intent first. Reload runs on the same queue, rebases later accepted global edits onto the loaded settings, and leaves those edits owned by their subsequent writes. Global persistence checks load/recovery errors at its queue turn, allowing writes ordered after a successful reload while still refusing writes before recovery. Do not interpret rejection or the running getters as proof of canonical state.

`recovery.kind: "verified-backup"` carries `backupPath` and `beforeSha256` only after the exact-byte backup file and directory flushes succeed. `"unverified-backup"` carries only an owned retained path: it may be incomplete or not durably recorded and is not an authorized restore source. These describe acknowledged filesystem calls, not a guarantee against hardware/filesystem failure. Restore is an explicit host action: stop writers, inspect canonical state, verify the successful receipt's or verified recovery metadata's backup SHA-256, and atomically replace global `settings.json` from that backup with private permissions and filesystem flushing, then reload. If no verified backup metadata exists, establish recovery independently; do not restore from a filename alone. There is no automatic restore, rollback reader or fallback.

<a id="inlineextension"></a>

Inline extension factories can be supplied through `DefaultResourceLoader`. Give one an `InlineExtension` name only when it needs a stable name in diagnostics and startup output. A named inline extension with `replaceable: true` is left out when another extension registers a tool, command, or flag with a name it registers during loading, instead of both loading with a conflict. The CLI's built-in codemode, tool search, and MCP extensions are replaceable. A named entry with `builtin: true` is not an inline extension: it supplies the code of the `builtin:<name>` extension, which loads like a configured extension file. It loads by default, is listed in `pi config`, and is disabled by `-builtin:<name>` in the `extensions` setting or by `noExtensions`; `additionalExtensionPaths: ["builtin:<name>"]` loads it explicitly. It loads after project trust is resolved, so it cannot handle `project_trust`. The CLI's built-in extensions use it.

### Inspect MCP configuration without connecting

`loadMcpConfig({ agentDir, cwd: projectDir, projectTrusted, maxConfigBytes: 256 * 1024 })`, exported from the package root, reads the same canonical configuration as the MCP extension. It includes disabled servers, global/project precedence, project overrides, source metadata and validation errors. Pass the project configuration directory as `cwd`, and its actual trust decision as `projectTrusted`; untrusted project files are not read. `maxConfigBytes` is an optional per-file UTF-8 byte budget. An oversized file contributes an error and no entries; other valid sources remain. Omitting the budget keeps the normal SDK loading behavior.

This call does not create a session, write files, start servers, connect, refresh providers, or resolve environment/command/credential values. It reads only the applicable `mcp.json` files. Returned configuration can still contain literal credentials, and parse diagnostics can contain source text. Hosts must project only bounded non-secret metadata and error counts into public or model-visible inventory; do not dump the result or raw diagnostics.

<a id="codemode-mcp"></a>

The CLI loads `codemode`, `tool_search`, and MCP as built-in extensions. SDK sessions do not; add `createCodemodeExtension()`, `createToolSearchExtension()`, and `createMcpExtension()` to the `extensionFactories` of `DefaultResourceLoader`. `codemode` and `tool_search` are registered inactive: enable them through the `defaultTools` setting (`["+codemode", "+tool_search"]` keeps the other default tools), or let the MCP extension activate them: `codemode` for servers with `codemode` exposure, `tool_search` for servers with `deferred` exposure. The MCP extension connects its servers on `session_start`, so call `session.bindExtensions()`. See [Codemode and MCP](../examples/sdk/14-codemode-mcp.ts).

See the focused examples for [models](../examples/sdk/02-custom-model.ts), [tools](../examples/sdk/05-tools.ts), [extensions](../examples/sdk/06-extensions.ts), and [full control](../examples/sdk/12-full-control.ts).

## Examples

| Example | Purpose |
|---|---|
| [Minimal](../examples/sdk/01-minimal.ts) | Create, prompt, observe, and dispose a session |
| [Custom model](../examples/sdk/02-custom-model.ts) | Select a model and thinking level |
| [System prompt](../examples/sdk/03-custom-prompt.ts) | Replace or append to the system prompt |
| [Skills](../examples/sdk/04-skills.ts) | Discover, filter, and add skills |
| [Tools](../examples/sdk/05-tools.ts) | Select built-in tools and their working directory |
| [Extensions](../examples/sdk/06-extensions.ts) | Load file-based and inline extensions |
| [Context files](../examples/sdk/07-context-files.ts) | Add or replace project instructions |
| [Prompt templates](../examples/sdk/08-prompt-templates.ts) | Add file-style prompt templates |
| [Credentials](../examples/sdk/09-api-keys-and-oauth.ts) | Configure credential and model storage |
| [Settings](../examples/sdk/10-settings.ts) | Supply file-backed or in-memory settings |
| [Sessions](../examples/sdk/11-sessions.ts) | Control session persistence and restoration |
| [Full control](../examples/sdk/12-full-control.ts) | Replace default discovery and state services |
| [Session runtime](../examples/sdk/13-session-runtime.ts) | Replace the active session safely |
| [Codemode and MCP](../examples/sdk/14-codemode-mcp.ts) | Add the `codemode`, `tool_search`, and MCP extensions |

<a id="exports"></a>

## Resources

- [Choose a Model](models.md) covers model selection and compatible endpoints; [Providers](providers.md) covers credentials and provider-specific setup.
- [Configuration](configuration.md) explains normal discovery and settings; [Settings](settings.md) lists every setting.
- [Sessions and Context](sessions.md) explains session behavior; [Session Format](session-format.md) defines persisted entries; [Message Types](message-types.md) defines shared transcript values.
- [Extensions](extensions.md), [Skills](skills.md), and [Prompt Templates](prompt-templates.md) document resources supplied through a `ResourceLoader`.
- [CLI Integration](cli-integration.md) covers print, JSON, and RPC alternatives to an in-process SDK integration.
